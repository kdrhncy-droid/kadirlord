async (page) => {
  await page.goto('http://127.0.0.1:8080/armory-studio.html');
  await page.waitForTimeout(1800);
  for (let i = 0; i < 4; i++) {
    await page.evaluate((n) => document.querySelectorAll('#sekmeler button')[n].click(), i);
    await page.waitForTimeout(1400);
  }
  await page.evaluate(() => document.querySelectorAll('#sekmeler button')[1].click());
  await page.waitForTimeout(900);
  await page.screenshot({ path: '/home/user/shot_27_final.png' });
  console.log('GEZİNDİ');
}

import * as THREE from 'three';
import { Character, ROLE_PRESETS, countObject } from '../build/Character.js';
import { bakeRigPose } from '../build/Army.js';
import { triCount, MaterialLibrary } from '../build/Core.js';

const ch = new Character({ faction:'vlandia', lod:'crowd', loadout: ROLE_PRESETS.infantry, seed: 5 });
console.log('grup üçgen:', countObject(ch.group));
let meshCount=0, skipped=0;
ch.group.traverse(o=>{ if(o.isMesh) meshCount++; });
console.log('mesh sayısı:', meshCount);
console.log('joint isimleri:', [...ch.rig.joints.keys()].join(','));
ch.rig.applyPose(ch.animator.evaluate('walk',0.5,{phase:0.5,speed:1}), true);
const g = bakeRigPose(ch.rig, ch.group, new MaterialLibrary({}));
console.log('bake üçgen:', triCount(g), 'position var mı:', !!g.attributes.position, 'count:', g.attributes.position?.count);

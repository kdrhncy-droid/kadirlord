// test/attack.mjs — saldırı yayı denetimi (fazdan bağımsız)
// Tez: vuruş klipinin bir anında (t*) silah ucu EN ÖNDE olmalı ve o anda
//   1) uç göğüs düzleminin belirgin önünde (karakter −Z'ye bakar → z küçük),
//   2) uç omuz-bel bandında (temas kafaya/yere değil, gövdeye),
//   3) uç↔el mesafesi tüm klip boyunca sabit (silah elde kabzasından pivotlanır),
//   4) t* vuruş bandında (kurulumda veya dinlenmede değil).
import * as THREE from 'three';
import { Character } from '../build/src/Character.js';
import { FactionPalette } from '../build/src/Faction.js';

const WEAPONS = ['gladius', 'greatsword', 'scimitar', 'warAxe', 'bardiche', 'lance', 'halberd',
  'flangedMace', 'warHammer', 'morningstar', 'billhook', 'recurveBow'];

// düğüm-uzayı uç noktası: geometri bbox'larını düğüm yerelinde birleştir (pozdan bağımsız)
function tipLocal(node) {
  const b = new THREE.Box3();
  node.updateMatrixWorld(true);
  const inv = new THREE.Matrix4().copy(node.matrixWorld).invert();
  node.traverse((o) => {
    if (!o.isMesh) return;
    o.geometry.computeBoundingBox();
    const local = new THREE.Matrix4().multiplyMatrices(inv, o.matrixWorld); // ağ→düğüm uzayı
    b.union(o.geometry.boundingBox.clone().applyMatrix4(local));
  });
  return new THREE.Vector3((b.min.x + b.max.x) / 2, b.max.y, (b.min.z + b.max.z) / 2);
}

let fail = 0;
const fac = FactionPalette.byId('vlandia');
console.log('── saldırı yayı denetimi (attackSword / shootBow) ──');
for (const id of WEAPONS) {
  const isBow = id === 'recurveBow';
  const clip = isBow ? 'shootBow' : 'attackSword';
  const ch = new Character({
    faction: fac, lod: 'hero',
    loadout: { role: 'infantry', tier: 'medium', helm: 'none', surcoat: false, weapon: id, offhand: null, back: null },
  });
  const handKey = isBow ? 'weaponL' : 'weaponR';
  const node = ch.rig.joint(handKey).children.find((c) => c.name.startsWith(id));
  if (!node) { console.log(`  ${id.padEnd(11)} TAKILI DÜĞÜM BULUNAMADI`); fail++; continue; }
  const tipL = tipLocal(node);
  let best = null; let dMin = Infinity; let dMax = 0;
  for (let t = 0; t <= 1.5; t += 0.05) {
    ch.setPose(ch.animator.evaluate(clip, t));
    ch.group.updateMatrixWorld(true);
    const hw = new THREE.Vector3(); ch.rig.joint(handKey).getWorldPosition(hw);
    const tw = tipL.clone().applyMatrix4(node.matrixWorld);
    const d = tw.distanceTo(hw);
    dMin = Math.min(dMin, d); dMax = Math.max(dMax, d);
    if (!best || tw.z < best.z) best = { t, x: tw.x, y: tw.y, z: tw.z };
  }
  const pivotOK = dMax - dMin < 0.01;                       // rijit montaj: mesafe sabit
  const reachOK = dMax > 0.35;                              // ölçülen uç gerçekten namlu ucu
  const fwdOK = best.z < (isBow ? -0.15 : -Math.max(0.18, 0.3 * dMax)); // yay: geren kol önde
  const hgtOK = best.y > 0.5 && best.y < 1.9;               // temas gövde bandında
  const bandOK = best.t > (isBow ? 0.2 : 0.45) && best.t < 1.0;  // yay: germe-bırakma penceresi
  const ok = pivotOK && reachOK && fwdOK && hgtOK && bandOK;
  if (!ok) fail++;
  console.log(
    `  ${id.padEnd(11)} t* ${best.t.toFixed(2)} sn · uç (x${best.x.toFixed(2)} y${best.y.toFixed(2)} z${best.z.toFixed(2)})` +
    ` · erişim ${dMax.toFixed(2)} m · pivot sapma ${(dMax - dMin).toFixed(3)} m · ${ok ? '✓' : '✗ YAY HATALI'}`,
  );
}
console.log(fail === 0
  ? '✓ tüm silahlar vuruş bandında öne uzanıyor, temas gövde hizasında, pivot elde sabit'
  : `✗ ${fail} silah yayında sorun`);
process.exit(fail === 0 ? 0 : 1);

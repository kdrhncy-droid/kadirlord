/**
 * fit.mjs — kuşanma oturma denetimi.
 * Her eşya için: eklem dünya konumu, eşyanın dünya bbox'u, kabza (grip)
 * dünya konumu ve el eklemine uzaklığı. Kabza elde durmuyorsa saldırı
 * animasyonu da yanlış pivot intorno döner (kayma hissi).
 */
import * as THREE from 'three';
import { Character } from '../build/src/Character.js';
import { FactionPalette } from '../build/src/Faction.js';
import { ARMORY_CATALOG } from '../build/src/Armory.js';

const SLOTS = {
  weapon: ['gladius', 'greatsword', 'scimitar', 'warAxe', 'bardiche', 'lance', 'halberd', 'flangedMace', 'warHammer', 'morningstar', 'billhook'],
  offhand: ['recurveBow'],
  shield: ['vikingShield', 'kiteShield', 'paviseShield', 'cavalryRound'],
  head: ['greatHelm', 'hornedHelm', 'nasalHelm', 'kettleHat'],
  back: ['gladius', 'warAxe', 'recurveBow'],
};

const fac = FactionPalette.byId('vlandia');
const v = (o) => [o.x.toFixed(3), o.y.toFixed(3), o.z.toFixed(3)].join(',');

function bboxOf(node) {
  const b = new THREE.Box3();
  node.updateMatrixWorld(true);
  node.traverse((o) => { if (o.isMesh) { o.geometry.computeBoundingBox(); const c = o.geometry.boundingBox.clone().applyMatrix4(o.matrixWorld); b.union(c); } });
  return b;
}

for (const [slot, ids] of Object.entries(SLOTS)) {
  console.log(`\n── slot: ${slot} ──`);
  for (const id of ids) {
    const ch = new Character({
      faction: fac,
      lod: 'hero',
      loadout: {
        role: 'infantry',
        tier: 'medium',
        helm: slot === 'head' ? id : 'none',
        surcoat: false,
        weapon: slot === 'weapon' ? id : null,
        offhand: slot === 'offhand' || slot === 'shield' ? id : null,
        back: slot === 'back' ? id : null,
      },
    });
    const spec = ARMORY_CATALOG.find((s) => s.id === id);
    const jointName = slot === 'weapon' ? 'weaponR' : slot === 'shield' ? 'forearmL' : slot === 'offhand' ? 'weaponL' : slot === 'head' ? 'head' : 'chest';
    const joint = ch.rig.joint(jointName);
    const node = ch.group.children.length ? null : null;
    // takılı düğümü bul: eklem çocuğu olarak
    let equipped = null;
    joint.traverse((o) => { if (o.name && (o.name.includes('_hero') || o.name.startsWith(id))) equipped = o; });
    if (!equipped) { // grup isimleri id_lod şeklinde
      joint.children.forEach((c) => { if (c.name.startsWith(id)) equipped = c; });
    }
    const jw = new THREE.Vector3();
    joint.getWorldPosition(jw);
    if (!equipped) { console.log(`  ${id}: TAKILI DÜĞÜM BULUNAMADI`); continue; }
    const b = bboxOf(equipped);
    const c = b.getCenter(new THREE.Vector3());
    const gripLocal = spec ? new THREE.Vector3(...spec.attack.grip) : null;
    let gripWorld = null;
    if (gripLocal) { gripWorld = gripLocal.clone(); equipped.localToWorld(gripWorld); }
    const dGrip = gripWorld ? gripWorld.distanceTo(jw) : null;
    console.log(
      `  ${id.padEnd(13)} eklem(${jointName}) ${v(jw)} · merkez ${v(c)} · boy ${b.getSize(new THREE.Vector3()).toArray().map((x) => x.toFixed(2)).join('×')}` +
      (dGrip !== null ? ` · kabza-el mesafe ${dGrip.toFixed(3)} m` : ''),
    );
  }
}

import { Character, ROLE_PRESETS, countObject } from '../build/Character.js';
import { triCount } from '../build/Core.js';
import { unitBudget } from '../build/Army.js';
for (const lod of ['battle','crowd']) {
  for (const role of ['infantry','archer','sergeant','cavalry']) {
    const ch = new Character({ faction:'vlandia', lod, loadout: ROLE_PRESETS[role], seed: 5 });
    const baked = ch.bakeToGeometry();
    const lim = unitBudget(role, lod);
    const ok = triCount(baked) <= lim;
    console.log(`  ${role.padEnd(9)} ${lod.padEnd(7)} ham ${String(countObject(ch.group)).padStart(4)} -> bake ${String(Math.round(triCount(baked))).padStart(4)} / ${lim} ${ok?'✓':'✗'}`);
    ch.dispose();
  }
}

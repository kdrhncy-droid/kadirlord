import * as THREE from 'three';
import { sweep, shellSweep, profile2, v3 } from '../build/Core.js';

function signedVolume(g) {
  const gg = g.index ? g.toNonIndexed() : g;
  const p = gg.attributes.position;
  const a = new THREE.Vector3(), b = new THREE.Vector3(), c = new THREE.Vector3();
  let V = 0;
  for (let i = 0; i + 2 < p.count; i += 3) {
    a.fromBufferAttribute(p, i); b.fromBufferAttribute(p, i+1); c.fromBufferAttribute(p, i+2);
    V += a.dot(new THREE.Vector3().crossVectors(b, c)) / 6;
  }
  return V;
}
// Referans: THREE silindir (kesinlikle dışa bakan)
const ref = new THREE.CylinderGeometry(0.1, 0.1, 1, 8, 1);
console.log('THREE.Cylinder signedVolume =', signedVolume(ref).toFixed(5), '(>0 beklenir)');

const circle = profile2([[-0.1,0],[0,-0.1],[0.1,0],[0,0.1],[-0.1,0]]);
const spine = [v3(0,0,0), v3(0,0.5,0), v3(0,1,0)];
const s = sweep(circle, spine, {});
console.log('sweep(circle) signedVolume =', signedVolume(s).toFixed(5));

const s2 = sweep(circle, spine, { seedNormal: v3(1,0,0) });
console.log('sweep(seedNormal X) signedVolume =', signedVolume(s2).toFixed(5));

const s3 = sweep(circle, spine, { seedNormal: v3(0,0,1) });
console.log('sweep(seedNormal Z) signedVolume =', signedVolume(s3).toFixed(5));

const out = profile2([[-0.1,-0.1],[0.1,-0.1],[0.1,0.1],[-0.1,0.1]]);
const prof = profile2([[0,0],[0.05,0.02],[0.08,0]]);
const sh = shellSweep(out, prof);
console.log('shellSweep signedVolume =', signedVolume(sh).toFixed(5));

const lathe = new THREE.LatheGeometry(profile2([[0.1,-0.2],[0.15,0],[0.05,0.2],[0,0.22]]), 8);
console.log('LatheGeometry signedVolume =', signedVolume(lathe).toFixed(5));

const ex = new THREE.ExtrudeGeometry(new THREE.Shape([[-0.1,-0.1],[0.1,-0.1],[0.1,0.1],[-0.1,0.1]].map(p=>new THREE.Vector2(p[0],p[1]))), { depth: 0.2, bevelEnabled: false });
console.log('ExtrudeGeometry signedVolume =', signedVolume(ex).toFixed(5));

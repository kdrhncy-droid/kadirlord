import * as THREE from 'three';
import { buildArmorSet } from '../build/Armor.js';
import { reduceToBudget, triCount } from '../build/Core.js';
const set = buildArmorSet({ tier:'light', lod:'hero' });   // indirgeme çalışmaz (bütçe üstü değil)
const pieces = set.zones.armsUpper;
console.log('ham armsUpper parçaları:', pieces.map(p=>triCount(p.geometry)));
// elle birleştir
import { mergePieces, MaterialLibrary } from '../build/Core.js';
const lib = new MaterialLibrary({});
const merged = mergePieces(pieces.map(p=>{const g=p.geometry.clone(); if(p.position) g.translate(...p.position); return {geometry:g, material:p.material};}), lib);
console.log('birleşik tri:', triCount(merged));
merged.computeBoundingBox();
console.log('bbox:', merged.boundingBox.getSize(new THREE.Vector3()).toArray().map(x=>x.toFixed(3)));
for (const t of [30,25,20,18,15,10]) console.log(`  hedef ${t} ->`, triCount(reduceToBudget(merged.clone(), t)));

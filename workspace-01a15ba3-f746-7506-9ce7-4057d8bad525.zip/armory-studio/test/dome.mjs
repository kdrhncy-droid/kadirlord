import * as THREE from 'three';
import { domeShell, profile2 } from '../build/Core.js';
function sv(g){const gg=g.index?g.toNonIndexed():g;const p=gg.attributes.position;const a=new THREE.Vector3(),b=new THREE.Vector3(),c=new THREE.Vector3();let V=0;for(let i=0;i+2<p.count;i+=3){a.fromBufferAttribute(p,i);b.fromBufferAttribute(p,i+1);c.fromBufferAttribute(p,i+2);V+=a.dot(new THREE.Vector3().crossVectors(b,c))/6;}return V;}
const circ=[];for(let i=0;i<12;i++){const a=i/12*Math.PI*2;circ.push(new THREE.Vector2(Math.cos(a)*0.44,Math.sin(a)*0.44));}
const d=domeShell(circ,[[0,0.06],[0.5,0.05],[1,-0.01]],{cap:true});
d.computeBoundingBox();
console.log('domeShell bbox:', d.boundingBox.getSize(new THREE.Vector3()).toArray().map(x=>x.toFixed(3)).join(' x '), '| hacim', sv(d).toFixed(5), '| tri', d.index.count/3);

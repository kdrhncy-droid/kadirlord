import * as THREE from 'three';
import { mergePieces, MaterialLibrary, triCount } from '../build/Core.js';
import { buildArmorSet } from '../build/Armor.js';
const set = buildArmorSet({ tier:'light', lod:'hero' });
const merged = mergePieces(set.zones.armsUpper.map(p=>{const g=p.geometry.clone(); if(p.position) g.translate(...p.position); return {geometry:g, material:p.material};}), new MaterialLibrary({}));
const src = merged.index ? merged.toNonIndexed() : merged;
const pos = src.attributes.position, count = pos.count;
// PCA (basit)
let cx=0,cy=0,cz=0; for(let i=0;i<count;i++){cx+=pos.getX(i);cy+=pos.getY(i);cz+=pos.getZ(i);} cx/=count;cy/=count;cz/=count;
// eksenleri dünya ekseni varsay
const lx=new Float32Array(count),ly=new Float32Array(count),lz=new Float32Array(count);
let minX=1e9,minY=1e9,minZ=1e9,maxX=-1e9,maxY=-1e9,maxZ=-1e9;
for(let i=0;i<count;i++){const x=pos.getX(i),y=pos.getY(i),z=pos.getZ(i);lx[i]=x;ly[i]=y;lz[i]=z;
 if(x<minX)minX=x; if(x>maxX)maxX=x; if(y<minY)minY=y; if(y>maxY)maxY=y; if(z<minZ)minZ=z; if(z>maxZ)maxZ=z;}
const sx=maxX-minX, sy=maxY-minY, sz=maxZ-minZ;
console.log('span', sx.toFixed(3), sy.toFixed(3), sz.toFixed(3));
function cluster(cell){
  const nx=Math.max(1,Math.round(sx/cell)),ny=Math.max(1,Math.round(sy/cell)),nz=Math.max(1,Math.round(sz/cell));
  const N=nx*ny*nz; const cnt=new Int32Array(N); const remap=new Int32Array(count);
  for(let i=0;i<count;i++){
    const ix=Math.min(nx-1,Math.max(0,Math.floor(((lx[i]-minX)/sx)*nx)));
    const iy=Math.min(ny-1,Math.max(0,Math.floor(((ly[i]-minY)/sy)*ny)));
    const iz=Math.min(nz-1,Math.max(0,Math.floor(((lz[i]-minZ)/sz)*nz)));
    const key=(ix*ny+iy)*nz+iz; cnt[key]++; remap[i]=key;
  }
  const cent=new Int32Array(N).fill(-1); let next=0;
  for(let kk=0;kk<N;kk++) if(cnt[kk]>0) cent[kk]=next++;
  let tris=0;
  for(let t=0;t+2<count;t+=3){const a=cent[remap[t]],b=cent[remap[t+1]],c=cent[remap[t+2]];
    if(a<0||b<0||c<0)continue; if(a===b||b===c||a===c)continue; tris++;}
  return {tris, verts:next, nx,ny,nz};
}
let cell=0.002;
for(let i=0;i<22;i++){const r=cluster(cell); console.log(`cell ${cell.toFixed(4)} grid ${r.nx}x${r.ny}x${r.nz} verts ${r.verts} tri ${r.tris}`); cell*=1.16;}

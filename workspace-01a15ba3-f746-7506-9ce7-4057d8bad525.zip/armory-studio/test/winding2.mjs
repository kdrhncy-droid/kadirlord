import * as THREE from 'three';
import { sweep, shellSweep, profile2, v3 } from '../build/Core.js';
function sv(g){const gg=g.index?g.toNonIndexed():g;const p=gg.attributes.position;const a=new THREE.Vector3(),b=new THREE.Vector3(),c=new THREE.Vector3();let V=0;for(let i=0;i+2<p.count;i+=3){a.fromBufferAttribute(p,i);b.fromBufferAttribute(p,i+1);c.fromBufferAttribute(p,i+2);V+=a.dot(new THREE.Vector3().crossVectors(b,c))/6;}return V;}
const circle = profile2([[-0.1,0],[0,-0.1],[0.1,0],[0,0.1],[-0.1,0]]);
const spine = [v3(0,0,0), v3(0,0.5,0), v3(0,1,0)];
console.log('sweep caps=false :', sv(sweep(circle, spine, {capEnds:false})).toFixed(5));
console.log('sweep caps=true  :', sv(sweep(circle, spine, {capEnds:true})).toFixed(5));
const out = profile2([[-0.1,-0.1],[0.1,-0.1],[0.1,0.1],[-0.1,0.1]]);
const prof = profile2([[0,0],[0.05,0.02],[0.08,0]]);
console.log('shellSweep       :', sv(shellSweep(out, prof)).toFixed(5));
// ters eğri (bükülmüş omurga)
const sp2=[v3(0,0,0),v3(0.3,0.5,0),v3(0.9,0.8,0)];
console.log('sweep eğri omurga:', sv(sweep(circle, sp2, {})).toFixed(5));
// ölçek 0'a düşen (koni ucu)
console.log('sweep konik      :', sv(sweep(circle, spine, {scale:(t)=>1-t})).toFixed(5));

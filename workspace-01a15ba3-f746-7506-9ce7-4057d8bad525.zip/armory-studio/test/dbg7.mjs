import * as THREE from 'three';
import { reduceToBudget, triCount, mergePieces, MaterialLibrary } from '../build/Core.js';
import { buildArmorSet } from '../build/Armor.js';
const set = buildArmorSet({ tier:'light', lod:'hero' });
const pieces = set.zones.armsUpper;
const merged = mergePieces(pieces.map(p=>{const g=p.geometry.clone(); if(p.position) g.translate(...p.position); return {geometry:g, material:p.material};}), new MaterialLibrary({}));
// reduceToBudget'in içini taklit et
const src = merged.index ? merged.toNonIndexed() : merged;
const pos = src.attributes.position;
const count = pos.count;
let cx=0,cy=0,cz=0;
for(let i=0;i<count;i++){cx+=pos.getX(i);cy+=pos.getY(i);cz+=pos.getZ(i);}
cx/=count;cy/=count;cz/=count;
let m00=0,m01=0,m02=0,m11=0,m12=0,m22=0;
for(let i=0;i<count;i++){const x=pos.getX(i)-cx,y=pos.getY(i)-cy,z=pos.getZ(i)-cz;
 m00+=x*x;m01+=x*y;m02+=x*z;m11+=y*y;m12+=y*z;m22+=z*z;}
const k=1/count;
console.log('cov:', [m00*k,m01*k,m02*k,m11*k,m12*k,m22*k].map(v=>v.toExponential(2)).join(' '));
console.log('count', count, 'tri', count/3);

import * as THREE from 'three';
import { shellSweep, profile2, sweep, v3 } from '../build/Core.js';
function bbox(g){g.computeBoundingBox();const s=g.boundingBox.getSize(new THREE.Vector3());return `${s.x.toFixed(3)} x ${s.y.toFixed(3)} z ${s.z.toFixed(3)}`;}
// Dikdörtgen kontur: X 0.4 (-0.2..0.2), Y 0.6 (-0.3..0.3)
const rect = profile2([[-0.2,-0.3],[0.2,-0.3],[0.2,0.3],[-0.2,0.3]]);
const prof = profile2([[0,0.02],[0.06,0.05],[0.10,0.0]]);
const sh = shellSweep(rect, prof);
console.log('shellSweep dikdörtgen(0.4x0.6) + profil(0..0.10) ->', bbox(sh));
const sh2 = sweep(rect, [v3(0,0,0), v3(0,0,0.1)], {scale:()=>1});
console.log('sweep aynı kontur, omurga +Z 0.1 ->', bbox(sh2));

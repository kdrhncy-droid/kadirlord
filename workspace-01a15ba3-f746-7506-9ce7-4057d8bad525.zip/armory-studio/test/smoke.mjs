/**
 * BannerForge Engine · duman testi (Node)
 * Harici dosya yok; three.js node_modules'tan yüklenir.
 *   node test/smoke.mjs
 */
import * as THREE from 'three';
import { Armory, ARMORY_IDS, budgetFor } from '../build/src/Armory.js';
import { buildArmorSet, armorBudget } from '../build/src/Armor.js';
import { Character, ROLE_PRESETS, countObject } from '../build/src/Character.js';
import { Horse } from '../build/src/Horse.js';
import { BattleSim, unitBudget, bakeRigPose } from '../build/src/Army.js';
import { Rig, Animator, humanoidJoints } from '../build/src/Rig.js';
import { triCount, MaterialLibrary, BUDGET } from '../build/src/Core.js';

const problems = [];
const notes = [];

function checkNaN(name, geo) {
  const p = geo.attributes?.position;
  if (!p) { problems.push(`${name}: position attribute yok`); return; }
  for (let i = 0; i < p.array.length; i++) {
    if (!Number.isFinite(p.array[i])) { problems.push(`${name}: NaN/Inf @${i}`); return; }
  }
  const nrm = geo.attributes?.normal;
  if (nrm) {
    for (let i = 0; i < nrm.array.length; i++) {
      if (!Number.isFinite(nrm.array[i])) { problems.push(`${name}: normal NaN @${i}`); return; }
    }
  }
}
function tri(geo) { return Math.round(triCount(geo)); }
function size(geo) {
  geo.computeBoundingBox();
  const s = geo.boundingBox.getSize(new THREE.Vector3());
  return `${s.x.toFixed(2)}×${s.y.toFixed(2)}×${s.z.toFixed(2)}`;
}
/** Yönlendirilmiş hacim > 0 → üçgen sarımı dışa bakıyor (kapalı mesh'lerde). */
function outwardRatio(geo) {
  const g = geo.index ? geo.toNonIndexed() : geo;
  const p = g.attributes.position;
  if (!p) return 1;
  const a = new THREE.Vector3(), b = new THREE.Vector3(), c = new THREE.Vector3();
  let V = 0;
  for (let i = 0; i + 2 < p.count; i += 3) {
    a.fromBufferAttribute(p, i); b.fromBufferAttribute(p, i + 1); c.fromBufferAttribute(p, i + 2);
    V += a.dot(new THREE.Vector3().crossVectors(b, c)) / 6;
  }
  return V;
}

const line = (t) => console.log(t);

/** Tamamen kapalı hacim üreten ekipmanlar (yönlendirilmiş hacim testi geçerli). */
const CLOSED_MESHES = new Set(['gladius', 'greatsword', 'scimitar', 'warAxe', 'bardiche', 'halberd', 'arrow', 'vikingShield']);

/* ═══════════ 1) ARMORY ═══════════ */
line('═══ 1) ARMORY · 22 ekipman × 3 LOD (bütçe: silah+kalkan 60–150) ═══');
for (const fac of ['vlandia', 'khuzait']) {
  const armory = new Armory(fac, { seed: 7 });
  for (const lod of ['hero', 'battle', 'crowd']) {
    line(`── ${fac} / ${lod} ──`);
    for (const id of ARMORY_IDS) {
      const item = armory.buildItem(id, lod);
      checkNaN(`${id}/${lod}`, item.merged);
      const budget = budgetFor(id, lod);
      const ok = item.triangles <= budget;
      if (!ok) problems.push(`${id}/${lod}: ${item.triangles} > ${budget} üçgen`);
      // Hacim testi yalnızca KAPALI hacimler için anlamlı. Kalkanlar (ön+arka
      // kabuk), miğfer astarı, zırh gövdeleri ve sancaklar açık/çift taraflı
      // yüzeyler içerir → bunlar tarayıcıda görsel doğrulanır.
      if (CLOSED_MESHES.has(id)) {
        const vol = outwardRatio(item.merged);
        if (vol < 0) problems.push(`${id}/${lod}: içe dönük sarım (hacim ${vol.toFixed(4)})`);
      }
      line(`  ${id.padEnd(13)} ${String(item.triangles).padStart(4)}/${String(budget).padStart(4)} ${ok ? '✓' : '✗'}  boyut ${size(item.merged)} m  ${item.spec.name}`);
    }
  }
}

/* ═══════════ 2) KARAKTER ═══════════ */
line('\n═══ 2) KARAKTER · rol × LOD (Bölüm 1: tam donanımlı piyade 400–800) ═══');
for (const lod of ['hero', 'battle', 'crowd']) {
  for (const role of ['infantry', 'archer', 'cavalry', 'sergeant']) {
    const ch = new Character({ faction: 'sturgia', lod, loadout: ROLE_PRESETS[role], seed: 3 });
    const lim = unitBudget(role, lod);
    const ok = ch.triangles <= lim;
    if (!ok) problems.push(`character ${role}/${lod}: ${ch.triangles} > ${lim}`);
    checkNaN(`bake ${role}/${lod}`, ch.bakeToGeometry());
    line(`  ${role.padEnd(9)} ${lod.padEnd(7)} çizilen ${String(ch.triangles).padStart(4)}/${String(lim).padStart(4)} ${ok ? '✓' : '✗'}   (vitrin ham: ${ch.rawTriangles})`);
    ch.dispose();
  }
}

/* ═══════════ 3) ZIRH SETLERİ ═══════════ */
line('\n═══ 3) ZIRH SETLERİ (ham kalite; bütçe karakter düzeyinde uygulanır) ═══');
for (const tier of ['light', 'medium', 'heavy']) {
  for (const lod of ['hero', 'battle', 'crowd']) {
    const set = buildArmorSet({
      tier, lod,
      helmStyle: tier === 'heavy' ? 'greatHelm' : tier === 'medium' ? 'spangen' : 'kettle',
    });
    let real = 0;
    for (const z of Object.keys(set.zones)) for (const p of set.zones[z]) { checkNaN(`armor ${tier}/${lod}/${z}`, p.geometry); real += tri(p.geometry); }
    if (real !== set.triangles) problems.push(`armor ${tier}/${lod}: rapor ${set.triangles} ≠ gerçek ${real}`);
    line(`  ${tier.padEnd(7)} ${lod.padEnd(7)} ${String(set.triangles).padStart(4)} üçgen · referans pay ${armorBudget(tier, lod)} · bölge ${Object.keys(set.zones).length}`);
  }
}

/* ═══════════ 4) AT ═══════════ */
line('\n═══ 4) AT · zırhlı savaş atı (Bölüm 1: 500–900) ═══');
for (const lod of ['hero', 'battle', 'crowd']) {
  for (const barding of [false, true]) {
    const h = new Horse({ lod, barding, caparison: barding, faction: 'khuzait', seed: 5 });
    const lim = lod === 'hero' ? BUDGET.horseMax : Math.round(BUDGET.horseMax * (lod === 'crowd' ? 0.72 : 1));
    const ok = h.triangles <= lim;
    if (!ok) problems.push(`horse ${lod} barding=${barding}: ${h.triangles} > ${lim}`);
    const g = h.bakeToGeometry();
    checkNaN(`horse ${lod}/${barding}`, g);
    if (!barding && outwardRatio(g) < 0) problems.push(`horse ${lod}: içe dönük sarım`);
    line(`  ${lod.padEnd(7)} barding=${String(barding).padEnd(5)} çizilen ${String(h.triangles).padStart(4)}/${lim} ${ok ? '✓' : '✗'}  (ham ${h.rawTriangles})  boyut ${size(g)} m`);
    h.dispose();
  }
}

/* ═══════════ 5) SÜVARİ (at + binici tek bake) ═══════════ */
line('\n═══ 5) SÜVARİ · at + binici tek geometride (limit 800+900=1700) ═══');
for (const lod of ['battle', 'crowd']) {
  const h = new Horse({ lod, barding: true, caparison: true, faction: 'vlandia', seed: 9 });
  const rider = new Character({ faction: 'vlandia', lod, loadout: ROLE_PRESETS.cavalry, seed: 9 });
  h.attachRider(rider);
  h.update(0.3);
  const g = h.bakeToGeometry(unitBudget('cavalry', lod));
  checkNaN(`cavalry ${lod}`, g);
  const lim = unitBudget('cavalry', lod);
  const t = tri(g);
  if (t > lim) problems.push(`cavalry ${lod}: ${t} > ${lim}`);
  line(`  ${lod.padEnd(7)} ${String(t).padStart(4)}/${lim} ${t <= lim ? '✓' : '✗'}  boyut ${size(g)} m  hacim ${outwardRatio(g).toFixed(3)}`);
  h.dispose();
}

/* ═══════════ 6) RIG / ANİMASYON ═══════════ */
line('\n═══ 6) RIG · animasyon klipleri NaN/sonsuz kontrolü ═══');
{
  const rig = new Rig(humanoidJoints());
  const anim = new Animator();
  let samples = 0;
  for (const clip of anim.list()) {
    for (const t of [0, 0.11, 0.37, 1.1, 2.5]) {
      for (const spd of [0.4, 1, 2.4]) {
        const pose = anim.evaluate(clip, t, { phase: 0.31, speed: spd, seed: 3, power: 1, handedness: -1, mounted: false });
        rig.applyPose(pose, true);
        rig.root.updateMatrixWorld(true);
        rig.joints.forEach((j, name) => {
          for (const v of j.matrixWorld.elements) {
            if (!Number.isFinite(v)) problems.push(`rig ${clip}@${t} spd=${spd} ${name}: sonlu olmayan matris`);
          }
        });
        samples++;
      }
    }
  }
  const root = rig.jointWorldPosition('head');
  if (!root || !Number.isFinite(root.y)) problems.push('rig: head dünya konumu geçersiz');
  line(`  ${anim.list().length} klip × 5 zaman × 3 hız = ${samples} poz örneği ✓`);
  line(`  klip listesi: ${anim.list().join(', ')}`);
  line(`  head dünya konumu: ${root.x.toFixed(2)}, ${root.y.toFixed(2)}, ${root.z.toFixed(2)} m (beklenen ≈ 0, 1.66, 0)`);
  rig.dispose();
}

/* ═══════════ 7) 500v500 SAVAŞ ═══════════ */
line('\n═══ 7) 500v500 MEYDAN SAVAŞI (InstancedMesh) ═══');
{
  const mk = (faction, seed) => ({
    faction, seed, lod: 'crowd', phases: 3,
    counts: { infantry: 380, archer: 90, sergeant: 16, banner: 6, cavalry: 8 },
  });
  const t0 = Date.now();
  const sim = new BattleSim({ armies: [mk('vlandia', 11), mk('khuzait', 22)], seed: 99 });
  const buildMs = Date.now() - t0;
  const s0 = sim.stats();
  const totalUnits = s0.armies[0].units + s0.armies[1].units;
  line(`  kurulum: ${buildMs} ms · toplam birim ${totalUnits} · varyant ${s0.armies[0].variants + s0.armies[1].variants} (draw-call)`);
  line('  rol başına çizilen üçgen (limit: piyade 576, süvari 1224 @crowd):');
  for (const army of s0.armies) {
    for (const [role, t] of Object.entries(army.trianglesPerRole)) {
      const lim = unitBudget(role, 'crowd');
      if (t > lim) problems.push(`crowd ${role}: ${t} > ${lim} üçgen`);
      if (t === 0) problems.push(`crowd ${role}: bake boş (0 üçgen)`);
      line(`    ${role.padEnd(9)} ${String(t).padStart(5)}/${String(lim).padStart(5)} ${t <= lim ? '✓' : '✗'}`);
    }
  }

  let frames = 0; const t1 = Date.now(); let maxMs = 0; let sumMs = 0;
  while (Date.now() - t1 < 4000) {
    const a = process.hrtime.bigint();
    sim.update(1 / 60);
    const ms = Number(process.hrtime.bigint() - a) / 1e6;
    if (ms > maxMs) maxMs = ms;
    sumMs += ms;
    frames++;
  }
  const st = sim.stats();
  line(`  ${frames} kare · ort ${(sumMs / frames).toFixed(2)} ms · en yavaş ${maxMs.toFixed(2)} ms · faz: ${st.phase}`);
  line(`  hayatta: ${st.armies[0].alive}/${s0.armies[0].units} (A)  vs  ${st.armies[1].alive}/${s0.armies[1].units} (B) · uçuşan ok ${st.arrowsInFlight}`);
  line(`  render üçgeni: ${(st.armies[0].totalTrianglesRendered + st.armies[1].totalTrianglesRendered).toLocaleString('tr-TR')} · instance ${st.armies[0].instances + st.armies[1].instances}`);
  if (sumMs / frames > 8) notes.push(`simülasyon kare maliyeti ${(sumMs / frames).toFixed(2)} ms — 60 fps için 16 ms bütçesinin ~%${Math.round((sumMs / frames) / 16 * 100)}'i`);
  sim.dispose();
}

/* ═══════════ SONUÇ ═══════════ */
line('\n═══ SONUÇ ═══');
if (notes.length) { line('Notlar:'); notes.forEach((n) => line('  · ' + n)); }
if (problems.length === 0) {
  line('✓ Tüm kontroller geçti: NaN yok, sarım dışa bakıyor, tüm bütçeler tutuyor.');
  process.exit(0);
} else {
  line(`✗ ${problems.length} sorun:`);
  const uniq = [...new Set(problems)];
  uniq.slice(0, 60).forEach((p) => line('  - ' + p));
  process.exit(1);
}

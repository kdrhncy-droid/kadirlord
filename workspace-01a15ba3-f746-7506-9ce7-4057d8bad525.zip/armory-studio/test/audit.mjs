/**
 * audit.mjs — her ekipmanı hero LOD'da üretip parça bağlanırlığını denetler.
 * Bir parça, diğer hiçbir parçaya değmiyorsa (eps içinde) "kopuk" sayılır:
 * bu, havada asılı kayış / gövdeden kopuk başlık gibi hataları yakalar.
 */
import * as THREE from 'three';
import { Armory, ARMORY_IDS } from '../build/src/Armory.js';
import { FactionPalette } from '../build/src/Faction.js';

const EPS = 0.006; // 6 mm temas toleransı
const factions = ['vlandia', 'kuzait'];
let sorun = 0;

function boxOf(mesh) {
  const g = mesh.geometry;
  g.computeBoundingBox();
  const b = g.boundingBox.clone();
  b.applyMatrix4(mesh.matrix);
  return b;
}

function touches(a, b, eps) {
  return (
    a.min.x - eps <= b.max.x && b.min.x - eps <= a.max.x &&
    a.min.y - eps <= b.max.y && b.min.y - eps <= a.max.y &&
    a.min.z - eps <= b.max.z && b.min.z - eps <= a.max.z
  );
}

for (const faction of factions) {
  const armory = new Armory(FactionPalette.byId(faction), { seed: 7 });
  for (const id of ARMORY_IDS) {
    const item = armory.buildItem(id, 'hero');
    item.group.updateMatrixWorld(true);
    const meshes = [];
    item.group.traverse((o) => { if (o.isMesh) meshes.push(o); });
    const boxes = meshes.map(boxOf);

    // birleşiklik: aynı bileşendeki parçalar
    const parent = meshes.map((_, i) => i);
    const find = (i) => (parent[i] === i ? i : (parent[i] = find(parent[i])));
    const union = (a, b) => { parent[find(a)] = find(b); };
    for (let i = 0; i < boxes.length; i++)
      for (let j = i + 1; j < boxes.length; j++)
        if (touches(boxes[i], boxes[j], EPS)) union(i, j);

    const compSize = new Map();
    for (let i = 0; i < meshes.length; i++) {
      const r = find(i);
      compSize.set(r, (compSize.get(r) ?? 0) + 1);
    }
    const main = [...compSize.entries()].sort((a, b) => b[1] - a[1])[0];
    const floaters = meshes
      .map((m, i) => ({ m, i }))
      .filter(({ i }) => find(i) !== main[0] && compSize.get(find(i)) === 1);

    // NaN taraması
    const pos = item.merged.attributes.position;
    let nan = 0;
    for (let i = 0; i < pos.count * 3; i++) if (!Number.isFinite(pos.array[i])) nan++;

    if (floaters.length || nan) {
      sorun++;
      console.log(`✗ ${faction}/${id}: ${floaters.length ? 'kopuk parça: ' + floaters.map((f) => f.m.name || f.m.geometry.type).join(', ') : ''}${nan ? ` · NaN:${nan}` : ''}`);
      for (const f of floaters) {
        const b = boxes[f.i];
        console.log(`    bbox [${b.min.x.toFixed(3)},${b.min.y.toFixed(3)},${b.min.z.toFixed(3)}] → [${b.max.x.toFixed(3)},${b.max.y.toFixed(3)},${b.max.z.toFixed(3)}]`);
      }
    }
  }
}
console.log(sorun === 0 ? '✓ tüm parçalar gövdeye bağlı, NaN yok' : `${sorun} eşyada sorun`);

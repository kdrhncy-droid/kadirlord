import { buildArmorSet, armorBudget } from '../build/Armor.js';
import { triCount } from '../build/Core.js';
const set = buildArmorSet({ tier:'light', lod:'battle' });
console.log('set.triangles =', set.triangles, 'budget =', armorBudget('light','battle'));
let actual = 0;
for (const z of Object.keys(set.zones)) for (const p of set.zones[z]) actual += triCount(p.geometry);
console.log('parçaların gerçek toplamı =', actual);
for (const z of Object.keys(set.zones)) {
  const t = set.zones[z].reduce((a,p)=>a+triCount(p.geometry),0);
  console.log('  ', z.padEnd(10), set.zones[z].length, 'parça', t, 'üçgen');
}

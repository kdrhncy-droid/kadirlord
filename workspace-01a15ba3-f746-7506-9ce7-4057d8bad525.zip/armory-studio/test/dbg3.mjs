import * as THREE from 'three';
import { reduceToBudget, triCount } from '../build/Core.js';
const g = new THREE.SphereGeometry(0.2, 16, 12);
console.log('kaynak tri:', triCount(g));
const r = reduceToBudget(g, 40);
console.log('indirgenmiş tri:', triCount(r), 'aynı nesne mi:', r === g);
const box = new THREE.BoxGeometry(0.3, 0.5, 0.2, 4, 6, 4);
console.log('box tri:', triCount(box), '->', triCount(reduceToBudget(box, 30)));

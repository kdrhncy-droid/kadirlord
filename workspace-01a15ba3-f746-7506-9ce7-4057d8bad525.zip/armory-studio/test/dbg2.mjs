import * as THREE from 'three';
import { Character, ROLE_PRESETS } from '../build/Character.js';
import { mergePieces, triCount, reduceToBudget } from '../build/Core.js';
const ch = new Character({ faction:'vlandia', lod:'crowd', loadout: ROLE_PRESETS.infantry, seed: 5 });
const rig = ch.rig;
rig.applyPose(ch.animator.evaluate('walk',0.5,{phase:0.5,speed:1}), true);
rig.root.updateMatrixWorld(true);
ch.group.updateMatrixWorld(true);
const rootMat = rig.joints.get('root')?.matrixWorld ?? rig.root.matrixWorld;
console.log('rootMat pozisyon:', rootMat.elements.slice(12,15));
const rootInv = new THREE.Matrix4().copy(rootMat).invert();
const excluded = new Set([rig.joints.get('root')]);
console.log('rig.root === joints.get(root):', rig.root === rig.joints.get('root'));
let found=0, skipped=0;
const m = new THREE.Matrix4();
const pieces=[];
ch.group.traverse(o=>{
  if(!o.isMesh || !o.geometry) return;
  let cur=o, skip=false;
  while(cur){ if(excluded.has(cur)){skip=true;break;} cur=cur.parent; }
  if(skip){skipped++;return;}
  found++;
  m.multiplyMatrices(rootInv, o.matrixWorld);
  const g=o.geometry.clone(); g.applyMatrix4(m);
  const mat=o.material;
  pieces.push({geometry:g, material:{key:'bake', color: mat.color?mat.color.getHex():0xffffff, metalness:mat.metalness??0.15, roughness:mat.roughness??0.85, flatShading:true, side:mat.side??THREE.FrontSide}});
});
console.log('bulunan mesh:', found, 'atlanan:', skipped);
const merged = mergePieces(pieces, ch.mats);
console.log('merged tri:', triCount(merged));
const red = reduceToBudget(merged, 800);
console.log('reduced tri:', triCount(red));

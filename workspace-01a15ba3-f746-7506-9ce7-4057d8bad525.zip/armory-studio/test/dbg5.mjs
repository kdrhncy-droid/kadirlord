import * as THREE from 'three';
import { reduceToBudget, triCount, profile2 } from '../build/Core.js';
const lathe = new THREE.LatheGeometry(profile2([[0.175,0.3],[0.2,0.25],[0.212,0.14],[0.208,0.02],[0.19,-0.1],[0.178,-0.2]]), 6);
console.log('lathe tri:', triCount(lathe));
console.log('reduce->11:', triCount(reduceToBudget(lathe, 11)));
const torus = new THREE.TorusGeometry(0.192, 0.024, 3, 6);
console.log('torus tri:', triCount(torus), '-> reduce 7:', triCount(reduceToBudget(torus, 7)));
const cone = new THREE.ConeGeometry(0.02,0.05,4);
console.log('cone tri:', triCount(cone), '-> reduce 6:', triCount(reduceToBudget(cone, 6)));

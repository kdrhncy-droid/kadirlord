/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BANNERFORGE STUDIO · demo/app.ts
 *  Motorun vitrini: 4 görünüm (Vitrin · Karakter Laboratuvarı · İnstans/LOD ·
 *  500v500 Meydan Savaşı), tamamen prosedürel sahne, Türkçe arayüz.
 *
 *  Bu dosya src/*.ts ile birlikte tools/build_html.js tarafından TEK bir
 *  armory-studio.html dosyasına gömülür (three.js CDN importmap'ten gelir).
 * ═══════════════════════════════════════════════════════════════════════════
 */

import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

import {
  BUDGET,
  DEG,
  clamp,
  LodLevel,
  MATERIAL_STANDARD,
  TAU,
} from '../src/Core.js';
import {
  ARMORY_CATALOG,
  ARMORY_IDS,
  Armory,
  ArmoryItemId,
  AttackAnimType,
  budgetFor,
} from '../src/Armory.js';
import { ChargeType, FACTIONS, FactionPalette, HERALDRY_CATALOG } from '../src/Faction.js';
import { ANIMATION_CLIPS } from '../src/Rig.js';
import { Character, ROLE_PRESETS, UnitRole } from '../src/Character.js';
import { CoatColor, Horse, HORSE_BREEDS, HorseBreed } from '../src/Horse.js';
import { ArmyConfig, BattleSim } from '../src/Army.js';
import { BattleSoundFX } from '../src/BattleSoundFX.js';

/* ═══════════════════════════════════════════════════════════════════════
   0) DURUM (state)
   ═══════════════════════════════════════════════════════════════════════ */

type ViewId = 'vitrin' | 'laboratuvar' | 'instans' | 'savas';
type AttackSoundName = 'swordClash' | 'shieldBlock' | 'bowRelease' | 'arrowHit' | 'heavyAxeSwing' | 'battleHorn';

interface SoundInfo {
  id: AttackSoundName;
  ad: string;
  aciklama: string;
  tus: string;
}

/** Kullanıcının test edebileceği 6 savaş sesi. */
const SESLER: SoundInfo[] = [
  { id: 'swordClash', ad: 'Kılıç Çarpışması', aciklama: 'FM sentez + uyumsuz metalik kısmiler', tus: 'S' },
  { id: 'shieldBlock', ad: 'Kalkan Bloğu', aciklama: 'Alçak geçiren tok darbe + demir tınısı', tus: 'D' },
  { id: 'bowRelease', ad: 'Yay Bırakma', aciklama: 'Kiriş twang + stereo whoosh', tus: 'F' },
  { id: 'arrowHit', ad: 'Ok İsabeti', aciklama: 'Ahşap thock + kıymık + zırh ping', tus: 'G' },
  { id: 'heavyAxeSwing', ad: 'Ağır Balta Savurma', aciklama: 'Süpürülen whoosh + sap gıcırtısı', tus: 'H' },
  { id: 'battleHorn', ad: 'Savaş Borazanı', aciklama: '3 testere katmanı + pirinç shaper + eko', tus: 'J' },
];

const ROLLER: { id: UnitRole; ad: string }[] = [
  { id: 'infantry', ad: 'Piyade' },
  { id: 'archer', ad: 'Okçu' },
  { id: 'cavalry', ad: 'Süvari' },
  { id: 'sergeant', ad: 'Çavuş' },
  { id: 'banner', ad: 'Sancaktar' },
];

const TIERS = [
  { id: 'light', ad: 'Hafif' },
  { id: 'medium', ad: 'Orta' },
  { id: 'heavy', ad: 'Ağır' },
] as const;

const HELMS = [
  { id: 'greatHelm', ad: 'Kapalı miğfer' },
  { id: 'spangen', ad: 'Boynuzlu/Spangen' },
  { id: 'kettle', ad: 'Kettle şapka' },
  { id: 'none', ad: 'Baş açık' },
] as const;

const LODLAR: { id: LodLevel; ad: string }[] = [
  { id: 'hero', ad: 'Hero (vitrin)' },
  { id: 'battle', ad: 'Battle (60–150 üçgen)' },
  { id: 'crowd', ad: 'Crowd (kalabalık)' },
];

/** Saldırı tipi → animasyon klibi. */
function clipForAttack(type: AttackAnimType): string {
  switch (type) {
    case 'thrust': return 'attackThrust';
    case 'chop':
    case 'bash': return 'attackAxe';
    case 'draw': return 'shootBow';
    case 'raise': return 'block';
    default: return 'attackSword';
  }
}

/* ── küresel sahne durumu ── */
let renderer!: THREE.WebGLRenderer;
let scene!: THREE.Scene;
let camera!: THREE.PerspectiveCamera;
let controls!: OrbitControls;
let keyLight!: THREE.DirectionalLight;
let rimLight!: THREE.DirectionalLight;
let hemiLight!: THREE.HemisphereLight;
let torchA!: THREE.PointLight;
let torchB!: THREE.PointLight;
let dust!: THREE.Points;
let dustVel!: Float32Array;
let ground!: THREE.Mesh;
let arena!: THREE.Group;

let sfx!: BattleSoundFX;
let audioUnlocked = false;

let currentView = '' as ViewId;
let clock = new THREE.Clock();
let fpsSmooth = 60;
let frameCount = 0;
let autoRotate = true;
let wireframe = false;
let useMerged = true;
let dustEnabled = true;

/* ── görünüm kökleri ── */
let vitrinRoot!: THREE.Group;
let labRoot!: THREE.Group;
let instansRoot!: THREE.Group;
let savasRoot!: THREE.Group;

/* ── vitrin durumu ── */
interface VitrinItem {
  id: ArmoryItemId;
  stand: THREE.Group;
  heroGroup: THREE.Group;
  mergedMesh: THREE.Mesh;
  merged: THREE.BufferGeometry;
  triangles: number;
  budget: number;
  angle: number;
  baseY: number;
  spin: number;
}
let vitrinItems: VitrinItem[] = [];
let vitrinArmory!: Armory;
let selectedItemId: ArmoryItemId = 'gladius';
let inspectMode = false;
let vitrinDais!: THREE.Mesh;
let vitrinRune!: THREE.Mesh;

/* ── laboratuvar durumu ── */
let labCharacter: Character | null = null;
let labHorse: Horse | null = null;
let labArmory!: Armory;
let labAttackNode: THREE.Group | null = null;
let labState = {
  role: 'infantry' as UnitRole,
  faction: 'vlandia',
  tier: 'medium' as 'light' | 'medium' | 'heavy',
  helm: 'spangen' as 'greatHelm' | 'spangen' | 'kettle' | 'none',
  weapon: 'gladius' as ArmoryItemId | '',
  offhand: 'vikingShield' as ArmoryItemId | '',
  back: '' as ArmoryItemId | 'arrow' | '',
  surcoat: true,
  breed: 'war' as HorseBreed,
  lod: 'hero' as LodLevel,
  clip: 'idle',
  speed: 1,
};

/* ── instans durumu ── */
let instansMeshes: THREE.InstancedMesh[] = [];
let instansState = { item: 'gladius' as ArmoryItemId, count: 120, compare: true };
let instansArmory!: Armory;
let instansSpin = 0;

/* ── savaş durumu ── */
let battle: BattleSim | null = null;
let battleState = {
  factionA: 'vlandia',
  factionB: 'khuzait',
  size: 500,
  running: false,
  cameraMode: 'serbest' as 'serbest' | 'takip' | 'kusbakisi',
  lastHorn: 0,
};
let battleSoundsAt = 0;

/* ── efekt havuzları ── */
interface Spark {
  mesh: THREE.Points;
  vel: Float32Array;
  life: number;
  maxLife: number;
}
let sparks: Spark[] = [];
let shockwaves: { mesh: THREE.Mesh; life: number }[] = [];

/* ═══════════════════════════════════════════════════════════════════════
   1) YARDIMCILAR
   ═══════════════════════════════════════════════════════════════════════ */

function $(id: string): HTMLElement {
  const el = document.getElementById(id);
  if (!el) throw new Error(`[UI] #${id} bulunamadı`);
  return el;
}
function $btn(id: string): HTMLButtonElement {
  return $(id) as HTMLButtonElement;
}
function $select(id: string): HTMLSelectElement {
  return $(id) as HTMLSelectElement;
}
function $range(id: string): HTMLInputElement {
  return $(id) as HTMLInputElement;
}
function $check(id: string): HTMLInputElement {
  return $(id) as HTMLInputElement;
}
function show(el: HTMLElement, on: boolean): void {
  el.classList.toggle('gizli', !on);
}
function fmt(n: number): string {
  return n.toLocaleString('tr-TR');
}

/** Basit deterministik PRNG (sahne detayları için). */
function rngFrom(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Canvas dokusu üretici (yer zemini, rune dairesi, gökyüzü). */
function canvasTexture(size: number, draw: (ctx: CanvasRenderingContext2D, s: number) => void, repeat = 1): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d');
  if (!ctx) throw new Error('[Bannerforge] 2D bağlam alınamadı');
  draw(ctx, size);
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeat, repeat);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

/** Uyarı şeridi (CDN/WebGL hataları için). */
let uyariTimer = 0;
function uyari(mesaj: string, sure = 6000): void {
  const el = $('uyari');
  el.textContent = mesaj;
  show(el, true);
  window.clearTimeout(uyariTimer);
  uyariTimer = window.setTimeout(() => show(el, false), sure);
}

/** Bir gruptaki tüm materyalleri telkafes/saydam yap. */
function applyMaterialFlags(root: THREE.Object3D, opts: { wire?: boolean; opacity?: number }): void {
  root.traverse((o) => {
    const mesh = o as THREE.Mesh;
    if (!mesh.isMesh) return;
    const list = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
    for (const mat of list) {
      const m = mat as THREE.MeshStandardMaterial;
      if (!m || m.type !== 'MeshStandardMaterial') continue;
      m.wireframe = !!opts.wire;
      const targetOpacity = opts.opacity ?? 1;
      if (targetOpacity < 1) {
        m.transparent = true;
        m.opacity = targetOpacity;
        m.depthWrite = targetOpacity > 0.9;
      } else {
        m.transparent = false;
        m.opacity = 1;
        m.depthWrite = true;
      }
      m.needsUpdate = true;
    }
  });
}

/* ═══════════════════════════════════════════════════════════════════════
   2) SAHNE KURULUMU
   ═══════════════════════════════════════════════════════════════════════ */

function initRenderer(): void {
  const canvas = $('tuval') as HTMLCanvasElement;
  renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    powerPreference: 'high-performance',
    alpha: false,
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.setSize(canvas.clientWidth || window.innerWidth, canvas.clientHeight || window.innerHeight, false);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.06;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x1b2029);
  scene.fog = new THREE.Fog(0x232a35, 26, 130);

  camera = new THREE.PerspectiveCamera(46, 16 / 9, 0.08, 400);
  camera.position.set(3.4, 2.1, 5.4);

  controls = new OrbitControls(camera, canvas);
  controls.enableDamping = true;
  controls.dampingFactor = 0.075;
  controls.minDistance = 0.7;
  controls.maxDistance = 130;
  controls.maxPolarAngle = 96 * DEG;
  controls.target.set(0, 1.0, 0);
  controls.autoRotateSpeed = 0.55;
}

function buildSky(): void {
  // Dikey degrade gökyüzü kubbesi (shader, harici dosya yok)
  const geo = new THREE.SphereGeometry(190, 20, 12);
  const mat = new THREE.ShaderMaterial({
    side: THREE.BackSide,
    depthWrite: false,
    fog: false,
    uniforms: {
      ustRenk: { value: new THREE.Color(0x141a26) },
      ortaRenk: { value: new THREE.Color(0x3a3226) },
      altRenk: { value: new THREE.Color(0x6b4a24) },
    },
    vertexShader: `
      varying float vY;
      void main() {
        vY = normalize(position).y;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      uniform vec3 ustRenk;
      uniform vec3 ortaRenk;
      uniform vec3 altRenk;
      varying float vY;
      void main() {
        float t = clamp(vY * 0.5 + 0.5, 0.0, 1.0);
        vec3 col = mix(altRenk, ortaRenk, smoothstep(0.30, 0.52, t));
        col = mix(col, ustRenk, smoothstep(0.50, 0.88, t));
        gl_FragColor = vec4(col, 1.0);
      }
    `,
  });
  const sky = new THREE.Mesh(geo, mat);
  sky.name = 'gokyuzu';
  sky.frustumCulled = false;
  scene.add(sky);
}

function buildLights(): void {
  hemiLight = new THREE.HemisphereLight(0x9fb4d8, 0x3a2c1c, 0.62);
  scene.add(hemiLight);

  keyLight = new THREE.DirectionalLight(0xffe2b0, 2.05);
  keyLight.position.set(7.5, 12.5, 6.5);
  keyLight.castShadow = true;
  keyLight.shadow.mapSize.set(2048, 2048);
  keyLight.shadow.camera.near = 0.5;
  keyLight.shadow.camera.far = 60;
  keyLight.shadow.camera.left = -16;
  keyLight.shadow.camera.right = 16;
  keyLight.shadow.camera.top = 16;
  keyLight.shadow.camera.bottom = -16;
  keyLight.shadow.bias = -0.0009;
  keyLight.shadow.normalBias = 0.022;
  scene.add(keyLight);
  scene.add(keyLight.target);

  rimLight = new THREE.DirectionalLight(0x7fa8ff, 0.85);
  rimLight.position.set(-8, 5.5, -7);
  scene.add(rimLight);

  const fill = new THREE.DirectionalLight(0xffd7a0, 0.28);
  fill.position.set(-3, 3, 8);
  scene.add(fill);

  torchA = new THREE.PointLight(0xff9b45, 12, 16, 2);
  torchA.position.set(-4.6, 2.5, 2.4);
  scene.add(torchA);
  torchB = new THREE.PointLight(0xff8a30, 12, 16, 2);
  torchB.position.set(4.6, 2.5, -2.4);
  scene.add(torchB);
}

function buildGround(): void {
  const tex = canvasTexture(512, (ctx, s) => {
    const rng = rngFrom(9091);
    ctx.fillStyle = '#4a4237';
    ctx.fillRect(0, 0, s, s);
    // toprak lekeleri
    for (let i = 0; i < 2600; i++) {
      const x = rng() * s;
      const y = rng() * s;
      const r = 1 + rng() * 9;
      const l = 24 + rng() * 34;
      ctx.fillStyle = `hsl(${28 + rng() * 16} ${16 + rng() * 18}% ${l * 0.55}%)`;
      ctx.globalAlpha = 0.1 + rng() * 0.28;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, TAU);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
    // çakıl
    for (let i = 0; i < 700; i++) {
      const x = rng() * s;
      const y = rng() * s;
      ctx.fillStyle = `rgba(${170 + rng() * 60},${160 + rng() * 50},${140 + rng() * 40},${0.08 + rng() * 0.2})`;
      ctx.beginPath();
      ctx.ellipse(x, y, 1 + rng() * 2.6, 0.8 + rng() * 2, rng() * TAU, 0, TAU);
      ctx.fill();
    }
  }, 14);

  const geo = new THREE.CircleGeometry(120, 40);
  geo.rotateX(-90 * DEG);
  const mat = new THREE.MeshStandardMaterial({
    ...MATERIAL_STANDARD,
    map: tex,
    color: 0xb9ab93,
    roughness: 0.98,
    metalness: 0.02,
  });
  ground = new THREE.Mesh(geo, mat);
  ground.receiveShadow = true;
  ground.name = 'zemin';
  scene.add(ground);

  // Arena halkası: dövüş alanını belirten taş çember
  arena = new THREE.Group();
  arena.name = 'arena';
  const ringGeo = new THREE.RingGeometry(6.6, 7.3, 56, 1);
  ringGeo.rotateX(-90 * DEG);
  const ringMat = new THREE.MeshStandardMaterial({ ...MATERIAL_STANDARD, color: 0x6d6355, roughness: 0.94, metalness: 0.04 });
  const ring = new THREE.Mesh(ringGeo, ringMat);
  ring.position.y = 0.012;
  ring.receiveShadow = true;
  arena.add(ring);

  // 24 taş blok (arena sınırı)
  const rng = rngFrom(4242);
  const blockMat = new THREE.MeshStandardMaterial({ ...MATERIAL_STANDARD, color: 0x7b7263, roughness: 0.95, metalness: 0.03 });
  for (let i = 0; i < 24; i++) {
    const a = (i / 24) * TAU;
    const g = new THREE.BoxGeometry(0.62 + rng() * 0.3, 0.2 + rng() * 0.16, 0.4 + rng() * 0.16);
    const m = new THREE.Mesh(g, blockMat);
    m.position.set(Math.cos(a) * 7.7, 0.1 + rng() * 0.04, Math.sin(a) * 7.7);
    m.rotation.y = -a + (rng() - 0.5) * 0.2;
    m.castShadow = true;
    m.receiveShadow = true;
    arena.add(m);
  }
  scene.add(arena);
}

function buildDust(): void {
  const COUNT = 1200;
  const rng = rngFrom(777);
  const positions = new Float32Array(COUNT * 3);
  dustVel = new Float32Array(COUNT * 3);
  const sizes = new Float32Array(COUNT);
  for (let i = 0; i < COUNT; i++) {
    positions[i * 3] = (rng() - 0.5) * 40;
    positions[i * 3 + 1] = rng() * 9;
    positions[i * 3 + 2] = (rng() - 0.5) * 40;
    dustVel[i * 3] = (rng() - 0.5) * 0.14;
    dustVel[i * 3 + 1] = 0.03 + rng() * 0.13;
    dustVel[i * 3 + 2] = (rng() - 0.5) * 0.14;
    sizes[i] = 0.02 + rng() * 0.05;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geo.setAttribute('aBoyut', new THREE.BufferAttribute(sizes, 1));
  const mat = new THREE.PointsMaterial({
    color: 0xd9c7a4,
    size: 0.05,
    sizeAttenuation: true,
    transparent: true,
    opacity: 0.34,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    fog: true,
  });
  dust = new THREE.Points(geo, mat);
  dust.frustumCulled = false;
  dust.name = 'toz';
  scene.add(dust);
}

function updateDust(dt: number): void {
  if (!dustEnabled) return;
  const pos = dust.geometry.attributes.position as THREE.BufferAttribute;
  const arr = pos.array as Float32Array;
  for (let i = 0; i < arr.length; i += 3) {
    arr[i] += dustVel[i] * dt;
    arr[i + 1] += dustVel[i + 1] * dt;
    arr[i + 2] += dustVel[i + 2] * dt;
    if (arr[i + 1] > 9.5) {
      arr[i + 1] = 0.05;
      arr[i] = (Math.random() - 0.5) * 40;
      arr[i + 2] = (Math.random() - 0.5) * 40;
    }
  }
  pos.needsUpdate = true;
}

function updateTorches(t: number): void {
  const f1 = 0.72 + Math.sin(t * 11.3) * 0.1 + Math.sin(t * 27.7) * 0.06 + Math.random() * 0.06;
  const f2 = 0.7 + Math.sin(t * 9.1 + 1.7) * 0.11 + Math.sin(t * 23.3) * 0.05 + Math.random() * 0.06;
  torchA.intensity = 12 * f1;
  torchB.intensity = 12 * f2;
}

/* ── efektler: kıvılcım patlaması + şok halkası ── */
function spawnSparks(at: THREE.Vector3, renk = 0xffcf7a, adet = 46, guc = 1): void {
  const rng = rngFrom(Math.floor(at.x * 977 + at.z * 313 + performance.now()) >>> 0);
  const positions = new Float32Array(adet * 3);
  const vel = new Float32Array(adet * 3);
  for (let i = 0; i < adet; i++) {
    positions[i * 3] = at.x;
    positions[i * 3 + 1] = at.y;
    positions[i * 3 + 2] = at.z;
    const a = rng() * TAU;
    const e = (rng() - 0.35) * Math.PI;
    const s = (1.4 + rng() * 3.4) * guc;
    vel[i * 3] = Math.cos(a) * Math.cos(e) * s;
    vel[i * 3 + 1] = Math.sin(e) * s * 1.15 + 0.9;
    vel[i * 3 + 2] = Math.sin(a) * Math.cos(e) * s;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  const mat = new THREE.PointsMaterial({
    color: renk,
    size: 0.075,
    transparent: true,
    opacity: 1,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    sizeAttenuation: true,
  });
  const pts = new THREE.Points(geo, mat);
  pts.frustumCulled = false;
  scene.add(pts);
  sparks.push({ mesh: pts, vel, life: 0, maxLife: 0.72 });
}

function spawnShockwave(at: THREE.Vector3, renk = 0xffe6b0): void {
  const geo = new THREE.RingGeometry(0.06, 0.13, 26, 1);
  geo.rotateX(-90 * DEG);
  const mat = new THREE.MeshBasicMaterial({
    color: renk,
    transparent: true,
    opacity: 0.72,
    side: THREE.DoubleSide,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    fog: false,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.copy(at);
  mesh.position.y = Math.max(0.03, at.y);
  scene.add(mesh);
  shockwaves.push({ mesh, life: 0 });
}

function updateEffects(dt: number): void {
  for (let i = sparks.length - 1; i >= 0; i--) {
    const s = sparks[i];
    s.life += dt;
    const k = s.life / s.maxLife;
    const pos = s.mesh.geometry.attributes.position as THREE.BufferAttribute;
    const arr = pos.array as Float32Array;
    for (let j = 0; j < arr.length; j += 3) {
      s.vel[j + 1] -= 9.4 * dt;
      arr[j] += s.vel[j] * dt;
      arr[j + 1] += s.vel[j + 1] * dt;
      arr[j + 2] += s.vel[j + 2] * dt;
      if (arr[j + 1] < 0.02) {
        arr[j + 1] = 0.02;
        s.vel[j + 1] *= -0.32;
        s.vel[j] *= 0.7;
        s.vel[j + 2] *= 0.7;
      }
    }
    pos.needsUpdate = true;
    (s.mesh.material as THREE.PointsMaterial).opacity = Math.max(0, 1 - k * k);
    if (k >= 1) {
      scene.remove(s.mesh);
      s.mesh.geometry.dispose();
      (s.mesh.material as THREE.Material).dispose();
      sparks.splice(i, 1);
    }
  }
  for (let i = shockwaves.length - 1; i >= 0; i--) {
    const w = shockwaves[i];
    w.life += dt;
    const k = w.life / 0.55;
    const s = 1 + k * 7.5;
    w.mesh.scale.setScalar(s);
    (w.mesh.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 0.72 * (1 - k));
    if (k >= 1) {
      scene.remove(w.mesh);
      w.mesh.geometry.dispose();
      (w.mesh.material as THREE.Material).dispose();
      shockwaves.splice(i, 1);
    }
  }
}

/* ── kamera yardımcıları ── */
function focusOn(target: THREE.Vector3, distance: number, height = 0.35, animMs = 620): void {
  const from = { x: controls.target.x, y: controls.target.y, z: controls.target.z, d: camera.position.distanceTo(controls.target) };
  const dir = new THREE.Vector3().subVectors(camera.position, controls.target).normalize();
  const toCam = target.clone().addScaledVector(dir, distance);
  toCam.y = target.y + height * distance + 0.35;
  const to = { x: target.x, y: target.y, z: target.z, d: distance, cx: toCam.x, cy: toCam.y, cz: toCam.z };
  // Kamera da hedef gibi deterministik easing ile gider: kare hızı düşse bile
  // tween sonunda tam pozisyonda olur (düşük FPS'te yarım kalıyordu).
  const fromCam = camera.position.clone();
  const start = performance.now();
  const step = () => {
    const k = clamp((performance.now() - start) / animMs, 0, 1);
    const e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
    controls.target.set(
      from.x + (to.x - from.x) * e,
      from.y + (to.y - from.y) * e,
      from.z + (to.z - from.z) * e,
    );
    camera.position.set(
      fromCam.x + (to.cx - fromCam.x) * e,
      fromCam.y + (to.cy - fromCam.y) * e,
      fromCam.z + (to.cz - fromCam.z) * e,
    );
    if (k < 1) requestAnimationFrame(step);
  };
  step();
}

function setCameraFor(view: ViewId): void {
  controls.autoRotate = false;
  if (view === 'vitrin') {
    controls.target.set(0, 1.05, 0);
    camera.position.set(3.6, 2.35, 5.6);
    controls.minDistance = 0.7;
    controls.maxDistance = 26;
  } else if (view === 'laboratuvar') {
    controls.target.set(0, 1.0, 0);
    camera.position.set(1.9, 1.55, 3.1);
    controls.minDistance = 0.7;
    controls.maxDistance = 20;
  } else if (view === 'instans') {
    // Karşıdan bakış: LOD sıraları ve arkadaki etiket şeritleri ortalanır.
    controls.target.set(0, 1.7, -1.2);
    camera.position.set(0, 5.4, 13.8);
    controls.minDistance = 1;
    controls.maxDistance = 40;
  } else {
    // Ordular z ekseninde ±39 m'ye açılıyor; kamera iki hattı da çerçeveye alır.
    controls.target.set(0, 1.5, 0);
    camera.position.set(0, 30, 86);
    controls.minDistance = 3;
    controls.maxDistance = 240;
  }
  controls.update();
}

/* ═══════════════════════════════════════════════════════════════════════
   3) ARAYÜZ KURULUMU
   ═══════════════════════════════════════════════════════════════════════ */

function buildItemChips(container: HTMLElement, items: { id: string; ad: string }[], activeId: string, onPick: (id: string) => void): void {
  container.innerHTML = '';
  for (const it of items) {
    const b = document.createElement('button');
    b.className = 'chip' + (it.id === activeId ? ' aktif' : '');
    b.textContent = it.ad;
    b.dataset.id = it.id;
    b.addEventListener('click', () => {
      onPick(it.id);
      for (const c of Array.from(container.children)) c.classList.toggle('aktif', (c as HTMLElement).dataset.id === it.id);
    });
    container.appendChild(b);
  }
}

function buildVitrinList(): void {
  const box = $('vitrinListe');
  box.innerHTML = '';
  const groups = new Map<string, typeof ARMORY_CATALOG>();
  for (const spec of ARMORY_CATALOG) {
    const g = groupOf(spec.cls);
    const list = groups.get(g) ?? [];
    list.push(spec);
    groups.set(g, list);
  }
  for (const [groupName, list] of groups) {
    const h = document.createElement('h3');
    h.textContent = groupName;
    box.appendChild(h);
    for (const spec of list) {
      const b = document.createElement('button');
      b.className = 'liste-oge' + (spec.id === selectedItemId ? ' aktif' : '');
      b.dataset.id = spec.id;
      const lim = budgetFor(spec.id, 'battle');
      b.innerHTML =
        `<span class="oge-ad">${spec.name}</span>` +
        `<span class="oge-alt">${spec.faction} · ≤${lim} üçgen</span>`;
      b.addEventListener('click', () => selectItem(spec.id));
      box.appendChild(b);
    }
  }
}

function groupOf(cls: string): string {
  switch (cls) {
    case 'sword': return 'Kılıçlar';
    case 'axe': return 'Baltalar';
    case 'mace': return 'Topuzlar & Çekiçler';
    case 'polearm': return 'Gönderli Silahlar';
    case 'bow':
    case 'arrow': return 'Menzilli';
    case 'shield': return 'Kalkanlar';
    default: return 'Zırh';
  }
}

function buildSoundButtons(): void {
  const box = $('sesButonlari');
  box.innerHTML = '';
  for (const s of SESLER) {
    const b = document.createElement('button');
    b.className = 'ses-buton';
    b.innerHTML = `<span class="ses-tus">${s.tus}</span><span class="ses-ad">${s.ad}</span><span class="ses-aciklama">${s.aciklama}</span>`;
    b.addEventListener('click', () => playSound(s.id));
    box.appendChild(b);
  }
}

function buildAppearanceUI(): void {
  const arma = $select('armaSec');
  arma.innerHTML = '';
  for (const c of HERALDRY_CATALOG) {
    const o = document.createElement('option');
    o.value = c.id;
    o.textContent = c.label;
    arma.appendChild(o);
  }
  arma.value = FactionPalette.byId(labState.faction).charge;
}

/** Arma adını katalogdan bul. */
function chargeName(c: ChargeType): string {
  return HERALDRY_CATALOG.find((h) => h.id === c)?.label ?? c;
}

function playSound(id: AttackSoundName, opts?: { intensity?: number; pan?: number; rate?: number }): void {
  if (!audioUnlocked) unlockAudio();
  sfx.play(id, { intensity: 1, pan: 0, ...(opts ?? {}) });
  flashSoundButton(id);
}

function flashSoundButton(id: AttackSoundName): void {
  const box = $('sesButonlari');
  const idx = SESLER.findIndex((s) => s.id === id);
  if (idx < 0) return;
  const el = box.children[idx] as HTMLElement | undefined;
  if (!el) return;
  el.classList.add('caliyor');
  window.setTimeout(() => el.classList.remove('caliyor'), 260);
}

function unlockAudio(): void {
  void sfx.unlock().then(() => {
    audioUnlocked = sfx.ready;
    $('sesDurum').textContent = audioUnlocked
      ? `ses kilidi: açık · ${sfx.getVoiceInfo().total} aktif ses`
      : 'ses kilidi: açılamadı (tarayıcı izin vermedi)';
  });
}

/* ── görünüm geçişi ── */
function setView(view: ViewId): void {
  if (currentView === view) return;
  currentView = view;
  for (const b of Array.from($('sekmeler').children)) {
    b.classList.toggle('aktif', (b as HTMLElement).dataset.gorunum === view);
  }
  show($('vitrinListeBolum'), view === 'vitrin');
  show($('labListeBolum'), view === 'laboratuvar');
  show($('instansListeBolum'), view === 'instans');
  show($('savasListeBolum'), view === 'savas');
  show($('detayBolum'), view === 'vitrin');
  show($('labAnimBolum'), view === 'laboratuvar');

  vitrinRoot.visible = view === 'vitrin';
  labRoot.visible = view === 'laboratuvar';
  instansRoot.visible = view === 'instans';
  savasRoot.visible = view === 'savas';
  arena.visible = view === 'vitrin' || view === 'laboratuvar' || view === 'instans';

  // toz ve gölgeler yalnızca yakın görünümlerde
  dust.visible = dustEnabled && view !== 'savas';
  // Meydan 78 m derinliğinde: sis uzaklaştırılmazsa karşı hat pusda kaybolur.
  const fog = scene.fog as THREE.Fog;
  fog.near = view === 'savas' ? 70 : 26;
  fog.far = view === 'savas' ? 240 : 130;
  keyLight.shadow.camera.far = view === 'savas' ? 220 : 60;
  const sc = view === 'savas' ? 62 : 16;
  keyLight.shadow.camera.left = -sc;
  keyLight.shadow.camera.right = sc;
  keyLight.shadow.camera.top = sc;
  keyLight.shadow.camera.bottom = -sc;
  keyLight.shadow.camera.updateProjectionMatrix();
  keyLight.position.set(view === 'savas' ? 34 : 7.5, view === 'savas' ? 52 : 12.5, view === 'savas' ? 26 : 6.5);

  setCameraFor(view);
  if (view === 'laboratuvar' && !labCharacter) buildLabCharacter();
  if (view === 'instans' && instansMeshes.length === 0) rebuildInstans();
  updateSceneOverlay();
}

/* ── sahne üstü bilgi şeridi ── */
function updateSceneOverlay(): void {
  const el = $('sahneUstuBilgi');
  if (currentView === 'savas') {
    el.innerHTML = '';
    return;
  }
  if (currentView === 'vitrin') {
    const spec = ARMORY_CATALOG.find((s) => s.id === selectedItemId);
    el.innerHTML = spec
      ? `<b>${spec.name}</b> · ${spec.faction} · ${spec.weightKg.toFixed(1)} kg · menzil ${spec.reach.toFixed(2)} m`
      : '';
    return;
  }
  if (currentView === 'laboratuvar' && labCharacter) {
    const b = labCharacter.budget;
    el.innerHTML =
      `<b>${ROL_ADLARI[labState.role]}</b> · ${FactionPalette.byId(labState.faction).name} · ` +
      `çizilen ${fmt(b.total)} / ${fmt(b.budget)} üçgen (vitrin ham ${fmt(b.rawTotal)})`;
    return;
  }
  if (currentView === 'instans') {
    el.innerHTML = `<b>${instansState.count} kopya</b> · ${instansState.compare ? '3 LOD sırası' : 'tek LOD'} · tek draw-call / sıra`;
  }
}

const ROL_ADLARI: Record<UnitRole, string> = {
  infantry: 'Piyade',
  archer: 'Okçu',
  cavalry: 'Süvari',
  sergeant: 'Çavuş',
  banner: 'Sancaktar',
};

/* ── detay paneli ── */
function updateDetailPanel(): void {
  const spec = ARMORY_CATALOG.find((s) => s.id === selectedItemId);
  if (!spec) return;
  const item = vitrinItems.find((v) => v.id === selectedItemId);
  $('detayBaslik').textContent = spec.name;

  const rozet = $('detayRozetler');
  rozet.innerHTML = '';
  const badges: [string, string][] = [
    [groupOf(spec.cls), 'tur'],
    [spec.faction, 'fraksiyon'],
    [spec.twoHanded ? 'Çift elli' : 'Tek elli', 'el'],
    [LOD_ADI[labState.lod] ?? 'hero', 'lod'],
  ];
  for (const [text, cls] of badges) {
    const s = document.createElement('span');
    s.className = `rozet ${cls}`;
    s.textContent = text;
    rozet.appendChild(s);
  }

  $('detayAciklama').textContent = spec.description;

  const lim = item ? item.budget : budgetFor(spec.id, 'battle');
  const tri = item ? item.triangles : 0;
  const tablo = $('detayTablo');
  tablo.innerHTML =
    row('Sınıf', spec.cls) +
    row('Ağırlık', `${spec.weightKg.toFixed(2)} kg`) +
    row('Menzil', `${spec.reach.toFixed(2)} m`) +
    row('Saldırı', attackName(spec.attack.type)) +
    row('Vuruş anı', `${spec.attack.impactAt.toFixed(2)} sn`) +
    row('Üçgen (hero)', fmt(tri)) +
    row('Bütçe (battle)', `${fmt(budgetFor(spec.id, 'battle'))} üçgen`);

  const ratio = clamp(tri / Math.max(1, lim), 0, 1.4);
  $('butceDeger').textContent = `${fmt(tri)} / ${fmt(lim)}`;
  const cubuk = $('butceCubuk');
  cubuk.style.width = `${clamp(ratio, 0, 1) * 100}%`;
  cubuk.className = ratio > 1 ? 'asim' : ratio > 0.85 ? 'sinirda' : 'uygun';
  $('butceNot').textContent = ratio > 1 ? 'BÜTÇE AŞIMI' : `Bölüm 1 performans bütçesi içinde · %${Math.round(ratio * 100)}`;

  $btn('btnSaldiri').textContent = `Saldırı Animasyonu Test Et · ${attackName(spec.attack.type)}`;
}

const LOD_ADI: Record<LodLevel, string> = { hero: 'hero', battle: 'battle', crowd: 'crowd' };

function row(k: string, v: string): string {
  return `<tr><td>${k}</td><td>${v}</td></tr>`;
}

function attackName(t: AttackAnimType): string {
  const n: Record<AttackAnimType, string> = {
    swing: 'Savurma (swing)',
    thrust: 'Saplama (thrust)',
    draw: 'Yay çekme (draw)',
    raise: 'Kaldırma (raise)',
    bash: 'Kabza vuruşu (bash)',
    chop: 'Doğrama (chop)',
  };
  return n[t] ?? t;
}

/* ── laboratuvar paneli ── */
function buildLabUI(): void {
  buildItemChips($('rolSec'), ROLLER.map((r) => ({ id: r.id, ad: r.ad })), labState.role, (id) => {
    labState.role = id as UnitRole;
    const preset = ROLE_PRESETS[labState.role];
    labState.weapon = (preset.weapon ?? '') as ArmoryItemId | '';
    labState.offhand = (preset.offhand ?? '') as ArmoryItemId | '';
    labState.back = (preset.back ?? '') as ArmoryItemId | '';
    labState.tier = (preset.tier ?? 'medium') as 'light' | 'medium' | 'heavy';
    labState.helm = (preset.helm ?? 'spangen') as 'greatHelm' | 'spangen' | 'kettle' | 'none';
    syncLabControls();
    buildLabCharacter();
  });

  buildItemChips(
    $('fraksiyonSec'),
    FACTIONS.map((f) => ({ id: f.id, ad: f.name })),
    labState.faction,
    (id) => {
      labState.faction = id;
      syncFactionColors();
      buildLabCharacter();
    },
  );

  buildItemChips($('tierSec'), TIERS.map((t) => ({ id: t.id, ad: t.ad })), labState.tier, (id) => {
    labState.tier = id as 'light' | 'medium' | 'heavy';
    buildLabCharacter();
  });

  buildItemChips($('helmSec'), HELMS.map((h) => ({ id: h.id, ad: h.ad })), labState.helm, (id) => {
    labState.helm = id as 'greatHelm' | 'spangen' | 'kettle' | 'none';
    buildLabCharacter();
  });

  buildItemChips(
    $('cinsSec'),
    (Object.keys(HORSE_BREEDS) as HorseBreed[]).map((b) => ({ id: b, ad: HORSE_BREEDS[b].ad })),
    labState.breed,
    (id) => {
      labState.breed = id as HorseBreed;
      buildLabCharacter();
    },
  );

  const silahlar = ARMORY_CATALOG.filter((s) => ['sword', 'axe', 'mace', 'polearm', 'bow'].includes(s.cls));
  fillSelect($select('silahSec'), silahlar.map((s) => ({ id: s.id, ad: s.name })), '(boş)', labState.weapon);
  fillSelect(
    $select('kalkanSec'),
    ARMORY_CATALOG.filter((s) => s.cls === 'shield' || s.id === 'recurveBow').map((s) => ({ id: s.id, ad: s.name })),
    '(boş)',
    labState.offhand,
  );
  fillSelect(
    $select('sirtSec'),
    ARMORY_CATALOG.filter((s) => ['sword', 'axe', 'mace', 'bow'].includes(s.cls) || s.id === 'arrow').map((s) => ({ id: s.id, ad: s.id === 'arrow' ? 'Ok kılıfı (sadak)' : s.name })),
    '(boş)',
    labState.back,
  );

  $select('silahSec').addEventListener('change', (e) => {
    labState.weapon = (e.target as HTMLSelectElement).value as ArmoryItemId;
    buildLabCharacter();
  });
  $select('kalkanSec').addEventListener('change', (e) => {
    labState.offhand = (e.target as HTMLSelectElement).value as ArmoryItemId;
    buildLabCharacter();
  });
  $select('sirtSec').addEventListener('change', (e) => {
    labState.back = (e.target as HTMLSelectElement).value as ArmoryItemId;
    buildLabCharacter();
  });
  $check('surcoatAcik').addEventListener('change', (e) => {
    labState.surcoat = (e.target as HTMLInputElement).checked;
    buildLabCharacter();
  });

  // animasyon klipleri
  buildItemChips(
    $('animSec'),
    Object.keys(ANIMATION_CLIPS).map((k) => ({ id: k, ad: clipName(k) })),
    labState.clip,
    (id) => {
      labState.clip = id;
      if (labCharacter) {
        labCharacter.animator.play(id);
        labCharacter.animator.ctx.speed = labState.speed;
      }
    },
  );

  $range('animHiz').addEventListener('input', (e) => {
    labState.speed = parseFloat((e.target as HTMLInputElement).value);
    $('animHizDeger').textContent = labState.speed.toFixed(2);
    if (labCharacter) labCharacter.animator.ctx.speed = labState.speed;
  });

  $btn('btnLabSaldiri').addEventListener('click', () => labAttackTest());
}

function fillSelect(sel: HTMLSelectElement, items: { id: string; ad: string }[], bosEtiket: string, active: string): void {
  sel.innerHTML = '';
  const bos = document.createElement('option');
  bos.value = '';
  bos.textContent = bosEtiket;
  sel.appendChild(bos);
  for (const it of items) {
    const o = document.createElement('option');
    o.value = it.id;
    o.textContent = it.ad;
    sel.appendChild(o);
  }
  sel.value = active || '';
}

function syncLabControls(): void {
  $select('silahSec').value = labState.weapon || '';
  $select('kalkanSec').value = labState.offhand || '';
  $select('sirtSec').value = labState.back || '';
  $check('surcoatAcik').checked = labState.surcoat;
}

function syncFactionColors(): void {
  const f = FactionPalette.byId(labState.faction);
  ($('renkBirincil') as HTMLInputElement).value = hexToInput(f.colors.primary);
  ($('renkIkincil') as HTMLInputElement).value = hexToInput(f.colors.secondary);
  ($('renkSus') as HTMLInputElement).value = hexToInput(f.colors.trim);
  $select('armaSec').value = f.charge;
}

function hexToInput(hex: number): string {
  return `#${hex.toString(16).padStart(6, '0')}`;
}

function inputToHex(v: string): number {
  return parseInt(v.replace('#', ''), 16) || 0;
}

function clipName(k: string): string {
  const n: Record<string, string> = {
    idle: 'Bekleyiş',
    ready: 'Hazır ol',
    walk: 'Yürüyüş',
    attackSword: 'Kılıç savurma',
    attackThrust: 'Saplamа',
    attackAxe: 'Balta doğrama',
    block: 'Blok',
    shootBow: 'Yay atışı',
    death: 'Ölüm',
    mountedIdle: 'At üstü bekleyiş',
    horseWalk: 'At yürüyüşü',
  };
  return (n[k] ?? k).replace('а', 'a');
}

/* ═══════════════════════════════════════════════════════════════════════
   4) GÖRÜNÜM 1 · VİTRİN (14 kaide, tıkla-incele)
   ═══════════════════════════════════════════════════════════════════════ */

function buildVitrin(): void {
  vitrinRoot = new THREE.Group();
  vitrinRoot.name = 'vitrin';
  scene.add(vitrinRoot);

  vitrinArmory = new Armory(FactionPalette.byId('vlandia'), { seed: 20261020, warnOnBudgetOverflow: false });

  // ── merkez rune dairesi ──
  const runeTex = canvasTexture(512, (ctx, s) => {
    const c = s / 2;
    ctx.clearRect(0, 0, s, s);
    ctx.strokeStyle = 'rgba(212,183,120,0.85)';
    ctx.lineWidth = 3;
    for (const r of [c * 0.94, c * 0.86, c * 0.52, c * 0.46]) {
      ctx.beginPath();
      ctx.arc(c, c, r, 0, TAU);
      ctx.stroke();
    }
    // runik çentikler
    ctx.lineWidth = 5;
    for (let i = 0; i < 36; i++) {
      const a = (i / 36) * TAU;
      const r0 = c * 0.86;
      const r1 = c * (i % 3 === 0 ? 0.72 : 0.79);
      ctx.beginPath();
      ctx.moveTo(c + Math.cos(a) * r0, c + Math.sin(a) * r0);
      ctx.lineTo(c + Math.cos(a) * r1, c + Math.sin(a) * r1);
      ctx.stroke();
    }
    // iç süs: sekiz kollu yıldız
    ctx.lineWidth = 3.5;
    ctx.beginPath();
    for (let i = 0; i < 16; i++) {
      const a = (i / 16) * TAU;
      const r = i % 2 === 0 ? c * 0.46 : c * 0.2;
      const x = c + Math.cos(a) * r;
      const y = c + Math.sin(a) * r;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.stroke();
  }, 1);

  const daisGeo = new THREE.CylinderGeometry(2.0, 2.15, 0.14, 24, 1);
  const daisMat = new THREE.MeshStandardMaterial({ ...MATERIAL_STANDARD, color: 0x575049, roughness: 0.96, metalness: 0.03 });
  vitrinDais = new THREE.Mesh(daisGeo, daisMat);
  vitrinDais.position.y = 0.07;
  vitrinDais.receiveShadow = true;
  vitrinDais.castShadow = true;
  vitrinRoot.add(vitrinDais);

  const runeGeo = new THREE.CircleGeometry(1.96, 40);
  runeGeo.rotateX(-90 * DEG);
  const runeMat = new THREE.MeshBasicMaterial({
    map: runeTex,
    transparent: true,
    opacity: 0.55,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    fog: false,
  });
  vitrinRune = new THREE.Mesh(runeGeo, runeMat);
  vitrinRune.position.y = 0.145;
  vitrinRoot.add(vitrinRune);

  // ── 14 kaide halka üzerinde ──
  const R = 4.35;
  const standGeo = new THREE.CylinderGeometry(0.34, 0.42, 0.86, 8, 1);
  const standTopGeo = new THREE.CylinderGeometry(0.4, 0.34, 0.07, 8, 1);
  const standMat = new THREE.MeshStandardMaterial({ ...MATERIAL_STANDARD, color: 0x4c4640, roughness: 0.95, metalness: 0.05 });
  const standTopMat = new THREE.MeshStandardMaterial({ ...MATERIAL_STANDARD, color: 0x6a6055, roughness: 0.9, metalness: 0.08 });

  ARMORY_IDS.forEach((id, i) => {
    const angle = (i / ARMORY_IDS.length) * TAU - Math.PI / 2;
    const x = Math.cos(angle) * R;
    const z = Math.sin(angle) * R;

    const stand = new THREE.Group();
    stand.position.set(x, 0, z);
    stand.lookAt(0, 0, 0);
    stand.rotation.x = 0;
    stand.rotation.z = 0;
    vitrinRoot.add(stand);

    const body = new THREE.Mesh(standGeo, standMat);
    body.position.y = 0.43;
    body.castShadow = true;
    body.receiveShadow = true;
    stand.add(body);
    const top = new THREE.Mesh(standTopGeo, standTopMat);
    top.position.y = 0.895;
    top.castShadow = true;
    stand.add(top);

    const item = vitrinArmory.buildItem(id, 'hero');
    const displayNode = vitrinArmory.createDisplayNode(item);
    // Kaidenin üstünde, göz hizasına gelecek şekilde yükselt
    const lift = liftFor(id, item.size.y);
    displayNode.position.y = 0.93 + lift;
    displayNode.userData.itemId = id;
    stand.add(displayNode);

    // merged (tek draw-call) gösterim kopyası — tıklama testi bununla yapılır
    const mergedMesh = new THREE.Mesh(item.merged, item.material.clone());
    mergedMesh.position.y = 0.93 + lift + (item.spec.displayOffset[1] * item.spec.displayScale);
    mergedMesh.scale.setScalar(item.spec.displayScale);
    mergedMesh.rotation.set(
      item.spec.displayRotation[0] * DEG,
      item.spec.displayRotation[1] * DEG,
      item.spec.displayRotation[2] * DEG,
    );
    mergedMesh.visible = false;
    mergedMesh.castShadow = true;
    mergedMesh.userData.itemId = id;
    mergedMesh.name = `merged_${id}`;
    stand.add(mergedMesh);

    vitrinItems.push({
      id,
      stand,
      heroGroup: displayNode,
      mergedMesh,
      merged: item.merged,
      triangles: item.triangles,
      budget: item.budget,
      angle,
      baseY: 0.93 + lift,
      spin: 0,
    });
  });

  buildVitrinList();
  selectItem('gladius', false);
}

/** Silahın görsel olarak dengede durması için gereken kaldırma (m). */
function liftFor(id: ArmoryItemId, height: number): number {
  const spec = ARMORY_CATALOG.find((s) => s.id === id)!;
  if (spec.cls === 'polearm' || id === 'bardiche' || id === 'lance' || id === 'halberd') return height * 0.42;
  if (spec.cls === 'bow') return 0.28;
  if (spec.cls === 'shield') return 0.34;
  if (spec.cls === 'armor') return 0.1;
  return height * 0.44;
}

function selectItem(id: ArmoryItemId, focus = true): void {
  selectedItemId = id;
  for (const b of Array.from($('vitrinListe').children)) {
    if (b.classList.contains('liste-oge')) b.classList.toggle('aktif', (b as HTMLElement).dataset.id === id);
  }
  const item = vitrinItems.find((v) => v.id === id);
  if (!item) return;
  // inceleme modunda karartma maskesi yeni seçime uysun (eski mask kalıyordu)
  if (inspectMode) applyInspectDim();
  applyMergedToggle();
  updateDetailPanel();
  updateSceneOverlay();
  if (focus) {
    const world = new THREE.Vector3();
    item.stand.getWorldPosition(world);
    world.y = item.baseY + 0.15;
    // Odak mesafesi eşyanın boyuna göre: topuz miğfer gibi kısa parçalar
    // 3.2 m'de ufacık kalıyordu, pavise/billhook içinse üst sınır korunur.
    const spec = ARMORY_CATALOG.find((s) => s.id === id);
    const dist = inspectMode ? 1.5 : Math.min(3.2, 1.05 + (spec?.displayScale ?? 1) * 1.5);
    focusOn(world, dist, inspectMode ? 0.12 : 0.22);
  }
}

/** İnceleme modu karartma maskesini SEÇİLİ öğeye göre yeniler. */
function applyInspectDim(): void {
  for (const item of vitrinItems) {
    const dim = inspectMode && item.id !== selectedItemId;
    applyMaterialFlags(item.stand, { opacity: dim ? 0.14 : 1 });
  }
  applyMaterialFlags(vitrinDais, { opacity: inspectMode ? 0.35 : 1 });
}

function setInspect(on: boolean): void {
  inspectMode = on;
  applyInspectDim();
  const world = new THREE.Vector3();
  const item = vitrinItems.find((v) => v.id === selectedItemId);
  if (item) {
    item.stand.getWorldPosition(world);
    world.y = item.baseY + 0.15;
    focusOn(world, on ? 1.5 : 3.2, on ? 0.1 : 0.3);
  }
  $btn('btnOdakla').textContent = on ? 'Geniş Görünüm' : 'Yakın İnceleme';
}

function applyMergedToggle(): void {
  for (const item of vitrinItems) {
    const showMerged = useMerged && item.id === selectedItemId;
    item.heroGroup.visible = !showMerged;
    item.mergedMesh.visible = showMerged;
  }
}

/* ── vitrin saldırı testi: elde tutulan silah animasyonu ── */
function vitrinAttackTest(): void {
  const spec = ARMORY_CATALOG.find((s) => s.id === selectedItemId);
  if (!spec) return;
  const item = vitrinItems.find((v) => v.id === selectedItemId);
  if (!item) return;

  const node = useMerged ? item.mergedMesh : item.heroGroup;
  const dur = spec.attack.duration;
  const start = clock.getElapsedTime();
  const restPos = node.position.clone();
  const restRot = node.rotation.clone();
  let impactDone = false;

  const step = () => {
    const t = clock.getElapsedTime() - start;
    const k = clamp(t / dur, 0, 1);
    // kabza → namlu savurma yayı: arm, strike ve rest arasında yumuşak geçiş
    const arm = new THREE.Euler(...spec.attack.arm.map((d) => d * DEG));
    const strike = new THREE.Euler(...spec.attack.strike.map((d) => d * DEG));
    const windup = clamp(k / 0.34, 0, 1);
    const swing = clamp((k - 0.34) / 0.18, 0, 1);
    const recover = clamp((k - 0.62) / 0.38, 0, 1);

    let e: THREE.Euler;
    if (k < 0.34) e = new THREE.Euler(arm.x * windup, arm.y * windup, arm.z * windup);
    else if (k < 0.52) {
      const s = swing * swing * (3 - 2 * swing);
      e = new THREE.Euler(arm.x + (strike.x - arm.x) * s, arm.y + (strike.y - arm.y) * s, arm.z + (strike.z - arm.z) * s);
    } else {
      const s = 1 - recover * recover * (3 - 2 * recover);
      e = new THREE.Euler(strike.x * s, strike.y * s, strike.z * s);
    }
    node.rotation.set(restRot.x + e.x, restRot.y + e.y, restRot.z + e.z);

    const lunge = Math.sin(clamp((k - 0.3) / 0.24, 0, 1) * Math.PI) * spec.attack.lunge;
    node.position.copy(restPos).addScaledVector(new THREE.Vector3(0, 0.35, 0.6).normalize(), lunge);

    if (!impactDone && k >= spec.attack.impactAt / dur) {
      impactDone = true;
      const hit = new THREE.Vector3();
      node.getWorldPosition(hit);
      hit.y += 0.35;
      spawnSparks(hit, 0xffd08a, 54, 1.1);
      spawnShockwave(hit);
      playSound(spec.showcaseSound as AttackSoundName, { intensity: 1.15 });
    }
    if (k < 1) requestAnimationFrame(step);
    else {
      node.position.copy(restPos);
      node.rotation.copy(restRot);
    }
  };
  step();
}

/* ═══════════════════════════════════════════════════════════════════════
   5) GÖRÜNÜM 2 · KARAKTER LABORATUVARI
   ═══════════════════════════════════════════════════════════════════════ */

function buildLabScene(): void {
  labRoot = new THREE.Group();
  labRoot.name = 'laboratuvar';
  labRoot.visible = false;
  scene.add(labRoot);
  labArmory = new Armory(FactionPalette.byId('vlandia'), { warnOnBudgetOverflow: false });

  // laboratuvar kaidesi
  const dais = new THREE.Mesh(
    new THREE.CylinderGeometry(1.35, 1.5, 0.1, 20, 1),
    new THREE.MeshStandardMaterial({ ...MATERIAL_STANDARD, color: 0x544d45, roughness: 0.95, metalness: 0.04 }),
  );
  dais.position.y = 0.05;
  dais.receiveShadow = true;
  dais.castShadow = true;
  labRoot.add(dais);

  const ring = new THREE.Mesh(
    new THREE.TorusGeometry(1.42, 0.022, 3, 40),
    new THREE.MeshStandardMaterial({ ...MATERIAL_STANDARD, color: 0xc9a227, roughness: 0.4, metalness: 0.85 }),
  );
  ring.rotation.x = 90 * DEG;
  ring.position.y = 0.1;
  labRoot.add(ring);

  buildLabCharacter();
}

function customFaction(id: string): FactionPalette {
  const base = FactionPalette.byId(id);
  const primary = inputToHex(($('renkBirincil') as HTMLInputElement).value);
  const secondary = inputToHex(($('renkIkincil') as HTMLInputElement).value);
  const trim = inputToHex(($('renkSus') as HTMLInputElement).value);
  const charge = ($select('armaSec').value || base.charge) as ChargeType;
  return new FactionPalette({
    id: base.id,
    name: base.name,
    culture: base.culture,
    motto: base.motto,
    charge,
    primary,
    secondary,
    trim,
    cloth: base.colors.cloth,
    steel: base.colors.steel,
    steelDark: base.colors.steelDark,
    gold: base.colors.gold,
    wood: base.colors.wood,
    leather: base.colors.leather,
  });
}

function buildLabCharacter(): void {
  if (labCharacter) {
    labRoot.remove(labCharacter.group);
    labCharacter.dispose();
    labCharacter = null;
  }
  if (labHorse) {
    labRoot.remove(labHorse.group);
    labHorse.dispose();
    labHorse = null;
  }
  if (labAttackNode) {
    labRoot.remove(labAttackNode);
    labAttackNode = null;
  }

  const faction = customFaction(labState.faction);
  const mounted = labState.role === 'cavalry';

  labCharacter = new Character({
    faction,
    lod: labState.lod,
    seed: 4242,
    build: 0.55,
    loadout: {
      weapon: (labState.weapon || null) as ArmoryItemId | null,
      offhand: (labState.offhand || null) as ArmoryItemId | null,
      back: (labState.back === 'arrow' ? 'arrow' : labState.back || null) as ArmoryItemId | null,
      tier: labState.tier,
      helm: labState.helm,
      surcoat: labState.surcoat,
      role: labState.role,
    },
  });
  labCharacter.animator.play(labState.clip);
  labCharacter.animator.ctx.speed = labState.speed;

  if (mounted) {
    labHorse = new Horse({
      faction,
      lod: labState.lod,
      coat: HORSE_BREEDS[labState.breed].coat as CoatColor,
      breed: labState.breed,
      barding: true,
      caparison: true,
      saddle: true,
      seed: 99,
    });
    labHorse.attachRider(labCharacter);
    labHorse.group.position.set(0, 0, 0);
    labHorse.group.rotation.y = 24 * DEG;
    labRoot.add(labHorse.group);
    // Binek (özellikle destrier) kadraja sığmıyorsa kamerayı bir kez geri çek.
    if (currentView === 'laboratuvar' && camera.position.distanceTo(controls.target) < 3.8) {
      controls.target.set(0, 1.25, 0);
      camera.position.set(2.8, 2.15, 4.6);
      controls.update();
    }
    labHorse.animator.play('horseWalk');
    labHorse.animator.ctx.speed = 0;
  } else {
    labCharacter.group.position.set(0, 0, 0);
    labCharacter.group.rotation.y = 18 * DEG;
    labRoot.add(labCharacter.group);
  }

  // saldırı testinde elde tutulan silahın yakın çekim kopyası
  if (labState.weapon && labState.weapon !== 'recurveBow') {
    labArmory.setFaction(faction);
    const weaponItem = labArmory.buildItem(labState.weapon as ArmoryItemId, 'hero');
    labAttackNode = labArmory.createDisplayNode(weaponItem);
    labAttackNode.visible = false;
    labAttackNode.position.set(0.62, 1.05, 0.35);
    labRoot.add(labAttackNode);
  }

  applyMaterialFlags(labRoot, { wire: wireframe });
  updateLabBudget();
  updateSceneOverlay();
}

function updateLabBudget(): void {
  if (!labCharacter) return;
  const b = labCharacter.budget;
  const horseTris = labHorse ? labHorse.triangles : 0;
  const total = b.total + horseTris;
  const limit = b.budget + (labHorse ? BUDGET.horseMax : 0);
  $('labButceDeger').textContent = `${fmt(total)} / ${fmt(limit)}`;
  const ratio = clamp(total / limit, 0, 1);
  const cubuk = $('labButceCubuk');
  cubuk.style.width = `${ratio * 100}%`;
  cubuk.className = total > limit ? 'asim' : ratio > 0.85 ? 'sinirda' : 'uygun';
  $('labButceNot').innerHTML =
    `gövde+zırh+silah <b>${fmt(b.total)}</b> · at <b>${fmt(horseTris)}</b> · ` +
    `vitrin ham <b>${fmt(b.rawTotal + (labHorse ? labHorse.rawTriangles : 0))}</b>` +
    (total > limit ? ' · <b class="asim-yazi">BÜTÇE AŞIMI</b>' : ' · Bölüm 1 bütçesi içinde');
}

let labAttackTimer = 0;
function labAttackTest(): void {
  if (!labCharacter || !labAttackNode) return;
  const spec = ARMORY_CATALOG.find((s) => s.id === labState.weapon);
  if (!spec) return;
  const clip = clipForAttack(spec.attack.type);
  labCharacter.animator.play(clip);
  labCharacter.animator.ctx.speed = labState.speed;
  labState.clip = clip;
  for (const c of Array.from($('animSec').children)) {
    c.classList.toggle('aktif', (c as HTMLElement).dataset.id === clip);
  }

  // elde tutulan silahın yakın çekim savurma animasyonu
  const node = labAttackNode;
  node.visible = true;
  const restPos = node.position.clone();
  const restRot = node.rotation.clone();
  const start = clock.getElapsedTime();
  const dur = spec.attack.duration / Math.max(0.1, labState.speed);
  let impactDone = false;
  window.clearTimeout(labAttackTimer);

  const step = () => {
    const t = clock.getElapsedTime() - start;
    const k = clamp(t / dur, 0, 1);
    const windup = clamp(k / 0.34, 0, 1);
    const swing = clamp((k - 0.34) / 0.18, 0, 1);
    const recover = clamp((k - 0.62) / 0.38, 0, 1);
    const arm = spec.attack.arm;
    const strike = spec.attack.strike;
    let rx: number, ry: number, rz: number;
    if (k < 0.34) {
      rx = arm[0] * windup; ry = arm[1] * windup; rz = arm[2] * windup;
    } else if (k < 0.52) {
      const s = swing * swing * (3 - 2 * swing);
      rx = arm[0] + (strike[0] - arm[0]) * s;
      ry = arm[1] + (strike[1] - arm[1]) * s;
      rz = arm[2] + (strike[2] - arm[2]) * s;
    } else {
      const s = 1 - recover * recover * (3 - 2 * recover);
      rx = strike[0] * s; ry = strike[1] * s; rz = strike[2] * s;
    }
    node.rotation.set(restRot.x + rx * DEG, restRot.y + ry * DEG, restRot.z + rz * DEG);
    const lunge = Math.sin(clamp((k - 0.3) / 0.24, 0, 1) * Math.PI) * spec.attack.lunge;
    node.position.set(restPos.x, restPos.y + lunge * 0.4, restPos.z + lunge);

    if (!impactDone && k >= spec.attack.impactAt / spec.attack.duration) {
      impactDone = true;
      const hit = new THREE.Vector3();
      node.getWorldPosition(hit);
      spawnSparks(hit, 0xffd08a, 60, 1.2);
      spawnShockwave(hit);
      playSound(spec.showcaseSound as AttackSoundName, { intensity: 1.2 });
    }
    if (k < 1) requestAnimationFrame(step);
    else {
      node.position.copy(restPos);
      node.rotation.copy(restRot);
      labAttackTimer = window.setTimeout(() => {
        node.visible = false;
        labCharacter?.animator.play(labState.clip === clip ? 'ready' : labState.clip);
      }, 700);
    }
  };
  step();
}

/* ═══════════════════════════════════════════════════════════════════════
   6) GÖRÜNÜM 3 · İNSTANS & LOD
   ═══════════════════════════════════════════════════════════════════════ */

function buildInstansScene(): void {
  instansRoot = new THREE.Group();
  instansRoot.name = 'instans';
  instansRoot.visible = false;
  scene.add(instansRoot);
  instansArmory = new Armory(FactionPalette.byId('sturgia'), { warnOnBudgetOverflow: false });

  const sel = $select('instansItem');
  sel.innerHTML = '';
  for (const spec of ARMORY_CATALOG) {
    const o = document.createElement('option');
    o.value = spec.id;
    o.textContent = spec.name;
    sel.appendChild(o);
  }
  sel.value = instansState.item;
  sel.addEventListener('change', (e) => {
    instansState.item = (e.target as HTMLSelectElement).value as ArmoryItemId;
    rebuildInstans();
  });
  $range('instansSayi').addEventListener('input', (e) => {
    instansState.count = parseInt((e.target as HTMLInputElement).value, 10);
    $('instansSayiDeger').textContent = String(instansState.count);
    rebuildInstans();
  });
  $check('instansLodKarsilastir').addEventListener('change', (e) => {
    instansState.compare = (e.target as HTMLInputElement).checked;
    rebuildInstans();
  });
}

function rebuildInstans(): void {
  for (const m of instansMeshes) {
    instansRoot.remove(m);
    m.dispose();
  }
  instansMeshes = [];

  const rows: LodLevel[] = instansState.compare ? ['hero', 'battle', 'crowd'] : ['battle'];
  const n = instansState.count;
  const cols = Math.ceil(Math.sqrt(n * 2.2));
  const gap = 0.72;

  rows.forEach((lod, rowIndex) => {
    const item = instansArmory.buildItem(instansState.item, lod);
    const mesh = new THREE.InstancedMesh(item.merged, item.material.clone(), n);
    mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.name = `instans_${lod}`;
    mesh.userData.lod = lod;
    mesh.userData.triangles = item.triangles;
    mesh.userData.budget = item.budget;
    mesh.userData.size = item.size.clone();
    instansRoot.add(mesh);
    instansMeshes.push(mesh);

    const o = new THREE.Object3D();
    for (let i = 0; i < n; i++) {
      const cx = i % cols;
      const cz = Math.floor(i / cols);
      o.position.set((cx - (cols - 1) / 2) * gap, 0.45 + rowIndex * 1.5, (cz - Math.floor(n / cols) / 2) * gap);
      o.rotation.set(0, (i * 0.7) % TAU, 0);
      o.scale.setScalar(1);
      o.updateMatrix();
      mesh.setMatrixAt(i, o.matrix);
    }
    mesh.instanceMatrix.needsUpdate = true;

    // LOD etiketi (canvas sprite)
    const label = makeLabel(
      `${LOD_ADI[lod]} · ${fmt(item.triangles)} üçgen × ${n} = ${fmt(item.triangles * n)} (tek draw-call)`,
      rowIndex === 0 ? '#ffd479' : rowIndex === 1 ? '#9fd0ff' : '#b7f0a8',
    );
    // Etiketleri kameranın BAKTIĞI yönde, sıraların arkasına koy: öne konunca
    // sprite kameraya 1 m'den yakın kalıp ekranı kaplıyordu.
    label.position.set(0, 0.55 + rowIndex * 1.5, -(cols * gap * 0.5 + 2.2));
    instansRoot.add(label);
  });
  updateSceneOverlay();
}

function makeLabel(text: string, color: string): THREE.Sprite {
  const w = 1024;
  const h = 96;
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = 'rgba(16,18,24,0.72)';
  ctx.beginPath();
  const r = 26;
  ctx.moveTo(r, 0);
  ctx.lineTo(w - r, 0);
  ctx.quadraticCurveTo(w, 0, w, r);
  ctx.lineTo(w, h - r);
  ctx.quadraticCurveTo(w, h, w - r, h);
  ctx.lineTo(r, h);
  ctx.quadraticCurveTo(0, h, 0, h - r);
  ctx.lineTo(0, r);
  ctx.quadraticCurveTo(0, 0, r, 0);
  ctx.fill();
  ctx.strokeStyle = color;
  ctx.lineWidth = 4;
  ctx.stroke();
  ctx.fillStyle = color;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  // Metni tuvale sığdır: uzun etiketler kenarlardan kırpılıyordu.
  let px = 44;
  ctx.font = `600 ${px}px system-ui, sans-serif`;
  const maxW = w - 72;
  const tw = ctx.measureText(text).width;
  if (tw > maxW) {
    px = Math.max(22, Math.floor((px * maxW) / tw));
    ctx.font = `600 ${px}px system-ui, sans-serif`;
  }
  ctx.fillText(text, w / 2, h / 2 + 2);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  const mat = new THREE.SpriteMaterial({
    map: tex,
    transparent: true,
    depthWrite: false,
    depthTest: false, // etiketler kılıç sıralarının arkasında kalınca kırpılıyordu
    fog: false,
  });
  const sprite = new THREE.Sprite(mat);
  sprite.renderOrder = 999;
  sprite.scale.set(6.2, 0.581, 1);
  return sprite;
}

function updateInstans(t: number, dt: number): void {
  if (!instansRoot.visible) return;
  instansSpin += dt * 0.42;
  const o = new THREE.Object3D();
  for (const mesh of instansMeshes) {
    const n = mesh.count;
    const cols = Math.ceil(Math.sqrt(n * 2.2));
    for (let i = 0; i < n; i++) {
      mesh.getMatrixAt(i, o.matrix);
      o.matrix.decompose(o.position, o.quaternion, o.scale);
      const cx = i % cols;
      const cz = Math.floor(i / cols);
      o.position.y = 0.45 + (LOD_SIRASI.indexOf(mesh.userData.lod as LodLevel)) * 1.5 + Math.sin(t * 1.6 + cx * 0.5 + cz * 0.4) * 0.03;
      o.rotation.set(0, instansSpin + i * 0.7, 0);
      o.updateMatrix();
      mesh.setMatrixAt(i, o.matrix);
    }
    mesh.instanceMatrix.needsUpdate = true;
  }
}

const LOD_SIRASI: LodLevel[] = ['hero', 'battle', 'crowd'];

/* ═══════════════════════════════════════════════════════════════════════
   7) GÖRÜNÜM 4 · 500v500 MEYDAN SAVAŞI
   ═══════════════════════════════════════════════════════════════════════ */

function buildBattleScene(): void {
  savasRoot = new THREE.Group();
  savasRoot.name = 'savas';
  savasRoot.visible = false;
  scene.add(savasRoot);

  buildItemChips(
    $('savasFactionA'),
    FACTIONS.filter((f) => f.id !== 'custom').map((f) => ({ id: f.id, ad: f.name })),
    battleState.factionA,
    (id) => {
      battleState.factionA = id;
    },
  );
  buildItemChips(
    $('savasFactionB'),
    FACTIONS.filter((f) => f.id !== 'custom').map((f) => ({ id: f.id, ad: f.name })),
    battleState.factionB,
    (id) => {
      battleState.factionB = id;
    },
  );
  buildItemChips(
    $('savasSayi'),
    [
      { id: '100', ad: '100v100' },
      { id: '250', ad: '250v250' },
      { id: '500', ad: '500v500' },
    ],
    String(battleState.size),
    (id) => {
      battleState.size = parseInt(id, 10);
    },
  );

  buildItemChips(
    $('savasKamera'),
    [
      { id: 'serbest', ad: 'Serbest' },
      { id: 'takip', ad: 'Hattı takip et' },
      { id: 'kusbakisi', ad: 'Kuşbakışı' },
    ],
    battleState.cameraMode,
    (id) => {
      battleState.cameraMode = id as 'serbest' | 'takip' | 'kusbakisi';
    },
  );

  $btn('savasKur').addEventListener('click', () => void setupBattle());
  $btn('savasBaslat').addEventListener('click', () => {
    battleState.running = true;
    battle?.reset();
    $btn('savasBaslat').disabled = true;
    $btn('savasSifirla').disabled = false;
    playSound('battleHorn', { intensity: 1.25, pan: -0.35 });
  });
  $btn('savasSifirla').addEventListener('click', () => {
    battle?.reset();
    battleState.running = true;
    $btn('savasBaslat').disabled = true;
    playSound('battleHorn', { intensity: 1, pan: 0.35 });
  });
  $btn('savasBorusu').addEventListener('click', () => playSound('battleHorn', { intensity: 1.3 }));

  // savaş alanı işaretleri: iki ordunun başlangıç hatları
  const lineGeo = new THREE.PlaneGeometry(56, 0.28);
  lineGeo.rotateX(-90 * DEG);
  for (const [z, color] of [[39, 0x6f9bd8], [-39, 0xd88a6f]] as [number, number][]) {
    const m = new THREE.Mesh(
      lineGeo.clone(),
      new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.3, depthWrite: false, fog: false }),
    );
    m.position.set(0, 0.02, z);
    savasRoot.add(m);
  }
}

function armyConfig(faction: string, size: number, seed: number): ArmyConfig {
  // 500 kişilik ordu bileşimi (Bannerlord tarzı): piyade çekirdek,
  // okçu gerisi, az sayıda çavuş/sancaktar, kanatlarda süvari.
  const infantry = Math.round(size * 0.62);
  const archer = Math.round(size * 0.2);
  const sergeant = Math.max(2, Math.round(size * 0.05));
  const banner = Math.max(2, Math.round(size * 0.02));
  const cavalry = Math.max(0, size - infantry - archer - sergeant - banner);
  return {
    faction,
    seed,
    lod: 'crowd',
    phases: 2,
    counts: { infantry, archer, sergeant, banner, cavalry },
  };
}

async function setupBattle(): Promise<void> {
  $btn('savasKur').disabled = true;
  $btn('savasBaslat').disabled = true;
  $btn('savasSifirla').disabled = true;
  $btn('savasBorusu').disabled = true;
  show($('savasIlerlemeKutu'), true);
  show($('savasSkor'), false);

  if (battle) {
    savasRoot.remove(battle.group);
    battle.dispose();
    battle = null;
  }

  const t0 = performance.now();
  battle = new BattleSim({
    armies: [
      armyConfig(battleState.factionA, battleState.size, 11),
      armyConfig(battleState.factionB, battleState.size, 22),
    ],
    sim: { width: 48, separation: 78, spacing: 1.15, engageDistance: 1.5 },
    arrowPool: 110,
    seed: 20261020,
    progressive: true,
  });
  savasRoot.add(battle.group);

  await battle.buildAsync((ratio, label) => {
    $('savasIlerleme').style.width = `${Math.round(ratio * 100)}%`;
    $('savasIlerlemeEtiket').textContent = `${Math.round(ratio * 100)}% · ${label}`;
  });

  const ms = Math.round(performance.now() - t0);
  const st = battle.stats();
  $('savasIlerlemeEtiket').textContent = `hazır · ${ms} ms içinde ${st.armies[0].units + st.armies[1].units} birim üretildi`;
  window.setTimeout(() => show($('savasIlerlemeKutu'), false), 1600);

  $btn('savasKur').disabled = false;
  $btn('savasBaslat').disabled = false;
  $btn('savasBorusu').disabled = false;
  show($('savasSkor'), true);
  battleState.running = true;
  updateBattleScore();
}

function updateBattleScore(): void {
  if (!battle) return;
  const st = battle.stats();
  const [a, b] = st.armies;
  const fa = FactionPalette.byId(battleState.factionA);
  const fb = FactionPalette.byId(battleState.factionB);
  $('savasSkor').innerHTML =
    `<div class="skor-satir"><span class="nokta" style="background:${hexToInput(fa.colors.primary).toString()}"></span>` +
    `<b>${fa.name}</b> ${a.alive}/${a.units}</div>` +
    `<div class="skor-satir"><span class="nokta" style="background:${hexToInput(fb.colors.primary)}"></span>` +
    `<b>${fb.name}</b> ${b.alive}/${b.units}</div>` +
    `<div class="skor-alt">faz: <b>${phaseName(st.phase)}</b> · süre ${st.time.toFixed(1)} sn · ok ${st.arrowsInFlight}` +
    `<br>draw-call ${a.drawCalls + b.drawCalls} · birim başına ${fmt(Math.max(a.trianglesPerUnit, b.trianglesPerUnit))} üçgen</div>`;
}

function phaseName(p: string): string {
  switch (p) {
    case 'muster': return 'toplanma';
    case 'advance': return 'ilerleyiş';
    case 'clash': return 'çarpışma';
    case 'aftermath': return 'savaş sonrası';
    default: return p;
  }
}

function updateBattle(dt: number, t: number): void {
  if (!battle || !savasRoot.visible) return;
  if (battleState.running) battle.update(dt);

  // ── olaylar → ses + efekt (kamera mesafesine göre seçilir, hız sınırlı) ──
  const events = battle.drainEvents(14);
  let played = 0;
  for (const ev of events) {
    const dist = camera.position.distanceTo(ev.position);
    if (dist > 95) continue;
    const pan = clamp((ev.position.x - camera.position.x) / 30, -1, 1);
    const intensity = clamp(1.25 - dist / 90, 0.25, 1.25);
    if (played < 3) {
      switch (ev.type) {
        case 'clash':
          playSound(Math.random() > 0.55 ? 'swordClash' : 'shieldBlock', { intensity, pan, rate: 0.92 + Math.random() * 0.2 });
          played++;
          break;
        case 'bowRelease':
          playSound('bowRelease', { intensity: intensity * 0.7, pan, rate: 0.95 + Math.random() * 0.15 });
          played++;
          break;
        case 'arrowHit':
          playSound('arrowHit', { intensity: intensity * 0.85, pan });
          played++;
          break;
        case 'death':
          if (dist < 26 && Math.random() > 0.6) {
            spawnSparks(ev.position, 0xa33b2b, 18, 0.6);
          }
          break;
        case 'horn':
          playSound('battleHorn', { intensity: 1.2, pan: ev.armyId === 0 ? -0.4 : 0.4 });
          played++;
          break;
      }
    }
    if (ev.type === 'clash' && dist < 22 && sparks.length < 26) {
      spawnSparks(ev.position, 0xffd08a, 22, 0.85);
    }
  }

  // ── savaş kamerası ──
  if (battleState.cameraMode === 'kusbakisi') {
    const target = new THREE.Vector3(0, 0, 0);
    controls.target.lerp(target, 0.06);
    camera.position.lerp(new THREE.Vector3(0, 88, 0.01), 0.04);
  } else if (battleState.cameraMode === 'takip') {
    const front = frontlinePoint();
    controls.target.lerp(front, 0.08);
    const desired = new THREE.Vector3(front.x + 9, front.y + 6.5, front.z + 13);
    camera.position.lerp(desired, 0.05);
  }

  if (frameCount++ % 12 === 0) updateBattleScore();
}

/** İki ordunun temas hattının orta noktası (takip kamerası için). */
function frontlinePoint(): THREE.Vector3 {
  if (!battle) return new THREE.Vector3();
  let best: { x: number; z: number } | null = null;
  let bestD = Infinity;
  const A = battle.armies[0].units;
  const B = battle.armies[1].units;
  for (let i = 0; i < A.length; i += 17) {
    const a = A[i];
    if (!a.alive) continue;
    for (let j = 0; j < B.length; j += 23) {
      const b = B[j];
      if (!b.alive) continue;
      const d = a.pos.distanceToSquared(b.pos);
      if (d < bestD) {
        bestD = d;
        best = { x: (a.pos.x + b.pos.x) / 2, z: (a.pos.z + b.pos.z) / 2 };
      }
    }
  }
  return best ? new THREE.Vector3(best.x, 1.2, best.z) : new THREE.Vector3(0, 1.2, 0);
}

/* ═══════════════════════════════════════════════════════════════════════
   8) ETKİLEŞİM (raycast, klavye, panel bağlantıları)
   ═══════════════════════════════════════════════════════════════════════ */

const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();
let pointerDownAt = { x: 0, y: 0 };

function initInteraction(): void {
  const canvas = renderer.domElement;
  canvas.addEventListener('pointerdown', (e) => {
    pointerDownAt = { x: e.clientX, y: e.clientY };
  });
  canvas.addEventListener('pointerup', (e) => {
    // sürükleme ile tıklamayı ayır
    if (Math.hypot(e.clientX - pointerDownAt.x, e.clientY - pointerDownAt.y) > 5) return;
    if (currentView !== 'vitrin') return;
    const rect = canvas.getBoundingClientRect();
    pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(pointer, camera);
    const targets: THREE.Object3D[] = [];
    for (const item of vitrinItems) {
      targets.push(item.mergedMesh.visible ? item.mergedMesh : item.heroGroup);
    }
    const hits = raycaster.intersectObjects(targets, true);
    if (hits.length > 0) {
      let obj: THREE.Object3D | null = hits[0].object;
      let id: ArmoryItemId | null = null;
      while (obj) {
        if (obj.userData.itemId) {
          id = obj.userData.itemId as ArmoryItemId;
          break;
        }
        obj = obj.parent;
      }
      if (id) {
        selectItem(id);
        if (inspectMode) setInspect(false);
        return;
      }
    }
    if (inspectMode) setInspect(false);
  });

  canvas.addEventListener('dblclick', () => {
    if (currentView === 'vitrin') setInspect(!inspectMode);
  });

  window.addEventListener('keydown', (e) => {
    if ((e.target as HTMLElement)?.tagName === 'INPUT' || (e.target as HTMLElement)?.tagName === 'SELECT') return;
    const k = e.key.toLowerCase();
    if (k === '1') setView('vitrin');
    else if (k === '2') setView('laboratuvar');
    else if (k === '3') setView('instans');
    else if (k === '4') setView('savas');
    else if (k === 'arrowright' || k === 'arrowleft') {
      if (currentView !== 'vitrin') return;
      const i = ARMORY_IDS.indexOf(selectedItemId);
      const next = (i + (k === 'arrowright' ? 1 : ARMORY_IDS.length - 1)) % ARMORY_IDS.length;
      selectItem(ARMORY_IDS[next]);
      e.preventDefault();
    } else if (k === ' ') {
      if (currentView === 'vitrin') vitrinAttackTest();
      else if (currentView === 'laboratuvar') labAttackTest();
      e.preventDefault();
    } else if (k === 'w') {
      wireframe = !wireframe;
      $check('optTelkafes').checked = wireframe;
      applyWireframe();
    } else if (k === 'r') {
      autoRotate = !autoRotate;
      $check('optDondur').checked = autoRotate;
    } else if (k === 'f' && currentView === 'vitrin') {
      setInspect(!inspectMode);
    } else {
      const ses = SESLER.find((s) => s.tus.toLowerCase() === k);
      if (ses) {
        playSound(ses.id);
        if (currentView === 'vitrin') spawnSparks(controls.target.clone(), 0xffd08a, 24, 0.7);
      }
    }
  });

  // görünüm sekmeleri
  for (const b of Array.from($('sekmeler').children)) {
    b.addEventListener('click', () => setView((b as HTMLElement).dataset.gorunum as ViewId));
  }

  // detay paneli butonları
  $btn('btnSaldiri').addEventListener('click', () => vitrinAttackTest());
  $btn('btnGeriAl').addEventListener('click', () => {
    for (const item of vitrinItems) {
      item.heroGroup.rotation.set(0, 0, 0);
      item.mergedMesh.rotation.set(
        ARMORY_CATALOG.find((s) => s.id === item.id)!.displayRotation[0] * DEG,
        ARMORY_CATALOG.find((s) => s.id === item.id)!.displayRotation[1] * DEG,
        ARMORY_CATALOG.find((s) => s.id === item.id)!.displayRotation[2] * DEG,
      );
    }
  });
  $btn('btnOdakla').addEventListener('click', () => setInspect(!inspectMode));

  // görünüm seçenekleri
  $check('optDondur').addEventListener('change', (e) => {
    autoRotate = (e.target as HTMLInputElement).checked;
  });
  $check('optTelkafes').addEventListener('change', (e) => {
    wireframe = (e.target as HTMLInputElement).checked;
    applyWireframe();
  });
  $check('optGolge').addEventListener('change', (e) => {
    renderer.shadowMap.enabled = (e.target as HTMLInputElement).checked;
    scene.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh) {
        const list = Array.isArray(m.material) ? m.material : [m.material];
        for (const mat of list) (mat as THREE.Material).needsUpdate = true;
      }
    });
  });
  $check('optBirlesik').addEventListener('change', (e) => {
    useMerged = (e.target as HTMLInputElement).checked;
    applyMergedToggle();
  });
  $check('optToz').addEventListener('change', (e) => {
    dustEnabled = (e.target as HTMLInputElement).checked;
    dust.visible = dustEnabled && currentView !== 'savas';
  });

  // fraksiyon renkleri + arma
  for (const id of ['renkBirincil', 'renkIkincil', 'renkSus']) {
    $(id).addEventListener('input', () => {
      if (currentView === 'laboratuvar') buildLabCharacter();
      refreshVitrinFaction();
    });
  }
  $select('armaSec').addEventListener('change', () => {
    if (currentView === 'laboratuvar') buildLabCharacter();
    refreshVitrinFaction();
  });

  // ses
  $range('sesSeviye').addEventListener('input', (e) => sfx.setMasterVolume(parseFloat((e.target as HTMLInputElement).value)));
  $range('sesReverb').addEventListener('input', (e) => sfx.setReverb(parseFloat((e.target as HTMLInputElement).value)));

  // ilk kullanıcı jesti → ses kilidini aç
  const unlock = () => {
    unlockAudio();
    window.removeEventListener('pointerdown', unlock);
    window.removeEventListener('keydown', unlock);
  };
  window.addEventListener('pointerdown', unlock);
  window.addEventListener('keydown', unlock);

  window.addEventListener('resize', onResize);
}

function applyWireframe(): void {
  applyMaterialFlags(vitrinRoot, { wire: wireframe });
  applyMaterialFlags(labRoot, { wire: wireframe });
  for (const m of instansMeshes) (m.material as THREE.MeshStandardMaterial).wireframe = wireframe;
}

/** Vitrindeki ekipmanları özel fraksiyon renkleriyle yeniden üretir. */
function refreshVitrinFaction(): void {
  const faction = customFaction(labState.faction);
  vitrinArmory.setFaction(faction);
  for (const item of vitrinItems) {
    const rebuilt = vitrinArmory.buildItem(item.id, 'hero');
    // eski geometri/materyali bırak
    item.stand.remove(item.heroGroup);
    item.stand.remove(item.mergedMesh);
    item.mergedMesh.geometry.dispose();
    (item.mergedMesh.material as THREE.Material).dispose();

    const displayNode = vitrinArmory.createDisplayNode(rebuilt);
    displayNode.position.y = item.baseY;
    displayNode.userData.itemId = item.id;
    item.stand.add(displayNode);
    item.heroGroup = displayNode;

    const mergedMesh = new THREE.Mesh(rebuilt.merged, rebuilt.material.clone());
    mergedMesh.position.y = item.baseY + rebuilt.spec.displayOffset[1] * rebuilt.spec.displayScale;
    mergedMesh.scale.setScalar(rebuilt.spec.displayScale);
    mergedMesh.rotation.set(
      rebuilt.spec.displayRotation[0] * DEG,
      rebuilt.spec.displayRotation[1] * DEG,
      rebuilt.spec.displayRotation[2] * DEG,
    );
    mergedMesh.visible = false;
    mergedMesh.castShadow = true;
    mergedMesh.userData.itemId = item.id;
    item.stand.add(mergedMesh);
    item.mergedMesh = mergedMesh;
    item.merged = rebuilt.merged;
    item.triangles = rebuilt.triangles;
    item.budget = rebuilt.budget;
  }
  applyMergedToggle();
  applyMaterialFlags(vitrinRoot, { wire: wireframe, opacity: inspectMode ? 0.14 : 1 });
  updateDetailPanel();
}

/* ═══════════════════════════════════════════════════════════════════════
   9) ANA DÖNGÜ + BAŞLATMA
   ═══════════════════════════════════════════════════════════════════════ */

function onResize(): void {
  const canvas = renderer.domElement;
  const parent = canvas.parentElement!;
  const w = parent.clientWidth;
  const h = parent.clientHeight;
  renderer.setSize(w, h, false);
  camera.aspect = w / Math.max(1, h);
  camera.updateProjectionMatrix();
}

function updateHud(): void {
  const info = renderer.info;
  $('hudFps').textContent = fpsSmooth.toFixed(0);
  $('hudCagri').textContent = String(info.render.calls);
  const tris = info.render.triangles;
  $('hudUcgen').textContent = tris > 1_000_000 ? `${(tris / 1_000_000).toFixed(2)}M` : tris > 1000 ? `${(tris / 1000).toFixed(1)}K` : String(tris);
  $('hudBirim').textContent =
    currentView === 'savas' && battle
      ? fmt(battle.stats().armies[0].alive + battle.stats().armies[1].alive)
      : currentView === 'instans'
        ? fmt(instansState.count * (instansState.compare ? 3 : 1))
        : currentView === 'laboratuvar' && labCharacter
          ? labHorse ? '1+1' : '1'
          : String(vitrinItems.length);
}

let hudTimer = 0;
function animate(): void {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.05);
  const t = clock.getElapsedTime();

  const inst = 1 / Math.max(dt, 0.0001);
  fpsSmooth += (inst - fpsSmooth) * 0.08;

  // otomatik dönüş yalnızca vitrin/laboratuvarda
  controls.autoRotate = autoRotate && (currentView === 'vitrin' || currentView === 'laboratuvar') && !inspectMode;
  controls.update();

  updateTorches(t);
  updateDust(dt);
  updateEffects(dt);

  if (currentView === 'vitrin') {
    vitrinRune.rotation.y += dt * 0.12;
    // seçili ekipman yavaşça döner ve hafifçe süzülür
    for (const item of vitrinItems) {
      const isSel = item.id === selectedItemId;
      item.spin += dt * (isSel ? 0.55 : 0.12);
      item.heroGroup.rotation.y = item.spin;
      item.mergedMesh.rotation.y = ARMORY_CATALOG.find((s) => s.id === item.id)!.displayRotation[1] * DEG + item.spin;
      const bob = isSel ? Math.sin(t * 1.4) * 0.028 : 0;
      item.heroGroup.position.y = item.baseY + bob;
      item.mergedMesh.position.y = item.baseY + bob + ARMORY_CATALOG.find((s) => s.id === item.id)!.displayOffset[1] * ARMORY_CATALOG.find((s) => s.id === item.id)!.displayScale;
    }
  } else if (currentView === 'laboratuvar') {
    if (labCharacter) {
      labCharacter.animator.ctx.speed = labState.speed;
      labCharacter.update(dt);
    }
    if (labHorse) {
      labHorse.animator.ctx.speed = labState.clip === 'horseWalk' ? labState.speed : 0;
      labHorse.update(dt);
    }
  } else if (currentView === 'instans') {
    updateInstans(t, dt);
  } else if (currentView === 'savas') {
    updateBattle(dt, t);
  }

  renderer.render(scene, camera);

  if (t - hudTimer > 0.25) {
    hudTimer = t;
    updateHud();
    if (audioUnlocked) {
      const v = sfx.getVoiceInfo();
      $('sesDurum').textContent = `ses kilidi: açık · ${v.total} aktif ses · ${v.state}`;
    }
  }
}

function boot(): void {
  try {
    initRenderer();
  } catch (err) {
    uyari(`WebGL başlatılamadı: ${(err as Error).message}`, 20000);
    return;
  }

  sfx = new BattleSoundFX({ masterVolume: 0.85, reverb: 0.35, reverbSeconds: 2.6, maxTotalVoices: 28 });

  buildSky();
  buildLights();
  buildGround();
  buildDust();

  buildVitrin();
  buildLabScene();
  buildInstansScene();
  buildBattleScene();

  buildLabUI();
  buildSoundButtons();
  buildAppearanceUI();
  syncFactionColors();
  initInteraction();

  onResize();
  clock.start();
  setView('vitrin');
  animate();

  // CDN'den three gelmezse kullanıcıyı bilgilendir (çevrimdışı önizleme)
  window.setTimeout(() => {
    if (renderer.info.render.frame === 0) {
      uyari('Sahne çizilemedi. Tarayıcı konsolunu kontrol edin.', 12000);
    }
  }, 3000);
}

if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
}

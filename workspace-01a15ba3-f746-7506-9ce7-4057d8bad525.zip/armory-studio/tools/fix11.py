#!/usr/bin/env python3
"""Bölüm 2: katalog girdileri + demo/Character entegrasyonu."""
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent

# ───────────────────────── Armory.ts: katalog ─────────────────────────
p = ROOT / 'src' / 'Armory.ts'
src = p.read_text(encoding='utf-8')

CATALOG_ADD = '''  {
    id: 'flangedMace',
    name: 'Dilimli Aseray Topuzu',
    cls: 'mace',
    faction: 'Aseray',
    twoHanded: false,
    displayScale: 0.85,
    displayOffset: [0, -0.42, 0],
    displayRotation: [0, 0, 10],
    reach: 0.72,
    weightKg: 1.6,
    description:
      'Yıldız kesitli çelik başı zırh plakasını içe göçertmek için dövüldü. Çöl süvarisinin eyerinde kılıçtan önce bu asılır: kalkan kavsa da kemik kırılır.',
    attack: {
      type: 'bash', grip: [0, 0.16, 0], arm: [-104, -20, 12], strike: [100, 24, -10],
      lunge: 0.12, duration: 0.82, impactAt: 0.32, impactSound: 'shieldBlock',
    },
    showcaseSound: 'shieldBlock',
  },
  {
    id: 'warHammer',
    name: 'Şövalye Savaş Çekici',
    cls: 'mace',
    faction: 'Vlandiya',
    twoHanded: false,
    displayScale: 0.9,
    displayOffset: [0, -0.45, 0],
    displayRotation: [0, 0, 6],
    reach: 0.78,
    weightKg: 2.0,
    description:
      'Dört yüzlü vuruş piramidi miğferi içeriden titretecek kadar yoğun; arkadaki ince gaga zincir halkasının arasını bulur. Turnuva değil, iş aleti.',
    attack: {
      type: 'bash', grip: [0, 0.17, 0], arm: [-118, -26, 14], strike: [114, 28, -12],
      lunge: 0.16, duration: 0.95, impactAt: 0.4, impactSound: 'shieldBlock',
    },
    showcaseSound: 'shieldBlock',
  },
  {
    id: 'morningstar',
    name: 'Zincirli Morningstar',
    cls: 'mace',
    faction: 'Sturgia',
    twoHanded: false,
    displayScale: 0.85,
    displayOffset: [0, -0.42, 0],
    displayRotation: [0, 0, 14],
    reach: 0.68,
    weightKg: 2.4,
    description:
      'Dikenli demir top üç halkalı zincirin ucunda savrulur; savuşturması kolay, kestirmesi imkânsız. Kuzey taygasında kalkanlı duvarı çatlatan köylü silahı.',
    attack: {
      type: 'bash', grip: [0, 0.15, 0], arm: [-96, -30, 20], strike: [110, 34, -16],
      lunge: 0.1, duration: 1.0, impactAt: 0.45, impactSound: 'swordClash',
    },
    showcaseSound: 'swordClash',
  },
  {
    id: 'billhook',
    name: 'Vlandya Billhook\\'u',
    cls: 'polearm',
    faction: 'Vlandiya',
    twoHanded: true,
    displayScale: 2.1,
    displayOffset: [0, -1.05, 0],
    displayRotation: [0, 0, 4],
    reach: 2.05,
    weightKg: 2.6,
    description:
      'Çiftlik çapalarından bozma kanca ağzı süvariyi eyerden çeker, sırt dikeni mızrak gibi iter. Piyade hattının atlılara karşı en ucuz cevabı.',
    attack: {
      type: 'chop', grip: [0, 0.55, 0], arm: [-120, -18, 10], strike: [118, 22, -8],
      lunge: 0.22, duration: 1.1, impactAt: 0.48, impactSound: 'heavyAxeSwing',
    },
    showcaseSound: 'heavyAxeSwing',
  },
  {
    id: 'paviseShield',
    name: 'İmparatorluk Pavise Kalkanı',
    cls: 'shield',
    faction: 'İmparatorluk',
    twoHanded: false,
    displayScale: 1.2,
    displayOffset: [0, -0.6, 0],
    displayRotation: [0, -18, 0],
    reach: 1.1,
    weightKg: 3.6,
    description:
      'Boylu boyunca çelik omurgalı, kavisli dev gövde; okçu siperi olarak yere çakılır, sahra duvarı olur. Ön yüzdeki haç lejyon consecratio\\'sunu taşır.',
    attack: {
      type: 'raise', grip: [0, 0, 0], arm: [-18, 0, 8], strike: [16, 0, -6],
      pullback: 0.1, lunge: 0, duration: 1.0, impactAt: 0.5, impactSound: 'shieldBlock',
    },
    showcaseSound: 'shieldBlock',
  },
  {
    id: 'cavalryRound',
    name: 'Kuzait Süvari Round Kalkanı',
    cls: 'shield',
    faction: 'Kuzait',
    twoHanded: false,
    displayScale: 0.62,
    displayOffset: [0, -0.31, 0],
    displayRotation: [0, -24, 0],
    reach: 0.55,
    weightKg: 1.7,
    description:
      'Derin bombeli çelik kubbe: okları kaydırır, yakın dövüşte yumruk gibi kullanılır. Bozkır akıncısının sol kolunda hafifliğinden ödün vermez.',
    attack: {
      type: 'raise', grip: [0, 0, 0], arm: [-22, 0, 10], strike: [20, 0, -8],
      pullback: 0.08, lunge: 0, duration: 0.9, impactAt: 0.45, impactSound: 'shieldBlock',
    },
    showcaseSound: 'shieldBlock',
  },
  {
    id: 'nasalHelm',
    name: 'Lejyon Nasal Miğferi',
    cls: 'armor',
    faction: 'İmparatorluk',
    twoHanded: false,
    displayScale: 0.42,
    displayOffset: [0, -0.1, 0],
    displayRotation: [0, -22, 0],
    reach: 0.34,
    weightKg: 1.3,
    description:
      'Konik tasın alnından inen nasal çubuğu burun kökünü, ense dilimleri boyun vuruşlarını karşılar. Lejyon veteranının kırk yıllık sigortası.',
    attack: {
      type: 'raise', grip: [0, 0, 0], arm: [-24, 0, 0], strike: [22, 0, 0],
      lunge: 0, duration: 1.2, impactAt: 0.6, impactSound: 'shieldBlock',
    },
    showcaseSound: 'battleHorn',
  },
  {
    id: 'kettleHat',
    name: 'Sturgia Kettle Hat\\'ı',
    cls: 'armor',
    faction: 'Sturgia',
    twoHanded: false,
    displayScale: 0.36,
    displayOffset: [0, -0.08, 0],
    displayRotation: [0, -22, 0],
    reach: 0.3,
    weightKg: 1.0,
    description:
      'Geniş konik kenarlığı yukarıdan düşen ok ve gürzü sekiyor; görüşü kapatmadığı için balta hattında great helm\\'den yeğ. Kar fırtınasında şemsiye niyetine de geçer.',
    attack: {
      type: 'raise', grip: [0, 0, 0], arm: [-24, 0, 0], strike: [22, 0, 0],
      lunge: 0, duration: 1.2, impactAt: 0.6, impactSound: 'shieldBlock',
    },
    showcaseSound: 'battleHorn',
  },
];
'''

idx = src.find('export const ARMORY_CATALOG')
if idx < 0:
    print('EKSİK: ARMORY_CATALOG')
    sys.exit(1)
end = src.find('\n];', idx)
if end < 0:
    print('EKSİK: katalog sonu')
    sys.exit(1)
src = src[:end] + '\n' + CATALOG_ADD + src[end + 3:]
p.write_text(src, encoding='utf-8')
print('Armory.ts: 8 katalog girdisi eklendi.')

# ───────────────────────── demo/app.ts ─────────────────────────
d = ROOT / 'demo' / 'app.ts'
txt = d.read_text(encoding='utf-8')

def rep2(old: str, new: str):
    global txt
    if old not in txt:
        print(f'EKSİK (demo): {old[:60]!r}')
        sys.exit(1)
    txt = txt.replace(old, new, 1)

rep2(
    "    case 'axe': return 'Baltalar';",
    "    case 'axe': return 'Baltalar';\n    case 'mace': return 'Topuzlar & Çekiçler';",
)
rep2(
    "  const silahlar = ARMORY_CATALOG.filter((s) => ['sword', 'axe', 'polearm', 'bow'].includes(s.cls));",
    "  const silahlar = ARMORY_CATALOG.filter((s) => ['sword', 'axe', 'mace', 'polearm', 'bow'].includes(s.cls));",
)
rep2(
    "    ARMORY_CATALOG.filter((s) => ['sword', 'axe', 'bow'].includes(s.cls) || s.id === 'arrow').map((s) => ({",
    "    ARMORY_CATALOG.filter((s) => ['sword', 'axe', 'mace', 'bow'].includes(s.cls) || s.id === 'arrow').map((s) => ({",
)
d.write_text(txt, encoding='utf-8')
print('demo/app.ts: grup + seçim listeleri güncellendi.')

# ───────────────────────── Character.ts: mount'lar ─────────────────────────
c = ROOT / 'src' / 'Character.ts'
ctx_ = c.read_text(encoding='utf-8')

def rep3(old: str, new: str):
    global ctx_
    if old not in ctx_:
        print(f'EKSİK (char): {old[:60]!r}')
        sys.exit(1)
    ctx_ = ctx_.replace(old, new, 1)

rep3(
    "  warAxe: { joint: 'weaponR', position: [0.01, -0.3, 0.01], rotation: [0, 0, 0], scale: 1 },",
    "  warAxe: { joint: 'weaponR', position: [0.01, -0.3, 0.01], rotation: [0, 0, 0], scale: 1 },\n"
    "  flangedMace: { joint: 'weaponR', position: [0.01, -0.26, 0.01], rotation: [0, 0, 0], scale: 1 },\n"
    "  warHammer: { joint: 'weaponR', position: [0.01, -0.28, 0.01], rotation: [0, 0, 0], scale: 1 },\n"
    "  morningstar: { joint: 'weaponR', position: [0.01, -0.24, 0.01], rotation: [0, 0, 0], scale: 1 },",
)
rep3(
    "  halberd: { joint: 'weaponR', position: [0.02, -0.78, 0.02], rotation: [0, 0, 0], scale: 1 },",
    "  halberd: { joint: 'weaponR', position: [0.02, -0.78, 0.02], rotation: [0, 0, 0], scale: 1 },\n"
    "  billhook: { joint: 'weaponR', position: [0.02, -0.8, 0.02], rotation: [0, 0, 0], scale: 1 },",
)
rep3(
    "  kiteShield: { joint: 'forearmL', position: [0.07, -0.16, -0.02], rotation: [0, -90 * DEG, 0], scale: 1 },",
    "  kiteShield: { joint: 'forearmL', position: [0.07, -0.16, -0.02], rotation: [0, -90 * DEG, 0], scale: 1 },\n"
    "  paviseShield: { joint: 'forearmL', position: [0.09, -0.3, -0.02], rotation: [0, -90 * DEG, 0], scale: 1 },\n"
    "  cavalryRound: { joint: 'forearmL', position: [0.05, -0.12, -0.01], rotation: [0, -90 * DEG, 0], scale: 1 },",
)
rep3(
    "  hornedHelm: { joint: 'head', position: [0, 0.05, 0], rotation: [0, 0, 0], scale: 1 },",
    "  hornedHelm: { joint: 'head', position: [0, 0.05, 0], rotation: [0, 0, 0], scale: 1 },\n"
    "  nasalHelm: { joint: 'head', position: [0, 0.045, 0], rotation: [0, 0, 0], scale: 1 },\n"
    "  kettleHat: { joint: 'head', position: [0, 0.05, 0], rotation: [0, 0, 0], scale: 1 },",
)
rep3(
    "    case 'vikingShield':\n    case 'kiteShield': return 'backShield';",
    "    case 'vikingShield':\n    case 'kiteShield':\n    case 'paviseShield':\n    case 'cavalryRound': return 'backShield';",
)
rep3(
    "    case 'warAxe':\n    case 'bardiche': return 'backAxe';",
    "    case 'warAxe':\n    case 'bardiche':\n    case 'flangedMace':\n    case 'warHammer':\n    case 'morningstar': return 'backAxe';",
)
c.write_text(ctx_, encoding='utf-8')
print('Character.ts: mount + backMountFor güncellendi.')

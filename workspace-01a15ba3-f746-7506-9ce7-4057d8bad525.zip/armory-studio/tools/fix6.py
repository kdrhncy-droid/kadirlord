import io

# ── Core.ts: inline MaterialDef'lerde factionTint'i uygula ──
p = 'src/Core.ts'
s = io.open(p, encoding='utf-8').read()
old = """  const def = matLib.resolve(piece.material);
  return normalizeGeometry(g, def ? def.color : 0xffffff);"""
new = """  const def = matLib.resolve(piece.material);
  let color = def ? def.color : 0xffffff;
  // Satır içi (inline) materyal tanımları da fraksiyon tint'ine saygı duyar.
  const faction = matLib.getFaction();
  if (def && def.factionTint && faction) color = faction.colorFor(def.factionTint);
  return normalizeGeometry(g, color);"""
assert old in s
s = s.replace(old, new)
io.open(p, 'w', encoding='utf-8').write(s)

# ── Armor.ts düzeltmeleri ──
p = 'src/Armor.ts'
s = io.open(p, encoding='utf-8').read()
n = 0


def rep(old, new, required=True):
    global s, n
    if old not in s:
        if required:
            raise SystemExit('BULUNAMADI: ' + old[:160])
        return
    s = s.replace(old, new, 1)
    n += 1


rep("  jitterGeometry,\n  profile2,", "  jitterGeometry,\n  mergePieces,\n  profile2,")

# greave arkası açık olacak şekilde öne baksın
rep("ctx.rad(7), ctx.steps(3), true, -70 * DEG, 220 * DEG", "ctx.rad(7), ctx.steps(3), true, -110 * DEG, 220 * DEG")

# orta tier göğüs levhası: rotasyonsuz, doğru konum
rep("""    const breast = plateShell(
      [[-0.13, 0.24], [-0.16, 0.1], [-0.13, -0.06], [0.13, -0.06], [0.16, 0.1], [0.13, 0.24]],
      [[0, 0.02], [0.055, 0.032], [0.088, 0.012], [0.095, -0.02]],
    );
    P.push({ geometry: breast, material: 'plate', joint: 'chest', position: [0, 0.02, 0.085], rotation: [0, 0, 0] });""",
    """    const breast = plateShell(
      [[-0.13, 0.14], [-0.155, 0.0], [-0.12, -0.16], [0.12, -0.16], [0.155, 0.0], [0.13, 0.14]],
      [[0, 0.012], [0.05, 0.03], [0.085, 0.012], [0.092, -0.018]],
    );
    P.push({ geometry: breast, material: 'plate', joint: 'chest', position: [0, -0.04, 0.1] });""")

# ayak parçaları yere bassın
rep("P.push({ geometry: sabaton, material: 'plate', joint, position: [0, -0.035, 0.055] });",
    "P.push({ geometry: sabaton, material: 'plate', joint, position: [0, -0.06, 0.055] });")
rep("P.push({ geometry: toe, material: 'plateBright', joint, position: [0, -0.04, 0.19] });",
    "P.push({ geometry: toe, material: 'plateBright', joint, position: [0, -0.062, 0.19] });")
rep("P.push({ geometry: lame, material: 'plateDark', joint, position: [0, -0.018, 0.02 + i * 0.055] });",
    "P.push({ geometry: lame, material: 'plateDark', joint, position: [0, -0.04, 0.02 + i * 0.055] });")
rep("P.push({ geometry: boot, material: ctx.tier === 'light' ? 'leatherDark' : 'leather', joint, position: [0, -0.035, 0.05] });",
    "P.push({ geometry: boot, material: ctx.tier === 'light' ? 'leatherDark' : 'leather', joint, position: [0, -0.05, 0.05] });")
rep("P.push({ geometry: toe, material: 'leatherDark', joint, position: [0, -0.045, 0.185] });",
    "P.push({ geometry: toe, material: 'leatherDark', joint, position: [0, -0.062, 0.185] });")
rep("P.push({ geometry: spur, material: 'gold', joint, position: [side * 0.05, -0.02, -0.07] });",
    "P.push({ geometry: spur, material: 'gold', joint, position: [side * 0.05, -0.04, -0.07] });")

# surcoat: konum + taper matematiği + omuz askıları
rep("""    P.push({
      geometry: panel,
      material: { key: 'surcoatPanel', color: ctx.faction.colors.primary, metalness: 0.04, roughness: 0.95, flatShading: true, side: THREE.DoubleSide, factionTint: 'primary' },
      joint: 'pelvis',
      position: [0, 0.16, side * 0.175],
    });""",
    """    P.push({
      geometry: panel,
      material: { key: 'surcoatPanel', color: ctx.faction.colors.primary, metalness: 0.04, roughness: 0.95, flatShading: true, side: THREE.DoubleSide, factionTint: 'primary' },
      joint: 'pelvis',
      position: [0, 0.12, side * 0.178],
    });""")
rep("""      const taper = 1 - 0.18 * (1 - (y + 0.31) / 0.62) + 0.12 * Math.max(0, -(y + 0.1));""",
    """      const v = (y + 0.31) / 0.62; // 0 = etek ucu, 1 = göğüs
      const taper = 0.82 + 0.3 * v + 0.1 * Math.max(0, 0.25 - v);""")
rep("""      const strapGeo = tubeFromPoints([v3(side * 0.13, 0.42, 0.16), v3(side * 0.16, 0.5, 0.06), v3(side * 0.13, 0.44, -0.16)], 0.016, 4, 2);""",
    """      const strapGeo = tubeFromPoints(
        [v3(side * 0.11, 0.44, 0.17), v3(side * 0.155, 0.53, 0.05), v3(side * 0.11, 0.45, -0.17)],
        0.016,
        4,
        2,
      );""")
rep("""        joint: 'pelvis',
        position: [(cp.position?.[0] ?? 0), 0.26 + (cp.position?.[1] ?? 0), 0.19],""",
    """        joint: 'pelvis',
        position: [(cp.position?.[0] ?? 0), 0.3 + (cp.position?.[1] ?? 0), 0.195],""")

# great helm iç kabuk: gereksiz scale çağrısını kaldır
rep("""      inner.scale(1, 1, 1);
      P.push({ geometry: flip(inner), material: 'dark', joint: 'head', position: [0, 0.055, 0] });""",
    """      P.push({ geometry: flip(inner), material: 'dark', joint: 'head', position: [0, 0.055, 0] });""")

# buildTorso kullanılmayan parametre
rep("function buildTorso(ctx: Ctx, surcoat: boolean): ArmorPiece[] {", "function buildTorso(ctx: Ctx): ArmorPiece[] {")
rep("case 'torso': push('torso', buildTorso(ctx, opts.surcoat ?? tier !== 'light')); break;",
    "case 'torso': push('torso', buildTorso(ctx)); break;")

# nefes deliklerindeki gereksiz -0.0
rep("position: [Math.sin(a) * 0.147, y - 0.0, Math.cos(a) * 0.147]", "position: [Math.sin(a) * 0.147, y, Math.cos(a) * 0.147]")

io.open(p, 'w', encoding='utf-8').write(s)
print('Armor düzeltmeleri:', n)

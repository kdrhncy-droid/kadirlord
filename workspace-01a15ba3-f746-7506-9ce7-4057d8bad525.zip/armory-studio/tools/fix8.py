import io

# ══════════ 1) Core.ts: domeShell (kapalı bombeli yüzey) ══════════
p = 'src/Core.ts'
s = io.open(p, encoding='utf-8').read()
helper = '''
/**
 * KAPALI BOMBELİ YÜZEY (kalkan yüzü, miğfer tası, göğüs kabuğu).
 *
 * shellSweep'ten farkı: shellSweep kontur boyunca bir KENAR BANDI üretir
 * (içi boş çerçeve); domeShell ise konturu merkezden kenara doğru küçülten
 * kapalı bir kabuk üretir.
 *
 * @param outline  kapalı, saat yönünün tersine (CCW) kontur — XY düzleminde
 * @param profile  [r, z] çiftleri; r = 0 (tepe/merkez) → r = 1 (kenar),
 *                 z = yükseklik (yüzeyin +Z'ye bombe miktarı)
 * @param opts     flip (sarım yönü), jitter, facet, cap (merkez üçgenleri)
 */
export function domeShell(
  outline: THREE.Vector2[],
  profile: Vec2Tuple[],
  opts: { flip?: boolean; jitter?: number; facet?: number; cap?: boolean } = {},
): THREE.BufferGeometry {
  const O = outline.length;
  const P = Math.max(2, profile.length);
  const rings = opts.cap ? P - 1 : P;
  const vertsPerRing = O;
  const pos = new Float32Array(((opts.cap ? 1 : 0) + rings) * vertsPerRing * 3);
  const idx: number[] = [];

  // profil normalize: r değerleri 0..1 aralığına ölçeklenir
  let rMax = 0;
  for (const q of profile) rMax = Math.max(rMax, Math.abs(q[0]));
  if (rMax <= 0) rMax = 1;

  let w = 0;
  if (opts.cap) {
    // merkez halkası: tüm köşeler tepe noktasında birleşir
    const cz = profile[0][1];
    for (let i = 0; i < O; i++) {
      pos[w++] = 0;
      pos[w++] = 0;
      pos[w++] = cz;
    }
  }
  const firstRing = opts.cap ? 1 : 0;
  for (let p2 = firstRing; p2 < firstRing + rings; p2++) {
    const src = opts.cap ? p2 : p2;
    const r = profile[src][0] / rMax;
    const z = profile[src][1];
    for (let i = 0; i < O; i++) {
      pos[w++] = outline[i].x * r;
      pos[w++] = outline[i].y * r;
      pos[w++] = z;
    }
  }

  const totalRings = (opts.cap ? 1 : 0) + rings;
  for (let ring = 0; ring < totalRings - 1; ring++) {
    for (let i = 0; i < O; i++) {
      const i2 = (i + 1) % O;
      const a = ring * O + i;
      const b = ring * O + i2;
      const c = (ring + 1) * O + i;
      const d = (ring + 1) * O + i2;
      idx.push(a, c, b, b, c, d);
    }
  }

  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setIndex(idx);
  g.computeVertexNormals();
  if (opts.flip) flipWinding(g);
  if (opts.jitter) jitterGeometry(g, opts.jitter, 4242);
  if (opts.facet) quantizeGeometry(g, opts.facet);
  return g;
}
'''
marker = "/* ═══════════════════════════════════════════════════════════════════════\n   OTOMATİK LOD İNDİRGEME"
assert marker in s
s = s.replace(marker, helper + "\n" + marker, 1)
io.open(p, 'w', encoding='utf-8').write(s)

# ══════════ 2) Armory.ts: kalkanlar ══════════
p = 'src/Armory.ts'
s = io.open(p, encoding='utf-8').read()

s = s.replace("  quantizeGeometry,\n  reduceToBudget,", "  domeShell,\n  quantizeGeometry,\n  reduceToBudget,")
if 'domeShell,' not in s.split('export')[0]:
    # import bloğuna ekle
    s = s.replace("import {\n", "import {\n  domeShell,\n", 1)

# ── Viking kalkanı: gerçek boyut (0.88 m) + kapalı bombeli yüz ──
old_viking_face = """  const outline = shieldOutline('round', hero ? 14 : 10);
  const R = 0.36;
  const dome = hero ? 0.055 : 0.05;

  // ── ön yüz: merkezden kenara hafif kubbe ──
  const face = new THREE.BufferGeometry();
  const faceShell = shellSweepFixed(outline, [
    [0, 0.028 + dome],
    [R * 0.62, 0.022 + dome * 0.86],
    [R * 0.9, 0.008],
    [R, -0.012],
  ]);
  face.copy(faceShell);
  P.push({ geometry: face, material: 'wood' });

  // ── arka yüz ──
  const back = shellSweepFixed(outline, [
    [0, -0.026],
    [R * 0.6, -0.02],
    [R * 0.92, -0.006],
    [R, -0.012],
  ]);
  P.push({ geometry: back, material: 'woodDark' });"""
new_viking_face = """  // Tarihsel ölçü: Viking yuvarlak kalkanı ≈ 0.88 m çap, 8-12 cm bombe.
  const R = 0.44;
  const outline = shieldOutline('round', hero ? 12 : 9, R / 0.36);
  const dome = hero ? 0.062 : 0.055;

  // ── ön yüz: merkezden kenara hafif kubbe (KAPALI kabuk) ──
  const face = domeShell(
    outline,
    [
      [0, dome],
      [0.42, dome * 0.94],
      [0.72, dome * 0.7],
      [0.92, dome * 0.3],
      [1, -0.006],
    ],
    { cap: true, jitter: ctx.jitter, facet: hero ? 0.008 : 0 },
  );
  P.push({ geometry: face, material: 'wood' });

  // ── arka yüz: düze yakın, içbükey ──
  const back = domeShell(
    outline,
    [
      [0, -0.03],
      [0.5, -0.026],
      [0.85, -0.016],
      [1, -0.006],
    ],
    { cap: true, jitter: ctx.jitter },
  );
  P.push({ geometry: back, material: 'woodDark' });

  // ── kenar kalınlığı (ön ve arka yüzü birleştiren çember bandı) ──
  const edge = shellSweepFixed(outline, [[-0.012, dome * 0.12], [0.012, dome * 0.12], [0.012, -0.012], [-0.012, -0.012]]);
  P.push({ geometry: edge, material: 'woodDark' });"""
assert old_viking_face in s
s = s.replace(old_viking_face, new_viking_face)

# viking: kalan boyutlara bağlı değerler
s = s.replace("    for (let i = 0; i < 5; i++) {\n      const x = -0.28 + i * 0.14;", "    for (let i = 0; i < 5; i++) {\n      const x = -0.34 + i * 0.17;")
s = s.replace("    const batten = new THREE.BoxGeometry(0.03, 0.66, 0.014);", "    const batten = new THREE.BoxGeometry(0.034, 0.82, 0.014);")
s = s.replace("  const bossBase = new THREE.CylinderGeometry(0.115, 0.125, 0.02, ctx.rad(8));", "  const bossBase = new THREE.CylinderGeometry(0.13, 0.142, 0.022, ctx.rad(8));")
s = s.replace("  const bossDome = new THREE.ConeGeometry(0.1, hero ? 0.1 : 0.09, ctx.rad(8));\n  bossDome.rotateX(90 * DEG);\n  P.push({ geometry: bossDome, material: 'steel', position: [0, 0, 0.1] });",
              "  const bossDome = new THREE.ConeGeometry(0.115, hero ? 0.11 : 0.1, ctx.rad(8));\n  bossDome.rotateX(90 * DEG);\n  P.push({ geometry: bossDome, material: 'steel', position: [0, 0, 0.105] });")
s = s.replace("  const strap = new THREE.BoxGeometry(0.05, 0.5, 0.012);\n  P.push({ geometry: strap, material: 'leather', position: [0, 0.06, -0.042] });",
              "  const strap = new THREE.BoxGeometry(0.055, 0.62, 0.012);\n  P.push({ geometry: strap, material: 'leather', position: [0, 0.06, -0.045] });")
s = s.replace("  const paintRing = new THREE.TorusGeometry(R * 0.62, hero ? 0.022 : 0.026, 3, hero ? 14 : 9);\n  P.push({ geometry: paintRing, material: 'cloth', position: [0, 0, 0.032] });",
              "  const paintRing = new THREE.TorusGeometry(R * 0.62, hero ? 0.024 : 0.028, 3, hero ? 12 : 8);\n  P.push({ geometry: paintRing, material: 'cloth', position: [0, 0, dome * 0.86] });")
s = s.replace("    const buckle = new THREE.TorusGeometry(0.022, 0.005, 3, 6);\n    P.push({ geometry: buckle, material: 'bronze', position: [0, 0.22, -0.048] });",
              "    const buckle = new THREE.TorusGeometry(0.024, 0.005, 3, 6);\n    P.push({ geometry: buckle, material: 'bronze', position: [0, 0.27, -0.05] });")
s = s.replace("  const rim = new THREE.TorusGeometry(R + 0.004, 0.016, hero ? 3 : 3, hero ? 14 : 10);\n  P.push({ geometry: rim, material: 'iron', position: [0, 0, 0.006] });",
              "  const rim = new THREE.TorusGeometry(R + 0.004, 0.017, 3, hero ? 12 : 9);\n  P.push({ geometry: rim, material: 'iron', position: [0, 0, 0.004] });")
s = s.replace("    P.push(...rivets(ctx, 6, 0.108, 0.009, 0.068, 'iron'));", "    P.push(...rivets(ctx, 6, 0.124, 0.009, 0.072, 'iron'));")

# ── Kite kalkanı: 1.21 m boy + içbükey (vücuda saran) yüz ──
old_kite = """  const outline = shieldOutline('kite', hero ? 10 : 7);
  const dome = hero ? 0.1 : 0.09;

  // ── ön yüz (kavisli/bombeli) ──
  const face = shellSweepFixed(outline, [
    [0, 0.03 + dome],
    [0.13, 0.02 + dome * 0.84],
    [0.27, 0.004],
    [0.335, -0.055],
  ]);
  P.push({ geometry: face, material: 'cloth' });

  // ── iç (arka) yüz ──
  const back = shellSweepFixed(outline, [
    [0, -0.028],
    [0.14, -0.022],
    [0.28, -0.01],
    [0.335, -0.055],
  ]);
  P.push({ geometry: back, material: 'woodDark' });"""
new_kite = """  // Tarihsel ölçü: uçurtma kalkanı ≈ 0.60 m genişlik × 1.20 m boy.
  const outline = shieldOutline('kite', hero ? 9 : 6, 0.82);
  const dome = hero ? 0.105 : 0.095;

  // ── ön yüz: kenarlara doğru İÇE kıvrılan (vücudu saran) kapalı kabuk ──
  const face = domeShell(
    outline,
    [
      [0, dome],
      [0.35, dome * 0.9],
      [0.68, dome * 0.6],
      [0.9, dome * 0.16],
      [1, -0.05],
    ],
    { cap: true, jitter: ctx.jitter, facet: hero ? 0.008 : 0 },
  );
  P.push({ geometry: face, material: 'cloth' });

  // ── iç (arka) yüz ──
  const back = domeShell(
    outline,
    [
      [0, dome - 0.05],
      [0.45, dome * 0.82 - 0.044],
      [0.8, dome * 0.4 - 0.03],
      [1, -0.05],
    ],
    { cap: true, jitter: ctx.jitter },
  );
  P.push({ geometry: back, material: 'woodDark' });"""
assert old_kite in s
s = s.replace(old_kite, new_kite)

s = s.replace("      position: [(cp.position?.[0] ?? 0) * 0.92, 0.06 + (cp.position?.[1] ?? 0) * 0.92, dome + 0.036],",
              "      position: [(cp.position?.[0] ?? 0) * 0.78, 0.05 + (cp.position?.[1] ?? 0) * 0.78, dome + 0.014],")
s = s.replace("  const chargePieces = buildCharge(ctx.faction.charge, ctx.faction.colors.secondary, hero ? 0.17 : 0.16, ctx.faction.colors.trim);",
              "  const chargePieces = buildCharge(ctx.faction.charge, ctx.faction.colors.secondary, hero ? 0.145 : 0.14, ctx.faction.colors.trim);")
s = s.replace("    const rib = new THREE.BoxGeometry(0.028, 1.16, 0.02);\n    P.push({ geometry: rib, material: 'steel', position: [0, -0.14, dome * 0.55 + 0.014] });",
              "    const rib = new THREE.BoxGeometry(0.026, 0.95, 0.02);\n    P.push({ geometry: rib, material: 'steel', position: [0, -0.12, dome * 0.86] });")
s = s.replace("""  const rivetPts: Vec3Tuple[] = hero
    ? [[0, 0.46, 0.06], [0.28, 0.32, 0.03], [-0.28, 0.32, 0.03], [0.24, -0.24, 0.01], [-0.24, -0.24, 0.01], [0, -0.8, 0.0]]
    : [[0, 0.46, 0.06], [0.28, 0.3, 0.03], [-0.28, 0.3, 0.03], [0, -0.78, 0.0]];""",
"""  const rivetPts: Vec3Tuple[] = hero
    ? [[0, 0.38, dome + 0.01], [0.23, 0.26, dome * 0.92], [-0.23, 0.26, dome * 0.92], [0.2, -0.2, dome * 0.7], [-0.2, -0.2, dome * 0.7], [0, -0.66, dome * 0.3]]
    : [[0, 0.38, dome + 0.01], [0.23, 0.25, dome * 0.92], [-0.23, 0.25, dome * 0.92], [0, -0.64, dome * 0.3]];""")
s = s.replace("""  const guige = tubeFromPoints(
    [v3(-0.2, 0.2, -0.06), v3(-0.06, -0.02, -0.12), v3(0.14, -0.18, -0.07)],""",
"""  const guige = tubeFromPoints(
    [v3(-0.17, 0.17, dome - 0.16), v3(-0.05, -0.02, dome - 0.2), v3(0.12, -0.15, dome - 0.16)],""")
s = s.replace("    const enarme = tubeFromPoints([v3(0.1, 0.12, -0.05), v3(0.02, 0.0, -0.1), v3(-0.08, -0.1, -0.05)], 0.014, 4, 2);",
              "    const enarme = tubeFromPoints([v3(0.09, 0.1, dome - 0.15), v3(0.02, 0.0, dome - 0.19), v3(-0.07, -0.09, dome - 0.15)], 0.014, 4, 2);")
s = s.replace("    P.push({ geometry: buckle, material: 'bronze', position: [-0.19, 0.2, -0.06] });",
              "    P.push({ geometry: buckle, material: 'bronze', position: [-0.17, 0.17, dome - 0.16] });")
s = s.replace("  const chausse = new THREE.ConeGeometry(hero ? 0.075 : 0.07, 0.2, ctx.rad(5));\n  chausse.rotateX(180 * DEG);\n  P.push({ geometry: chausse, material: 'steelDark', position: [0, -0.86, 0.0] });",
              "  const chausse = new THREE.ConeGeometry(hero ? 0.062 : 0.058, 0.17, ctx.rad(5));\n  chausse.rotateX(180 * DEG);\n  P.push({ geometry: chausse, material: 'steelDark', position: [0, -0.71, 0.0] });")

# kite kenar bandı: dışa offset 0.028 → yeni ölçekte 0.024
s = s.replace("    band.push(v2(outline[i].x + nx * 0.028, outline[i].y + ny * 0.028));",
              "    band.push(v2(outline[i].x + nx * 0.024, outline[i].y + ny * 0.024));")

io.open(p, 'w', encoding='utf-8').write(s)
print('Armory kalkanlar güncellendi')

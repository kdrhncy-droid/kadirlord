#!/usr/bin/env python3
"""Çakışan üst-seviye yardımcı isimleri modül-özel isimlere çevirir.

Amaç: build_html.js'teki otomatik yeniden adlandırıcının GLSL şablon
dizgilerini (clamp / mix / smoothstep) bozmasını kökünden engellemek.
"""
import re
import sys
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent

EDITS = [
    # (dosya, eski isim, yeni isim)
    ('src/BattleSoundFX.ts', 'clamp01', 'clamp01Fx'),
    ('src/BattleSoundFX.ts', 'clamp', 'clampFx'),
    ('src/Armor.ts', 'mix', 'mixArmor'),
    ('src/Character.ts', 'mix', 'mixChar'),
]

misses = []
for rel, old, new in EDITS:
    p = ROOT / rel
    text = p.read_text(encoding='utf-8')
    pattern = re.compile(r'(?<![A-Za-z0-9_$])' + re.escape(old) + r'(?![A-Za-z0-9_$])')
    hits = len(pattern.findall(text))
    if hits == 0:
        misses.append(f'{rel}: {old}')
        continue
    p.write_text(pattern.sub(new, text), encoding='utf-8')
    print(f'{rel}: {old} -> {new}  ({hits} yer)')

# demo/app.ts: yerel clamp'i sil, Core'dan al.
demo = ROOT / 'demo' / 'app.ts'
text = demo.read_text(encoding='utf-8')
old_fn = """function clamp(v: number, lo: number, hi: number): number {
  return v < lo ? lo : v > hi ? hi : v;
}
"""
if old_fn in text:
    text = text.replace(old_fn, '', 1)
    text = text.replace("""import {
  BUDGET,
  DEG,
  LodLevel,""", """import {
  BUDGET,
  DEG,
  clamp,
  LodLevel,""", 1)
    demo.write_text(text, encoding='utf-8')
    print('demo/app.ts: yerel clamp silindi, Core.clamp import edildi')
else:
    misses.append('demo/app.ts: yerel clamp fonksiyonu bulunamadı')

if misses:
    print('\nEKSİKLER:')
    for m in misses:
        print('  -', m)
    sys.exit(1)
print('\ntamam')

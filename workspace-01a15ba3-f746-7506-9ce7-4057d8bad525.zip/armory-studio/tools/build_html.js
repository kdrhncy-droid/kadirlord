/**
 * BannerForge · tek dosya HTML derleyicisi
 * ─────────────────────────────────────────
 * src/*.ts + demo/app.ts + demo/style.css + demo/shell.html → armory-studio.html
 *
 * Neden özel derleyici?
 *  • İstenen çıktı TEK, çift tıklamayla açılabilen bir HTML dosyası.
 *  • three.js CDN'den importmap ile geliyor (paket yok, bundler yok).
 *  • Modüller arası bağımlılık grafı topo-lojik sırayla çözülüp tek bir
 *    <script type="module"> içine gömülüyor; 'three' ve 'three/addons/*'
 *    importları korunuyor, göreli importlar kaldırılıyor.
 *
 * Kullanım:  node tools/build_html.js
 */
const fs = require('fs');
const path = require('path');
// TypeScript derleyicisi: tip sözdizimini gerçek JS'e çevirmek için kullanılır.
const ts = require('typescript');

const ROOT = path.resolve(__dirname, '..');
const SRC = path.join(ROOT, 'src');
const DEMO = path.join(ROOT, 'demo');
const OUT = path.join(ROOT, 'armory-studio.html');

const MODULES = ['Core.ts', 'Faction.ts', 'Rig.ts', 'Armory.ts', 'Armor.ts', 'Character.ts', 'Horse.ts', 'Army.ts', 'BattleSoundFX.ts'];

/** Dosyayı oku + satır sonlarını normalize et. */
function read(p) {
  return fs.readFileSync(p, 'utf8').replace(/\r\n/g, '\n');
}

/**
 * Bir modülün göreli import satırlarını söker, dış (three) importlarını toplar.
 * Tip-only importlar çalışma zamanında yok sayılır.
 */
function stripImports(code, moduleName) {
  const external = new Map(); // kaynak → ad kümesi
  const importRe = /^import\s+(?:type\s+)?([\s\S]*?)\s+from\s+['"]([^'"]+)['"];?\s*$/gm;
  const out = code.replace(importRe, (whole, clause, source) => {
    if (source.startsWith('.')) return ''; // göreli → gömülü modüllerden gelecek
    const isTypeOnly = /^import\s+type\s/.test(whole);
    if (isTypeOnly) return '';
    const names = parseClause(clause);
    if (!external.has(source)) external.set(source, new Set());
    for (const n of names) external.get(source).add(n);
    return '';
  });
  // 'import * as THREE' biçimini ayrıca yakala
  const starRe = /^import\s+\*\s+as\s+(\w+)\s+from\s+['"]([^'"]+)['"];?\s*$/gm;
  let m;
  const stars = new Map();
  while ((m = starRe.exec(code)) !== null) stars.set(m[2], m[1]);
  for (const [source, alias] of stars) {
    if (!external.has(source)) external.set(source, new Set());
    external.get(source).add(`* as ${alias}`);
  }
  return { code: out, external };
}

function parseClause(clause) {
  const names = [];
  const braceMatch = clause.match(/\{([\s\S]*)\}/);
  if (braceMatch) {
    for (let raw of braceMatch[1].split(',')) {
      raw = raw.trim();
      if (!raw) continue;
      names.push(raw); // "A", "A as B", "type A" hepsi geçerli
    }
  }
  return names;
}

/** export belirteçlerini kaldır (tek modül içinde hepsi yerel kalır). */
function stripExports(code) {
  return code
    .replace(/^export\s+default\s+/gm, '')
    .replace(/^export\s+declare\s+/gm, '')
    .replace(/^export\s+(abstract\s+)?(class|function|const|let|var|interface|type|enum|namespace)\s/gm, '$1$2 ')
    .replace(/^export\s*\{[^}]*\}\s*;?\s*$/gm, '')
    .replace(/^export\s*\*\s*from\s*['"][^'"]+['"];?\s*$/gm, '');
}

function banner(name, index, total) {
  const line = '═'.repeat(74);
  return `\n/* ${line}\n   ▌ ${index}/${total} · ${name}\n   ${line} */\n`;
}

/**
 * Bir TypeScript dosyasını tarayıcıda çalışacak ES2020 JavaScript'e çevirir.
 * Yalnızca tip sözdizimi soyulur (transpileOnly); tip denetimi `npx tsc --noEmit`
 * ile ayrıca yapılır. Böylece `as`, `interface`, generic'ler ve `!` işaretleri
 * HTML'e sızmaz.
 */
function transpile(code, fileName) {
  const out = ts.transpileModule(code, {
    fileName,
    compilerOptions: {
      target: ts.ScriptTarget.ES2020,
      module: ts.ModuleKind.ESNext,
      moduleResolution: ts.ModuleResolutionKind.Bundler,
      isolatedModules: true,
      removeComments: false,
      importHelpers: false,
      useDefineForClassFields: false,
    },
  });
  const diags = (out.diagnostics ?? []).filter((d) => d.category === ts.DiagnosticCategory.Error);
  if (diags.length) {
    for (const d of diags) console.error(`  ! ${fileName}: ${ts.flattenDiagnosticMessageText(d.messageText, ' ')}`);
    throw new Error(`${fileName}: dönüştürme hatası`);
  }
  return out.outputText;
}

function build() {
  const parts = [];
  const partNames = [];
  const externals = new Map();

  const files = [...MODULES.map((f) => path.join(SRC, f)), path.join(DEMO, 'app.ts')];
  files.forEach((file, i) => {
    if (!fs.existsSync(file)) throw new Error(`Eksik dosya: ${file}`);
    const raw = transpile(read(file), path.basename(file));
    const { code, external } = stripImports(raw, path.basename(file));
    for (const [source, names] of external) {
      if (!externals.has(source)) externals.set(source, new Set());
      for (const n of names) externals.get(source).add(n);
    }
    const moduleName = path.basename(file, '.ts').replace(/^app$/, 'demo');
    partNames.push(moduleName);
    parts.push(banner(moduleName, i + 1, files.length) + stripExports(code));
  });

  // Dış importları tek bir blokta topla (importmap üzerinden çözülür)
  const importLines = [];
  for (const [source, names] of externals) {
    const list = [...names];
    const star = list.filter((n) => n.startsWith('* as '));
    const named = list.filter((n) => !n.startsWith('* as '));
    for (const s of star) importLines.push(`import ${s} from '${source}';`);
    if (named.length) importLines.push(`import { ${named.join(', ')} } from '${source}';`);
  }

  // ── birleşik kapsam bekçisi ──
  // Modüller tek bir <script type="module"> içine gömüldüğü için üst düzey
  // bildirimler AYNI kapsama düşer. Aynı adı iki modül de bildiriyorsa
  // tarayıcı "Identifier has already been declared" verir. İlk bildirim
  // (genellikle Core.ts) korunur, sonrakiler modül adıyla son eklenir.
  const declRe = /^(?:const|let|var|function|class)\s+([A-Za-z_$][\w$]*)/gm;
  const seen = new Map();
  const renames = [];
  for (let i = 0; i < parts.length; i++) {
    const base = partNames[i];
    declRe.lastIndex = 0;
    let dm;
    const localRenames = [];
    while ((dm = declRe.exec(parts[i])) !== null) {
      const name = dm[1];
      if (seen.has(name)) {
        const suffix = base.charAt(0).toUpperCase() + base.slice(1);
        let newName = `${name}${suffix}`;
        let k = 2;
        while (seen.has(newName)) newName = `${name}${suffix}${k++}`;
        seen.set(newName, base);
        localRenames.push([name, newName]);
        renames.push(`${base}: ${name} → ${newName}`);
      } else {
        seen.set(name, base);
      }
    }
    for (const [from, to] of localRenames) {
      // nokta/parça sonrası kullanımları (özellik erişimi) atla
      parts[i] = parts[i].replace(new RegExp(`(?<![.\\w$])\\b${from}\\b`, 'g'), to);
    }
  }
  if (renames.length) console.log(`· otomatik yeniden adlandırma (${renames.length}):\n  ${renames.join('\n  ')}`);

  const joined = parts.join('\n');
  declRe.lastIndex = 0;
  const check = new Map();
  let cm;
  while ((cm = declRe.exec(joined)) !== null) check.set(cm[1], (check.get(cm[1]) ?? 0) + 1);
  const dupes = [...check.entries()].filter(([, n]) => n > 1);
  if (dupes.length) {
    throw new Error(`Birleşik kapsamda hâlâ çift bildirim var: ${dupes.map(([n, c]) => `${n}×${c}`).join(', ')}`);
  }

  const appCode = ['/* BannerForge Engine · tek dosya derlemesi (three.js CDN importmap ile gelir) */', ...importLines, ...parts].join('\n');

  // </script> dizisi modül kodunu erken kapatmasın
  const safeApp = appCode.replace(/<\/script>/gi, '<\\/script>');

  const shell = read(path.join(DEMO, 'shell.html'));
  const css = read(path.join(DEMO, 'style.css'));
  const html = shell
    .replace('/*__CSS__*/', () => css)
    .replace('/*__APP__*/', () => safeApp);

  fs.writeFileSync(OUT, html, 'utf8');
  const kb = (Buffer.byteLength(html, 'utf8') / 1024).toFixed(0);
  const lines = html.split('\n').length;
  console.log(`✓ ${path.relative(ROOT, OUT)} üretildi · ${kb} KB · ${lines} satır · ${importLines.length} dış import`);
}

build();

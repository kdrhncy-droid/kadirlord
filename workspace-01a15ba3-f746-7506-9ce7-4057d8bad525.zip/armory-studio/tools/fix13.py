#!/usr/bin/env python3
"""Bölüm 2.1: audit.mjs'in bulduğu kopuk parça hatalarını kapatır."""
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
p = ROOT / 'src' / 'Armory.ts'
t = p.read_text(encoding='utf-8')

def rep(old, new):
    global t
    if old not in t:
        print(f'EKSİK: {old[:80]!r}')
        sys.exit(1)
    t = t.replace(old, new, 1)

# ── 1) rivets yardımcısına XY düzlemi seçeneği (kalkan yüzeyi için) ──
rep(
    """function rivets(ctx: BuildCtx, count: number, radius: number, r: number, y: number, mat = 'iron', arc = TAU, phase = 0): Piece[] {
  const out: Piece[] = [];
  const n = ctx.lod === 'crowd' ? Math.max(3, Math.round(count * 0.5)) : count;
  for (let i = 0; i < n; i++) {
    const a = phase + (i / n) * arc;
    const g = new THREE.OctahedronGeometry(r, 0);
    g.scale(1, 0.72, 1);
    out.push({ geometry: g, material: mat, position: [Math.cos(a) * radius, y, Math.sin(a) * radius] });
  }""",
    """function rivets(ctx: BuildCtx, count: number, radius: number, r: number, y: number, mat = 'iron', arc = TAU, phase = 0): Piece[] {
  const out: Piece[] = [];
  const n = ctx.lod === 'crowd' ? Math.max(3, Math.round(count * 0.5)) : count;
  for (let i = 0; i < n; i++) {
    const a = phase + (i / n) * arc;
    const g = new THREE.OctahedronGeometry(r, 0);
    g.scale(1, 0.72, 1);
    out.push({ geometry: g, material: mat, position: [Math.cos(a) * radius, y, Math.sin(a) * radius] });
  }""",
)
# XY halkası: kalkan yüzeyinde (z sabit) merkez çevresinde perçinler
rep(
    "/** Perçin dizisi (dairesel ya da çizgi boyunca). */",
    """/** Kalkan yüzeyinde (XY düzlemi, z sabit) halka perçinler.
 *  Yatay halka veren rivets() düz kalkanlarda yarısı havada kalıyordu. */
function rivetsXY(ctx: BuildCtx, count: number, radius: number, r: number, z: number, mat = 'iron', arc = TAU, phase = 0): Piece[] {
  const out: Piece[] = [];
  const n = ctx.lod === 'crowd' ? Math.max(3, Math.round(count * 0.5)) : count;
  for (let i = 0; i < n; i++) {
    const a = phase + (i / n) * arc;
    const g = new THREE.OctahedronGeometry(r, 0);
    g.scale(1, 1, 0.72);
    out.push({ geometry: g, material: mat, position: [Math.cos(a) * radius, Math.sin(a) * radius, z] });
  }
  return out;
}

/** Perçin dizisi (dairesel ya da çizgi boyunca). */""",
)

# ── 2) viking: boss perçinleri XY'ye, kayış/tutamak/toka derinlikleri ──
rep("    P.push(...rivets(ctx, 6, 0.124, 0.009, 0.072, 'iron'));",
    "    P.push(...rivetsXY(ctx, 6, 0.124, 0.009, 0.062, 'iron'));")
rep("  P.push({ geometry: strap, material: 'leather', position: [0, 0.06, -0.045] });",
    "  P.push({ geometry: strap, material: 'leather', position: [0, 0.06, -0.024] });")
rep("  P.push({ geometry: handle, material: 'leatherDark', position: [0, -0.02, -0.055] });",
    "  P.push({ geometry: handle, material: 'leatherDark', position: [0, -0.02, -0.032] });")
rep("    P.push({ geometry: buckle, material: 'bronze', position: [0, 0.27, -0.05] });",
    "    P.push({ geometry: buckle, material: 'bronze', position: [0, 0.27, -0.03] });")

# ── 3) kite: arma plakası kubbe yüzeyine gömülsün ──
rep("      position: [(cp.position?.[0] ?? 0) * 0.78, 0.05 + (cp.position?.[1] ?? 0) * 0.78, dome + 0.014],",
    "      position: [(cp.position?.[0] ?? 0) * 0.78, 0.05 + (cp.position?.[1] ?? 0) * 0.78, dome * 0.8],")

# ── 4) yay: uç halkası nock ile aynı eksende (z kayması yok) ──
rep("    P.push({ geometry: groove, material: 'horn', position: [0, tipY + dir * 0.045, BOW.tipZ + dir * 0.012] });",
    "    P.push({ geometry: groove, material: 'horn', position: [0, tipY + dir * 0.045, BOW.tipZ], rotation: [dir * ang * 0.55, 0, 0] });")

# ── 5) cuirass: rondel içe, sol omuz fini rondele bitsin ──
rep("  P.push({ geometry: rondel, material: 'gold', position: [side * 0.24, 0.268, 0] });",
    "  P.push({ geometry: rondel, material: 'gold', position: [side * 0.225, 0.268, 0] });")
rep("  P.push({ geometry: finGeo, material: 'steelDark', position: [-0.26, 0.288, 0], rotation: [0, -90 * DEG, 20 * DEG] });",
    "  P.push({ geometry: finGeo, material: 'steelDark', position: [-0.248, 0.288, 0], rotation: [0, -90 * DEG, 20 * DEG] });")
rep("  P.push({ geometry: spike, material: 'steelBright', position: [0.28, 0.28, 0] });",
    "  P.push({ geometry: spike, material: 'steelBright', position: [0.265, 0.28, 0] });")

# ── 6) morningstar: zincir baklaları birbirine geçsin ──
rep("      position: [0.012 * (i % 2 === 0 ? 1 : -1), 0.48 + i * 0.042, 0],",
    "      position: [0.012 * (i % 2 === 0 ? 1 : -1), 0.48 + i * 0.036, 0],")
rep("  const headY = 0.48 + links * 0.042 + 0.06;",
    "  const headY = 0.48 + links * 0.036 + 0.045;")

# ── 7) bardiche: gövde perçinleri çelik dilin üstüne taşmasın ──
rep("  P.push({ geometry: rv, material: 'iron', position: [0.048, 1.02 + i * 0.13, 0] });",
    "  P.push({ geometry: rv, material: 'iron', position: [0.042, 1.0 + i * 0.12, 0] });")

# ── 8) pavise: yatay perçin halkası yerine kenar sütunları + kayış derinliği ──
rep("    P.push(...rivets(ctx, 8, 0.27, 0.01, 0.4, 'iron', Math.PI));",
    """    for (let i = 0; i < 5; i++) {
      const y = -0.4 + i * 0.2;
      for (const s of [-1, 1]) {
        const rv = new THREE.OctahedronGeometry(0.011, 0);
        rv.scale(1, 1, 0.72);
        P.push({ geometry: rv, material: 'iron', position: [s * 0.27, y, 0.005] });
      }
    }""")
rep("    const strap = new THREE.BoxGeometry(0.06, 0.5, 0.014);\n    P.push({ geometry: strap, material: 'leather', position: [0, 0, -0.05] });",
    "    const strap = new THREE.BoxGeometry(0.06, 0.5, 0.014);\n    P.push({ geometry: strap, material: 'leather', position: [0, 0, -0.014] });")

# ── 9) cavalryRound: perçinler XY halkası + kayış yüzeye ──
rep("    P.push(...rivets(ctx, 8, R - 0.03, 0.009, 0.03, 'bronze'));",
    "    P.push(...rivetsXY(ctx, 8, R - 0.03, 0.009, 0.028, 'bronze'));")
rep("  P.push({ geometry: strap, material: 'leatherDark', position: [0, 0, -0.035] });",
    "  P.push({ geometry: strap, material: 'leatherDark', position: [0, 0, -0.012] });")

p.write_text(t, encoding='utf-8')
print('fix13: 9 bölge düzeltildi.')

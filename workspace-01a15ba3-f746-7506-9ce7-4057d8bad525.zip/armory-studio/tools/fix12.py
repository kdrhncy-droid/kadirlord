#!/usr/bin/env python3
"""Bölüm 2: at cinsleri (war / steppe / destrier) + lab UI."""
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent

def load(rel):
    return (ROOT / rel).read_text(encoding='utf-8')

def save(rel, txt):
    (ROOT / rel).write_text(txt, encoding='utf-8')

def rep(txt, old, new, tag):
    if old not in txt:
        print(f'EKSİK ({tag}): {old[:70]!r}')
        sys.exit(1)
    return txt.replace(old, new, 1)

# ─────────────────────────── Rig.ts ───────────────────────────
t = load('src/Rig.ts')
t = rep(t,
    'export function horseJoints(scale = 1): JointDef[] {\n  const P = (k: keyof typeof HORSE_PROPORTIONS): number => HORSE_PROPORTIONS[k] * scale;',
    'export function horseJoints(scale = 1, props: Record<string, number> = HORSE_PROPORTIONS): JointDef[] {\n  const P = (k: keyof typeof HORSE_PROPORTIONS): number => props[k] * scale;',
    'rig')
t = rep(t,
    "    ['hindL', -0.62 * scale, P('legSpread')],\n    ['hindR', -0.62 * scale, -P('legSpread')],",
    "    ['hindL', P('hindLegX'), P('legSpread')],\n    ['hindR', P('hindLegX'), -P('legSpread')],",
    'rig-hind')
save('src/Rig.ts', t)
print('Rig.ts: horseJoints props parametresi aldı.')

# ─────────────────────────── Horse.ts ───────────────────────────
h = load('src/Horse.ts')

h = rep(h,
    "export interface HorseOptions {",
    """/** At cinsi: oranlar, yele dokusu ve varsayılan don rengi değişir. */
export type HorseBreed = 'war' | 'steppe' | 'destrier';

export interface BreedProfile {
  leg: number;
  girth: number;
  len: number;
  neck: number;
  mane: number;
  /** Tüm LOD'larda paça tüyü (bozkır ve ağır atlar). */
  feather: boolean;
  coat: CoatColor;
  ad: string;
}

export const HORSE_BREEDS: Record<HorseBreed, BreedProfile> = {
  war: { leg: 1, girth: 1, len: 1, neck: 1, mane: 1, feather: false, coat: 'bay', ad: 'Savaş Atı' },
  steppe: { leg: 0.86, girth: 1.07, len: 0.93, neck: 0.94, mane: 1.45, feather: true, coat: 'dun', ad: 'Bozkır Midillisi' },
  destrier: { leg: 1.1, girth: 1.15, len: 1.06, neck: 1.05, mane: 0.85, feather: true, coat: 'black', ad: 'Destrier' },
};

export interface HorseOptions {
  breed?: HorseBreed;""",
    'horse-breed-type')

h = rep(h,
    """  steps: (n: number) => number;
  scale: number;
}""",
    """  steps: (n: number) => number;
  scale: number;
  /** Cins çarpanları. */
  bp: BreedProfile;
  /** Cinsle ölçeklenmiş iskelet oranları. */
  hp: Record<string, number>;
}""",
    'hctx')

h = rep(h,
    "function makeHorseCtx(o: { lod: LodLevel; faction: FactionPalette; seed: number; scale: number }): HCtx {",
    "function makeHorseCtx(o: { lod: LodLevel; faction: FactionPalette; seed: number; scale: number; bp: BreedProfile; hp: Record<string, number> }): HCtx {",
    'ctx-sig')
h = rep(h,
    """    steps: (n: number) => Math.max(2, Math.round(n * stepScale)),
    scale: o.scale,
  };""",
    """    steps: (n: number) => Math.max(2, Math.round(n * stepScale)),
    scale: o.scale,
    bp: o.bp,
    hp: o.hp,
  };""",
    'ctx-fields')

# constructor
h = rep(h,
    """    this.coat = options.coat ?? 'bay';
    const seed = options.seed ?? 5150;
    const scale = options.scale ?? 1;""",
    """    const breed = HORSE_BREEDS[options.breed ?? 'war'];
    this.coat = options.coat ?? breed.coat;
    const seed = options.seed ?? 5150;
    const scale = options.scale ?? 1;
    // Cins oranları: iskelet VE geometri aynı tablodan beslenir (eklem kayması olmaz).
    const hp: Record<string, number> = {
      ...HORSE_PROPORTIONS,
      bodyY: HORSE_PROPORTIONS.bodyY * breed.leg,
      shoulderY: HORSE_PROPORTIONS.shoulderY * breed.leg,
      hipY: HORSE_PROPORTIONS.hipY * breed.leg,
      upperLeg: HORSE_PROPORTIONS.upperLeg * breed.leg,
      cannon: HORSE_PROPORTIONS.cannon * breed.leg,
      neckLen: HORSE_PROPORTIONS.neckLen * breed.neck,
      bodyLen: HORSE_PROPORTIONS.bodyLen * breed.len,
      frontLegX: HORSE_PROPORTIONS.frontLegX * breed.len,
      hindLegX: HORSE_PROPORTIONS.hindLegX * breed.len,
    };""",
    'ctor-breed')
h = rep(h,
    "    this.rig = new Rig(horseJoints(scale));",
    "    this.rig = new Rig(horseJoints(scale, hp));",
    'ctor-rig')
h = rep(h,
    "    const ctx = makeHorseCtx({ lod: this.lod, faction: this.faction, seed, scale });",
    "    const ctx = makeHorseCtx({ lod: this.lod, faction: this.faction, seed, scale, bp: breed, hp });",
    'ctor-ctx')
h = rep(h,
    "    this.saddleSlot.position.set(0.02, HORSE_PROPORTIONS.bodyY * scale + 0.42 * scale, 0);",
    "    this.saddleSlot.position.set(0.02, hp.bodyY * scale + 0.42 * scale, 0);",
    'ctor-saddle')

# barrel
h = rep(h,
    "    spine.push(v3(-0.82 + t * 1.62, 0.06 * Math.sin(Math.PI * t) - 0.02 * t, 0));",
    "    spine.push(v3((-0.82 + t * 1.62) * ctx.bp.len, 0.06 * Math.sin(Math.PI * t) - 0.02 * t, 0));",
    'barrel-spine')
h = rep(h,
    "  barrel.scale(1, 1, 0.86); // yandan basık",
    "  barrel.scale(1, ctx.bp.girth, ctx.bp.girth * 0.86); // yandan basık + cins gövdesi",
    'barrel-scale')
h = rep(h,
    """  const chest = new THREE.SphereGeometry(0.26, ctx.rad(6), ctx.rad(5));
  chest.scale(0.8, 1, 0.92);
  P.push({ geometry: chest, material: 'coat', joint: 'body', position: [0.74, -0.02, 0] });""",
    """  const chest = new THREE.SphereGeometry(0.26 * ctx.bp.girth, ctx.rad(6), ctx.rad(5));
  chest.scale(0.8, 1, 0.92);
  P.push({ geometry: chest, material: 'coat', joint: 'body', position: [0.74 * ctx.bp.len, -0.02, 0] });""",
    'chest')
h = rep(h,
    """  const croup = new THREE.SphereGeometry(0.28, ctx.rad(6), ctx.rad(5));
  croup.scale(0.95, 0.9, 0.92);
  P.push({ geometry: croup, material: 'coat', joint: 'body', position: [-0.72, 0.08, 0] });""",
    """  const croup = new THREE.SphereGeometry(0.28 * ctx.bp.girth, ctx.rad(6), ctx.rad(5));
  croup.scale(0.95, 0.9, 0.92);
  P.push({ geometry: croup, material: 'coat', joint: 'body', position: [-0.72 * ctx.bp.len, 0.08, 0] });""",
    'croup')

# neck + mane
h = rep(h,
    "    spine.push(v3(0.78 + t * 0.5, 0.1 + t * 0.62 - t * t * 0.16, 0));",
    "    spine.push(v3((0.78 + t * 0.5) * ctx.bp.len, 0.1 + t * 0.62 * ctx.bp.neck - t * t * 0.16 * ctx.bp.neck, 0));",
    'neck-spine')
h = rep(h,
    "  neck.scale(1, 1, 0.72);",
    "  neck.scale(1, ctx.bp.girth, 0.72 * ctx.bp.girth);",
    'neck-scale')
h = rep(h,
    "    maneSpine.push(v3(0.74 + t * 0.52, 0.26 + t * 0.6 - t * t * 0.16, -0.02 + Math.sin(t * 5.5) * 0.022));",
    "    maneSpine.push(v3((0.74 + t * 0.52) * ctx.bp.len, (0.26 + t * 0.6 - t * t * 0.16) * ctx.bp.neck, -0.02 + Math.sin(t * 5.5) * 0.022));",
    'mane-spine')
h = rep(h,
    "  mane.scale(1, 1, 0.8);",
    "  mane.scale(1, ctx.bp.mane, 0.8 * ctx.bp.mane);",
    'mane-scale')

# legs
h = rep(h,
    """  const upper = HORSE_PROPORTIONS.upperLeg;
  const cannon = HORSE_PROPORTIONS.cannon;
  const hero = ctx.lod === 'hero';

  const legs: [string, number, number, boolean][] = [
    ['frontL', HORSE_PROPORTIONS.frontLegX, HORSE_PROPORTIONS.legSpread, false],
    ['frontR', HORSE_PROPORTIONS.frontLegX, -HORSE_PROPORTIONS.legSpread, false],
    ['hindL', -0.62, HORSE_PROPORTIONS.legSpread, true],
    ['hindR', -0.62, -HORSE_PROPORTIONS.legSpread, true],
  ];""",
    """  const upper = ctx.hp.upperLeg;
  const cannon = ctx.hp.cannon;
  const hero = ctx.lod === 'hero';

  const legs: [string, number, number, boolean][] = [
    ['frontL', ctx.hp.frontLegX, ctx.hp.legSpread, false],
    ['frontR', ctx.hp.frontLegX, -ctx.hp.legSpread, false],
    ['hindL', ctx.hp.hindLegX, ctx.hp.legSpread, true],
    ['hindR', ctx.hp.hindLegX, -ctx.hp.legSpread, true],
  ];""",
    'legs-props')
h = rep(h,
    """    if (hero) {
      // tırnak üstü (pastern) tüyü
      const feathering = new THREE.ConeGeometry(0.07, 0.09, 5);""",
    """    if (hero || ctx.bp.feather) {
      // tırnak üstü (pastern) tüyü — bozkır ve ağır atlarda tüm LOD'larda
      const feathering = new THREE.ConeGeometry(0.07, 0.09, 5);""",
    'feather')
save('src/Horse.ts', h)
print('Horse.ts: cins sistemi eklendi.')

# ─────────────────────────── demo ───────────────────────────
s = load('demo/shell.html')
s = rep(s,
    """        <div class="etiket">Miğfer</div>
        <div id="helmSec" class="cips"></div>""",
    """        <div class="etiket">Miğfer</div>
        <div id="helmSec" class="cips"></div>
        <div class="etiket">Binek cinsi</div>
        <div id="cinsSec" class="cips"></div>""",
    'shell')
save('demo/shell.html', s)

d = load('demo/app.ts')
d = rep(d,
    "import { CoatColor, Horse } from '../src/Horse.js';",
    "import { CoatColor, Horse, HORSE_BREEDS, HorseBreed } from '../src/Horse.js';",
    'demo-import')
d = rep(d,
    "  surcoat: true,\n  lod: 'hero' as LodLevel,",
    "  surcoat: true,\n  breed: 'war' as HorseBreed,\n  lod: 'hero' as LodLevel,",
    'demo-state')
d = rep(d,
    """  const silahlar = ARMORY_CATALOG.filter((s) => ['sword', 'axe', 'mace', 'polearm', 'bow'].includes(s.cls));""",
    """  buildItemChips(
    $('cinsSec'),
    (Object.keys(HORSE_BREEDS) as HorseBreed[]).map((b) => ({ id: b, ad: HORSE_BREEDS[b].ad })),
    labState.breed,
    (id) => {
      labState.breed = id as HorseBreed;
      buildLabCharacter();
    },
  );

  const silahlar = ARMORY_CATALOG.filter((s) => ['sword', 'axe', 'mace', 'polearm', 'bow'].includes(s.cls));""",
    'demo-chips')
d = rep(d,
    """      coat: 'bay' as CoatColor,
      barding: true,""",
    """      coat: HORSE_BREEDS[labState.breed].coat as CoatColor,
      breed: labState.breed,
      barding: true,""",
    'demo-horse')
save('demo/app.ts', d)
print('demo: cins çipleri + lab entegrasyonu.')

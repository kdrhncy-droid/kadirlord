import io

p = 'src/Armory.ts'
s = io.open(p, encoding='utf-8').read()
n = 0


def rep(old, new, count=1):
    global s, n
    if old not in s:
        raise SystemExit('BULUNAMADI:\n' + old[:200])
    s = s.replace(old, new, count)
    n += 1


# ── 1) kılıç ucu ölçek sürekliliği (gladius) ──
rep(
    """    scale: (t) => {
      if (t > 0.955) return 1 - smooth((t - 0.955) / 0.045);
      return 0.4 + 0.6 * Math.sin(Math.PI * Math.min(1, 0.1 + t * 0.95)) ** 0.45;
    },""",
    """    scale: (t) => {
      const body = 0.4 + 0.6 * Math.sin(Math.PI * Math.min(1, 0.1 + t * 0.95)) ** 0.45;
      const tip = t < 0.88 ? 1 : Math.max(0, 1 - smooth((t - 0.88) / 0.12));
      return body * tip;
    },""",
)

# ── 2) scimitar: ölçek sürekliliği + daha az agresif kavis ──
rep(
    """    scale: (t) => {
      const base = 0.88 + 0.12 * Math.sin(Math.PI * t);
      // yalman: ucun son %22'sinde genişleme
      const flare = t > 0.78 ? 1 + 0.55 * smooth((t - 0.78) / 0.16) : 1;
      if (t > 0.965) return base * flare * (1 - smooth((t - 0.965) / 0.035));
      return base * flare;
    },""",
    """    scale: (t) => {
      const base = 0.88 + 0.12 * Math.sin(Math.PI * t);
      // yalman: ucun son %28'inde genişleme (0.9'da tepe, sonra sivrilir)
      const flare = t > 0.72 ? 1 + 0.5 * Math.sin(Math.PI * Math.min(1, (t - 0.72) / 0.28)) : 1;
      const tip = t < 0.9 ? 1 : Math.max(0, 1 - smooth((t - 0.9) / 0.1));
      return base * flare * tip;
    },""",
)
rep("  bendGeometry(blade, (y) => Math.max(0, y - 0.3) * 0.62 * Math.max(0, y - 0.3));",
    "  bendGeometry(blade, (y) => 0.42 * Math.max(0, y - 0.3) * Math.max(0, y - 0.3));")
rep("""    spineRib.translate(-0.02, 0.62, 0.004);
    bendGeometry(spineRib, (y) => Math.max(0, y - 0.3) * 0.62 * Math.max(0, y - 0.3));""",
    """    spineRib.translate(-0.02, 0.62, 0.004);
    bendGeometry(spineRib, (y) => 0.42 * Math.max(0, y - 0.3) * Math.max(0, y - 0.3));""")

# ── 3) tek elli balta: doğru ağız konturu (sap etrafında göz + dışa açılan ağız) ──
rep(
    """function axeHeadOutline(size: number, beard: number, sweepBack: number): Vec2Tuple[] {
  return [
    [0.055 * size, 0.055 * size],                                   // göz (şaft yuvası) üst
    [0.09 * size, 0.2 * size + sweepBack],                          // omuz
    [0.19 * size, 0.28 * size + sweepBack],                         // ağız üst
    [0.26 * size, 0.06 * size],                                     // ağız tepe
    [0.2 * size, -0.1 * size],                                       // ağız alt
    [0.1 * size, -0.24 * size - beard],                             // sakal ucu
    [0.04 * size, -0.16 * size - beard * 0.5],                       // sakal iç
    [0.035 * size, -0.06 * size],                                    // göz alt
  ];
}""",
    """/**
 * Balta başı konturu (ExtrudeGeometry şekil düzlemi):
 *   shape.x → dünya Z (ağızın yukarı/aşağı açıklığı)
 *   shape.y → dünya X (saptan dışa, ağıza doğru)
 * Soket (göz) x≈0'da kalır, keskin ağız x≈0.3'te dışbükey kavis çizer.
 */
function axeHeadOutline(size: number, beard: number, sweepBack: number): Vec2Tuple[] {
  return [
    [-0.045 * size, 0.05 * size],                     // göz arka-üst
    [0.05 * size, 0.075 * size + sweepBack],          // omuz üst
    [0.16 * size, 0.15 * size + sweepBack],           // ağız üst çıkışı
    [0.28 * size, 0.045 * size],                      // ağız tepe (keskin)
    [0.24 * size, -0.07 * size],                       // ağız alt çıkışı
    [0.12 * size, -0.19 * size - beard],               // sakal ucu
    [0.02 * size, -0.13 * size - beard * 0.5],         // sakal iç kavis
    [-0.045 * size, -0.055 * size],                    // göz arka-alt
  ];
}""",
)
rep(
    """  const head = extrudedBlade(outline, hero ? 0.03 : 0.026, hero ? 0.011 : 0.006, 'steelBright', {
    rotation: [0, 90 * DEG, 0],
    position: [hero ? 0.026 : 0.02, 0.63, 0],
  });
  P.push(head);""",
    """  const head = extrudedBlade(outline, hero ? 0.034 : 0.028, hero ? 0.011 : 0.006, 'steelBright', {
    rotation: [0, 90 * DEG, 0],
    position: [-0.017, 0.63, 0],
  });
  P.push(head);""",
)
rep(
    """    const edge = extrudedBlade(
      [
        [0.19, 0.28],
        [0.26, 0.06],
        [0.2, -0.1],
        [0.21, -0.1],
        [0.275, 0.06],
        [0.205, 0.285],
      ],
      0.034,
      0.004,
      'steel',
      { rotation: [0, 90 * DEG, 0], position: [0.017, 0.63, 0] },
    );
    P.push(edge);""",
    """    const edge = extrudedBlade(
      [
        [0.16, 0.15],
        [0.28, 0.045],
        [0.24, -0.07],
        [0.255, -0.075],
        [0.3, 0.048],
        [0.17, 0.16],
      ],
      0.038,
      0.004,
      'steel',
      { rotation: [0, 90 * DEG, 0], position: [-0.019, 0.63, 0] },
    );
    P.push(edge);""",
)
rep(
    """  const cheek = new THREE.BoxGeometry(hero ? 0.05 : 0.04, 0.16, hero ? 0.028 : 0.024);
  P.push({ geometry: cheek, material: 'steel', position: [0.012, 0.64, 0] });""",
    """  const cheek = new THREE.BoxGeometry(hero ? 0.05 : 0.04, 0.16, hero ? 0.03 : 0.026);
  P.push({ geometry: cheek, material: 'steel', position: [0.0, 0.64, 0] });""",
)

# ── 4) bardiche: hilal ağız konturu ──
rep(
    """  const outline: Vec2Tuple[] = [
    [0.03, 0.1],
    [0.09, 0.5],
    [0.3, 0.72],
    [0.5, 0.46],
    [0.44, 0.1],
    [0.24, -0.02],
    [0.3, -0.4],
    [0.08, -0.26],
    [0.028, -0.34],
  ];
  const head = extrudedBlade(outline, hero ? 0.032 : 0.026, hero ? 0.012 : 0.006, 'steelBright', {
    rotation: [0, 90 * DEG, 0],
    position: [0.03, 1.16, 0],
  });
  P.push(head);""",
    """  // shape.x → dünya Z (aşağı/yukarı), shape.y → dünya X (saptan dışa)
  const outline: Vec2Tuple[] = [
    [-0.03, 0.05],      // soket arka-üst
    [0.03, 0.06],       // soket ön-üst (sapa dayanır)
    [0.03, -0.5],       // soket ön-alt
    [-0.03, -0.5],      // soket arka-alt
    [0.02, -0.56],      // sakal başlangıcı
    [0.2, -0.6],        // sakal ucu (aşağı sarkan diken)
    [0.24, -0.24],      // iç kavis
    [0.34, 0.1],        // ağız altı
    [0.5, 0.44],        // ağız göbeği (en dış nokta)
    [0.32, 0.7],        // ağız üstü
    [0.06, 0.6],        // sırt (sapa paralel)
  ];
  const head = extrudedBlade(outline, hero ? 0.034 : 0.028, hero ? 0.012 : 0.006, 'steelBright', {
    rotation: [0, 90 * DEG, 0],
    position: [-0.017, 1.36, 0],
  });
  P.push(head);""",
)
rep(
    """  const edge = extrudedBlade(
    [
      [0.3, 0.72],
      [0.5, 0.46],
      [0.44, 0.1],
      [0.46, 0.1],
      [0.525, 0.47],
      [0.315, 0.735],
    ],
    hero ? 0.036 : 0.03,
    0.004,
    'steel',
    { rotation: [0, 90 * DEG, 0], position: [0.014, 1.16, 0] },
  );
  P.push(edge);""",
    """  const edge = extrudedBlade(
    [
      [0.24, -0.24],
      [0.34, 0.1],
      [0.5, 0.44],
      [0.32, 0.7],
      [0.345, 0.715],
      [0.525, 0.45],
      [0.365, 0.105],
      [0.262, -0.245],
    ],
    hero ? 0.038 : 0.032,
    0.004,
    'steel',
    { rotation: [0, 90 * DEG, 0], position: [-0.019, 1.36, 0] },
  );
  P.push(edge);""",
)
rep(
    """  const langet = new THREE.BoxGeometry(hero ? 0.046 : 0.04, 0.62, hero ? 0.014 : 0.012);
  P.push({ geometry: langet, material: 'steelDark', position: [0.026, 1.1, 0] });
  if (hero) {
    const langetBack = new THREE.BoxGeometry(0.03, 0.5, 0.012);
    P.push({ geometry: langetBack, material: 'steelDark', position: [-0.028, 1.14, 0] });""",
    """  const langet = new THREE.BoxGeometry(hero ? 0.05 : 0.042, 0.72, hero ? 0.014 : 0.012);
  P.push({ geometry: langet, material: 'steelDark', position: [0.022, 1.16, 0] });
  if (hero) {
    const langetBack = new THREE.BoxGeometry(0.034, 0.62, 0.012);
    P.push({ geometry: langetBack, material: 'steelDark', position: [-0.024, 1.2, 0] });""",
)
rep(
    """  const spike = new THREE.ConeGeometry(hero ? 0.032 : 0.026, hero ? 0.26 : 0.2, ctx.rad(5));
  P.push({ geometry: spike, material: 'steel', position: [0.01, 1.86, 0] });
  const spikeBase = new THREE.CylinderGeometry(0.036, 0.03, 0.09, ctx.rad(6));
  P.push({ geometry: spikeBase, material: 'steelDark', position: [0.005, 1.75, 0] });""",
    """  const spike = new THREE.ConeGeometry(hero ? 0.032 : 0.026, hero ? 0.26 : 0.2, ctx.rad(5));
  P.push({ geometry: spike, material: 'steel', position: [0, 1.85, 0] });
  const spikeBase = new THREE.CylinderGeometry(0.036, 0.03, 0.09, ctx.rad(6));
  P.push({ geometry: spikeBase, material: 'steelDark', position: [0, 1.74, 0] });""",
)
rep("""    const tassel = new THREE.ConeGeometry(0.03, 0.16, 4);
    tassel.rotateX(180 * DEG);
    P.push({ geometry: tassel, material: 'cloth', position: [-0.05, 1.5, 0] });""",
    """    const tassel = new THREE.ConeGeometry(0.03, 0.16, 4);
    tassel.rotateX(180 * DEG);
    P.push({ geometry: tassel, material: 'cloth', position: [-0.04, 1.42, 0] });""")

# ── 5) halberd balta ağzı konturu ──
rep(
    """  const axe = extrudedBlade(
    [
      [0.02, 0.06],
      [0.14, 0.17],
      [0.32, 0.06],
      [0.3, -0.15],
      [0.13, -0.24],
      [0.02, -0.15],
    ],
    hero ? 0.026 : 0.022,
    hero ? 0.009 : 0.005,
    'steel',
    { rotation: [0, 90 * DEG, 0], position: [0.012, 1.86, 0] },
  );
  P.push(axe);""",
    """  const axe = extrudedBlade(
    [
      [-0.03, 0.05],
      [0.03, 0.06],
      [0.03, -0.22],
      [-0.03, -0.2],
      [0.06, -0.26],
      [0.2, -0.16],
      [0.3, 0.0],
      [0.2, 0.16],
      [0.06, 0.2],
    ],
    hero ? 0.028 : 0.024,
    hero ? 0.009 : 0.005,
    'steel',
    { rotation: [0, 90 * DEG, 0], position: [-0.014, 1.86, 0] },
  );
  P.push(axe);""",
)

# ── 6) great helm: kaş bandına da göz yarığı aç + perçin açısını düzelt ──
rep(
    """  const browProf = profile2([[0.155, -0.012], [0.166, -0.006], [0.166, 0.012], [0.155, 0.018]]);
  const brow = new THREE.LatheGeometry(browProf, seg);
  P.push({ geometry: brow, material: 'steelDark', position: [0, 0.032, 0] });""",
    """  const browProf = profile2([[0.155, -0.012], [0.166, -0.006], [0.166, 0.012], [0.155, 0.018]]);
  const brow = new THREE.LatheGeometry(browProf, seg);
  weldVertices(brow, 1e-4);
  P.push({
    geometry: carveEyeSlit(brow, hero ? 52 : 62, -0.02, 0.02),
    material: 'steelDark',
    position: [0, 0.032, 0],
  });""",
)
rep(
    """      const a = (i / seg) * TAU + Math.PI / seg;
      if (Math.abs(((a + Math.PI) % TAU) - Math.PI) < 1.1) continue; // ön tarafta yarığa denk gelmesin
      const g = new THREE.OctahedronGeometry(0.009, 0);""",
    """      const a = (i / seg) * TAU + Math.PI / seg;
      // ön bölgedeki perçinleri atla (göz yarığına denk gelmesin)
      const front = Math.atan2(Math.sin(a), Math.cos(a));
      if (Math.abs(front) < 62 * DEG) continue;
      const g = new THREE.OctahedronGeometry(0.009, 0);""",
)

# ── 7) horned helm: spangen şeritleri süpürme ile (tası gerçekten takip eder) ──
rep(
    """  if (hero) {
    for (const a of [0, 90, 180, 270]) {
      const band = new THREE.BoxGeometry(0.018, 0.006, 0.34);
      band.rotateY(a * DEG);
      const g = band.clone();
      g.rotateX(0);
      P.push({ geometry: g, material: 'steelBright', position: [0, 0.06, 0], rotation: [78 * DEG, a * DEG, 0] });
    }
  }""",
    """  if (hero) {
    for (const azim of [0, 90, 180, 270]) {
      const a = azim * DEG;
      const bandSpine: Vec3Tuple[] = [];
      for (let i = 0; i <= 6; i++) {
        const u = i / 6;
        const th = (-12 + u * 190) * DEG;
        const rr = 0.149 * Math.cos(th * 0.52) + 0.008;
        bandSpine.push([Math.sin(a) * rr * Math.cos(th), 0.02 + Math.sin(th) * 0.155, Math.cos(a) * rr * Math.cos(th)]);
      }
      const band = sweep(
        profile2([[-0.011, -0.004], [0.011, -0.004], [0.011, 0.004], [-0.011, 0.004], [-0.011, -0.004]]),
        spine3(bandSpine),
        { seedNormal: v3(Math.sin(a), 0, Math.cos(a)) },
      );
      P.push({ geometry: band, material: 'steelBright' });
    }
  }""",
)

# ── 8) cuirass: pauldron konturu/yönü + typo + armpit çift yüz ──
rep(
    """  const pauldronOutline = profile2([
    [-0.02, 0.19],
    [0.09, 0.25],
    [0.19, 0.13],
    [0.2, -0.03],
    [0.1, -0.13],
    [-0.02, -0.09],
  ]);
  const pauldronProfile: Vec2Tuple[] = [
    [0, 0.03],
    [0.055, 0.016],
    [0.095, -0.018],
    [0.1, -0.052],
  ];""",
    """  // Kontur (local XY): x = ön/arka (göğüs → sırt), y = aşağı sarkma yönü.
  // rotation.x = -90° ile local +Y → dünya -Z ... bunun yerine local +Y'nin
  // dünya -Y'ye (aşağı) bakması için +90° X rotasyonu kullanılır; profil
  // (+Z) ise kol eksenine (sağda +Z, solda -Z) oturur.
  const pauldronOutline = profile2([
    [-0.12, 0.03],
    [-0.05, 0.07],
    [0.06, 0.05],
    [0.13, -0.02],
    [0.1, -0.13],
    [-0.02, -0.17],
    [-0.11, -0.1],
  ]);
  const pauldronProfile: Vec2Tuple[] = [
    [0, 0.028],
    [0.05, 0.02],
    [0.1, 0.004],
    [0.125, -0.022],
  ];""",
)
rep(
    """      const shell = shellSweep(outline, profile2(pauldronProfile.map((p) => [p[0] * k, p[1]] as Vec2Tuple)));
      P.push({
        geometry: shell,
        material: i === 0 ? 'steelBright' : 'steel',
        position: [side * (0.196 + i * 0.014), 0.222 - i * 0.062, 0],
        rotation: [-90 * DEG, 0, side > 0 ? -6 * DEG : 6 * DEG],
      });
      if (hero) {
        // katman kenarında altın biye
        const trimOutline = outline.map((p) => v2(p.x, p.y));
        const trimShell = shellSweep(trimOutline, profile2([[0.098, -0.05], [0.104, -0.056], [0.104, -0.044]]));
        P.push({
          geometry: trimShell,
          material: 'trim',
          position: [side * (0.196 + i * 0.014), 0.222 - i * 0.062, 0],
          rotation: [-90 * DEG, 0, side > 0 ? -6 * DEG : 6 * DEG],
        });
      }""",
    """      const shell = shellSweep(outline, profile2(pauldronProfile.map((q) => [q[0] * k, q[1]] as Vec2Tuple)));
      P.push({
        geometry: shell,
        material: i === 0 ? 'steelBright' : 'steel',
        position: [side * (0.178 + i * 0.024), 0.268 - i * 0.05, 0],
        rotation: [90 * DEG, side > 0 ? 0 : 180 * DEG, side > 0 ? -8 * DEG : 8 * DEG],
      });
      if (hero) {
        // katman kenarında altın biye
        const trimShell = shellSweep(outline, profile2([[0.118, -0.024], [0.132, -0.03], [0.13, -0.016]]));
        P.push({
          geometry: trimShell,
          material: 'trim',
          position: [side * (0.178 + i * 0.024), 0.268 - i * 0.05, 0],
          rotation: [90 * DEG, side > 0 ? 0 : 180 * DEG, side > 0 ? -8 * DEG : 8 * DEG],
        });
      }""",
)
rep(
    """    const rondel = new THREE.CylinderGeometry(hero ? 0.042 : 0.038, hero ? 0.046 : 0.042, 0.018, ctx.rad(6));
    rondel.rotateZ(side * 90 * DEG);
    P.push({ geometry: rondel, material: 'gold', position: [side * 0.215, 0.255, 0] });
    if (hero && side > 0) {
      const spike = new THREE.ConeGeometry(0.018, 0.07, 4);
      spike.rotateZ(-90 * DEG);
      P.push({ geometry: spike, material: 'steelBright', position: [0.25, 0.27, 0] });
    }
    if (hero && side < 0) {
      // sol omuzda küçük kanat/çıkıntı (asimetrik Bannerlord silüeti)
      const fin = shapeFrom([
        [0, 0],
        [0.1, 0.03],
        [0.13, -0.06],
        [0.04, -0.05],
      ]);
      const finGeo = new THREE.ExtrudeGeometry(fin, extrudeOpts(0.014, 0.004, 1));
      P.push({ geometry: finGeo, material: 'steelDark', position: [-0.24, 0.27, 0], rotation: [0, 90 * DEG, 20 * DEG] });
    }""",
    """    const rondel = new THREE.CylinderGeometry(hero ? 0.042 : 0.038, hero ? 0.046 : 0.042, 0.018, ctx.rad(6));
    rondel.rotateZ(side * 90 * DEG);
    P.push({ geometry: rondel, material: 'gold', position: [side * 0.205, 0.276, 0] });
    if (hero && side > 0) {
      const spike = new THREE.ConeGeometry(0.018, 0.07, 4);
      spike.rotateZ(-90 * DEG);
      P.push({ geometry: spike, material: 'steelBright', position: [0.245, 0.288, 0] });
    }
    if (hero && side < 0) {
      // sol omuzda küçük kanat/çıkıntı (asimetrik Bannerlord silüeti)
      const fin = shapeFrom([
        [0, 0],
        [0.1, 0.03],
        [0.13, -0.06],
        [0.04, -0.05],
      ]);
      const finGeo = new THREE.ExtrudeGeometry(fin, extrudeOpts(0.014, 0.004, 1));
      P.push({ geometry: finGeo, material: 'steelDark', position: [-0.23, 0.29, 0], rotation: [0, 90 * DEG, 20 * DEG] });
    }""",
)
rep("""    const armpit = new THREE.CircleGeometry(0.075, ctx.rad(6));
    armpit.rotateY(side * 90 * DEG);""",
    """    const armpit = new THREE.CircleGeometry(0.078, ctx.rad(6));
    armpit.rotateY(side > 0 ? 90 * DEG : -90 * DEG);""")
rep("""      material: 'dark', position: [side * 0.17, 0.14, 0] });""",
    """      material: { key: 'armpit', color: 0x1b1a18, metalness: 0.15, roughness: 0.9, flatShading: true, side: THREE.DoubleSide },
      position: [side * 0.17, 0.14, 0],
    });""")
rep("    faction: 'İmparlorluk',", "    faction: 'İmparatorluk',")

# ── 9) viking boss perçinleri: map hack'i yerine doğrudan çağrı ──
rep(
    """    P.push(...rivets(ctx, 6, 0.108, 0.009, 0, 'iron').map((r) => ({
      geometry: r.geometry,
      material: 'iron',
      position: [r.position![0], r.position![1], 0.068] as Vec3Tuple,
    })));""",
    """    P.push(...rivets(ctx, 6, 0.108, 0.009, 0.068, 'iron'));""",
)
rep("""/** Perçin dizisi (dairesel ya da çizgi boyunca). */
function rivets(ctx: BuildCtx, count: number, radius: number, r: number, y: number, mat = 'iron', arc = TAU, phase = 0): Piece[] {""",
    """/** Perçin dizisi: XZ düzleminde `radius` yarıçaplı çember boyunca, `y` yüksekliğinde. */
function rivets(ctx: BuildCtx, count: number, radius: number, r: number, y: number, mat = 'iron', arc = TAU, phase = 0): Piece[] {""")

io.open(p, 'w', encoding='utf-8').write(s)
print('uygulanan düzeltme:', n)

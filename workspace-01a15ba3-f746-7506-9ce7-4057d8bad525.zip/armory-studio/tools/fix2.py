import io

p = 'src/Armory.ts'
s = io.open(p, encoding='utf-8').read()

# ── BOW sabitleri: gerçek recurve için parçalı eğrilik ──
old_const = """const BOW = {
  half: 0.7, // kol uzunluğu (kabza merkezinden uç nock'a)
  k: 0.52,   // eğrilik çarpanı → θ(y) = k·y²  (toplam 0.255 rad ≈ 14.6°)
  tipZ: -0.0901, // bükülmüş uç z konumu
  brace: 0.16,   // kiriş germe yüksekliği
};"""
new_const = """const BOW = {
  half: 0.7,      // kol uzunluğu (kabza merkezinden uç nock'a)
  k: 0.5,         // ana eğrilik çarpanı (gövde geriye, yani -Z'ye bükülür)
  recurveFrom: 0.72, // kolun bu oranından sonra uçlar içe (kiriş yönüne) kıvrılır
  recurveK: 2.3,  // recurve eğrilik çarpanı
};

/** Yay kolu eğrilik fonksiyonu: θ(|y|) — gövde -Z'ye, uçlar +Z'ye kıvrılır. */
function bowCurvature(absY: number): number {
  const L = BOW.half;
  const r = BOW.recurveFrom;
  const u = absY / L;
  let theta = -BOW.k * Math.min(absY, r * L) * Math.min(absY, r * L);
  if (u > r) {
    const k = (u - r) / (1 - r);
    theta += BOW.recurveK * (r * L) * (absY - r * L) * (0.5 + 0.5 * k);
  }
  return theta;
}

/** Eğrilikten türetilen yerel teğet açısı (sayısal türev). */
function bowTangentAngle(absY: number, sign: 1 | -1): number {
  const h = 0.01;
  const dTheta = (bowCurvature(Math.min(BOW.half, absY + h)) - bowCurvature(Math.max(0, absY - h))) / (2 * h);
  return sign * dTheta * absY * 0 - sign * dTheta * (absY === 0 ? 1 : absY) * 0 + sign * dTheta * 0 + sign * 0 - sign * dTheta * 0 + sign * dTheta * 0 - sign * 0;
}"""
assert old_const in s
s = s.replace(old_const, new_const)

# bowTangentAngle'ı doğru ve basit hale getir
s = s.replace("""/** Eğrilikten türetilen yerel teğet açısı (sayısal türev). */
function bowTangentAngle(absY: number, sign: 1 | -1): number {
  const h = 0.01;
  const dTheta = (bowCurvature(Math.min(BOW.half, absY + h)) - bowCurvature(Math.max(0, absY - h))) / (2 * h);
  return sign * dTheta * absY * 0 - sign * dTheta * (absY === 0 ? 1 : absY) * 0 + sign * dTheta * 0 + sign * 0 - sign * dTheta * 0 + sign * dTheta * 0 - sign * 0;
}""",
"""/**
 * Bükülmüş kol üzerindeki bir noktanın dünya konumunu ve teğet açısını verir.
 * Büküm θ(y)=curvature(|y|)·sign(y) olduğundan nokta (0,y,0) →
 *   (y·(-sinθ_sign), y·cosθ, 0) ... fakat bendGeometry X/Y düzleminde
 * döndürdüğü için sonuç: x = -y·sin(θs), y = y·cos(θs), z = 0.
 * Yay düzlemini XZ'e taşımak için kolu ayrıca -90° X rotasyonu ile yatırıyoruz.
 */
function bowPointOnLimb(absY: number, sign: 1 | -1): { pos: THREE.Vector3; tangentDeg: number } {
  const theta = bowCurvature(absY) * sign;
  const y = absY * sign;
  // bendGeometry: (x,y) → (x·cosθ − y·sinθ, x·sinθ + y·cosθ)
  const px = -y * Math.sin(theta);
  const py = y * Math.cos(theta);
  // teğet açısı: θ_total = θ (büküm toplamı) → derece
  const tangentDeg = (theta / DEG) * -1;
  return { pos: v3(px, py, 0), tangentDeg };
}""")

# ── buildRecurveBow gövdesini yeni matematiğe bağla ──
old_limb = """  const buildLimb = (dir: 1 | -1): void => {
    const spine: Vec3Tuple[] = [];
    for (let i = 0; i <= steps; i++) spine.push([0, (i / steps) * BOW.half * 0.985, 0]);
    const g = sweptBlade(ctx, {
      profile: limbProfile,
      spine,
      steps: steps + 1,
      scale: (t) => {
        const w = lerp(1, 0.46, t); // uçlara doğru daralma
        const swell = 1 + 0.1 * Math.sin(Math.PI * t);
        return w * swell;
      },
      seedNormal: [1, 0, 0],
    });
    // kompozit yay: boynuz karın + ahşap çekirdek hissi için hafif bük
    bendGeometry(g, (y) => dir * BOW.k * y * y);
    P.push({ geometry: g, material: dir === 1 ? 'wood' : 'woodDark' });

    // ── kemik uç nock ──
    const nock = new THREE.CylinderGeometry(0.013, 0.019, 0.075, radial);
    nock.translate(0, 0.03, 0);
    const tipY = dir * BOW.half;
    // bükülmüş ucun teğet açısı: theta'(y) = 2·k·y
    const ang = 2 * BOW.k * BOW.half;
    P.push({ geometry: nock, material: 'bone', position: [0, tipY, BOW.tipZ], rotation: [dir * ang * 0.55, 0, 0] });
    const groove = new THREE.TorusGeometry(0.014, 0.004, 3, radial);
    groove.rotateX(90 * DEG);
    P.push({ geometry: groove, material: 'horn', position: [0, tipY + dir * 0.045, BOW.tipZ + dir * 0.012] });

    // ── kol üzerinde tendon sarımı (büküm sonrası z konumu: -k·y·|y|) ──
    if (hero) {
      for (const t of [0.34, 0.56, 0.76]) {
        const y = dir * BOW.half * t;
        const ring = new THREE.TorusGeometry(0.021, 0.005, 3, 7);
        ring.rotateX(90 * DEG);
        P.push({ geometry: ring, material: 'trim', position: [0, y, -BOW.k * y * Math.abs(y)] });
      }
      // kabza derisi
      const wrapGeo = new THREE.CylinderGeometry(0.03, 0.03, 0.16, 8);
      P.push({ geometry: wrapGeo, material: 'leather', position: [0, dir * 0.02, 0.004] });
    }
  };
  buildLimb(1);
  buildLimb(-1);"""

new_limb = """  const buildLimb = (dir: 1 | -1): void => {
    const spine: Vec3Tuple[] = [];
    for (let i = 0; i <= steps; i++) spine.push([0, (i / steps) * BOW.half * 0.985, 0]);
    const g = sweptBlade(ctx, {
      profile: limbProfile,
      spine,
      steps: steps + 1,
      scale: (t) => {
        const w = lerp(1, 0.46, t); // uçlara doğru daralma
        const swell = 1 + 0.1 * Math.sin(Math.PI * t);
        return w * swell;
      },
      seedNormal: [1, 0, 0],
    });
    // kompozit yay bükümü: gövde -Z'ye (kiriş tersi), uçlar içe kıvrılır
    bendGeometry(g, (y) => bowCurvature(Math.abs(y)) * Math.sign(y || dir));
    P.push({ geometry: g, material: dir === 1 ? 'wood' : 'woodDark' });

    // ── kemik uç nock: bükülmüş uç noktasına, teğet yönünde ──
    const tip = bowPointOnLimb(BOW.half, dir);
    const nock = new THREE.CylinderGeometry(0.013, 0.019, 0.075, radial);
    nock.translate(0, 0.03, 0);
    P.push({
      geometry: nock,
      material: 'bone',
      position: [tip.pos.x, tip.pos.y, 0],
      rotation: [0, 0, dir === 1 ? -tip.tangentDeg * DEG : -tip.tangentDeg * DEG],
    });
    const groove = new THREE.TorusGeometry(0.014, 0.0045, 3, radial);
    groove.rotateX(90 * DEG);
    const grooveAt = bowPointOnLimb(BOW.half * 0.94, dir);
    P.push({
      geometry: groove,
      material: 'horn',
      position: [grooveAt.pos.x, grooveAt.pos.y, 0],
      rotation: [0, 0, -grooveAt.tangentDeg * DEG],
    });

    // ── kol üzerinde tendon sarımı (bükülmüş konumlarla) ──
    if (hero) {
      for (const t of [0.34, 0.56, 0.76]) {
        const at = bowPointOnLimb(BOW.half * t, dir);
        const ring = new THREE.TorusGeometry(0.021, 0.005, 3, 7);
        ring.rotateX(90 * DEG);
        P.push({ geometry: ring, material: 'trim', position: [at.pos.x, at.pos.y, 0], rotation: [0, 0, -at.tangentDeg * DEG] });
      }
    }
  };
  buildLimb(1);
  buildLimb(-1);"""
assert old_limb in s
s = s.replace(old_limb, new_limb)

# ── kiriş yolu: gerçek uç noktalarından ──
old_string = """  // ── kiriş: iki kol ucundan hafif içe kavisle ──
  const stringPath = [
    v3(0, BOW.half, BOW.tipZ),
    v3(0, BOW.half * 0.5, BOW.tipZ * 0.55 + BOW.brace * 0.35),
    v3(0, 0, BOW.brace),
    v3(0, -BOW.half * 0.5, BOW.tipZ * 0.55 + BOW.brace * 0.35),
    v3(0, -BOW.half, BOW.tipZ),
  ];
  const string = tubeFromPoints(stringPath, hero ? 0.0055 : 0.007, hero ? 4 : 3, 1);
  P.push({ geometry: string, material: hero ? 'bone' : 'clothLight' });

  // ── kiriş orta sarımı (serving) ──
  if (hero) {
    const serving = new THREE.CylinderGeometry(0.009, 0.009, 0.09, 5);
    P.push({ geometry: serving, material: 'clothLight', position: [0, 0, BOW.brace] });
  }"""
new_string = """  // ── kiriş: bükülmüş uç noktalarını birleştirir, ortada kabzaya yaklaşır ──
  const tipUp = bowPointOnLimb(BOW.half, 1).pos;
  const tipDown = bowPointOnLimb(BOW.half, -1).pos;
  const brace = Math.max(0.1, Math.abs(tipUp.x) * 0.55);
  const stringPath = [
    v3(tipUp.x, tipUp.y, 0),
    v3(brace * 0.55, BOW.half * 0.5, 0),
    v3(brace, 0, 0),
    v3(brace * 0.55, -BOW.half * 0.5, 0),
    v3(tipDown.x, tipDown.y, 0),
  ];
  const string = tubeFromPoints(stringPath, hero ? 0.0055 : 0.007, hero ? 4 : 3, 1);
  P.push({ geometry: string, material: hero ? 'bone' : 'clothLight' });

  // ── kiriş orta sarımı (serving) + ok yatağı ──
  if (hero) {
    const serving = new THREE.CylinderGeometry(0.009, 0.009, 0.1, 5);
    P.push({ geometry: serving, material: 'clothLight', position: [brace, 0, 0] });
    const nockingPoint = new THREE.TorusGeometry(0.012, 0.004, 3, 6);
    nockingPoint.rotateY(90 * DEG);
    P.push({ geometry: nockingPoint, material: 'leatherDark', position: [brace, 0.02, 0] });
  }"""
assert old_string in s
s = s.replace(old_string, new_string)

# riser/kabza: kiriş düzleminde (X) değil, gövde düzleminde kalmalı → z'yi sıfırla
s = s.replace("""  // ── kabza (riser): kalınlaştırılmış merkez ──
  const riser = new THREE.CylinderGeometry(0.034, 0.03, 0.17, radial);
  P.push({ geometry: riser, material: 'leatherDark', position: [0, 0, 0.002] });
  const riserPlate = new THREE.BoxGeometry(0.05, 0.11, 0.022);
  P.push({ geometry: riserPlate, material: 'woodDark', position: [0, 0, -0.026] });
  if (hero) {
    const gripRingTop = new THREE.TorusGeometry(0.032, 0.006, 3, 8);
    gripRingTop.rotateX(90 * DEG);
    P.push({ geometry: gripRingTop, material: 'gold', position: [0, 0.085, 0.002] });
    const gripRingBot = gripRingTop.clone();
    P.push({ geometry: gripRingBot, material: 'gold', position: [0, -0.085, 0.002] });
  }""",
"""  // ── kabza (riser): kalınlaştırılmış merkez + deri sarım ──
  const riser = new THREE.CylinderGeometry(0.034, 0.03, 0.17, radial);
  P.push({ geometry: riser, material: 'leatherDark', position: [0, 0, 0] });
  const riserPlate = new THREE.BoxGeometry(0.022, 0.11, 0.05);
  P.push({ geometry: riserPlate, material: 'woodDark', position: [-0.026, 0, 0] });
  if (hero) {
    const gripRingTop = new THREE.TorusGeometry(0.032, 0.006, 3, 8);
    gripRingTop.rotateX(90 * DEG);
    P.push({ geometry: gripRingTop, material: 'gold', position: [0, 0.085, 0] });
    const gripRingBot = gripRingTop.clone();
    P.push({ geometry: gripRingBot, material: 'gold', position: [0, -0.085, 0] });
    const wrapGeo = new THREE.CylinderGeometry(0.037, 0.037, 0.13, 8);
    P.push({ geometry: wrapGeo, material: 'leather', position: [0, 0, 0] });
  }""")

io.open(p, 'w', encoding='utf-8').write(s)
print('bow rewritten')

import io

# ── Core.ts: bakePiece mevcut vertex rengini korusun (bakeHierarchy için şart) ──
p = 'src/Core.ts'
s = io.open(p, encoding='utf-8').read()
old = """  const def = matLib.resolve(piece.material);
  let color = def ? def.color : 0xffffff;
  // Satır içi (inline) materyal tanımları da fraksiyon tint'ine saygı duyar.
  const faction = matLib.getFaction();
  if (def && def.factionTint && faction) color = faction.colorFor(def.factionTint);
  return normalizeGeometry(g, color);"""
new = """  const def = matLib.resolve(piece.material);
  // Satır içi (inline) materyal tanımları da fraksiyon tint'ine saygı duyar.
  const faction = matLib.getFaction();
  if (def && def.factionTint && faction) return normalizeGeometry(g, faction.colorFor(def.factionTint));
  if (def) return normalizeGeometry(g, def.color);
  // Materyal verilmemişse geometrideki mevcut renk attribute'u korunur
  // (bakeHierarchy / bakeToGeometry zinciri için kritik).
  if (!g.attributes.color && piece.material === undefined) return normalizeGeometry(g, 0xffffff);
  return normalizeGeometry(g, null);"""
assert old in s
s = s.replace(old, new)
io.open(p, 'w', encoding='utf-8').write(s)

# ── Character.ts ──
p = 'src/Character.ts'
s = io.open(p, encoding='utf-8').read()

old_mounts_start = s.index('export const EQUIPMENT_MOUNTS: Record<string, EquipmentMount> = {')
old_mounts_end = s.index('/** Ok kılıfı (sadak)')
new_mounts = '''/**
 * Her ekipmanın elde / sırta nasıl duracağı. `position` değeri parçanın
 * KABZA (grip) noktasını ekleme oturtur: position = -grip + el ofseti.
 * Karakter +Z'ye bakar; sağ el +X, sol el -X tarafındadır.
 */
export const EQUIPMENT_MOUNTS: Record<string, EquipmentMount> = {
  // ── sağ el: kılıçlar ──
  gladius: { joint: 'weaponR', position: [0.01, -0.19, 0.02], rotation: [0, 0, 0], scale: 1 },
  scimitar: { joint: 'weaponR', position: [0.01, -0.2, 0.02], rotation: [0, 0, 0], scale: 1 },
  greatsword: { joint: 'weaponR', position: [0.0, -0.18, -0.02], rotation: [0, 0, 0], scale: 1 },
  // ── sağ el: baltalar (sap elde, baş yukarıda) ──
  warAxe: { joint: 'weaponR', position: [0.01, -0.3, 0.01], rotation: [0, 0, 0], scale: 1 },
  bardiche: { joint: 'weaponR', position: [0.02, -0.82, 0.0], rotation: [0, 0, 0], scale: 1 },
  // ── sağ el: gönderliler ──
  lance: { joint: 'weaponR', position: [0.02, -1.0, 0.06], rotation: [-6 * DEG, 0, 0], scale: 1 },
  halberd: { joint: 'weaponR', position: [0.02, -0.78, 0.02], rotation: [0, 0, 0], scale: 1 },
  // ── sol el: yay (kollar dikey, kiriş karaktere bakacak şekilde) ──
  recurveBow: { joint: 'weaponL', position: [0.0, -0.02, -0.04], rotation: [0, 90 * DEG, 0], scale: 1 },
  // ── sağ el: ok (atış anında) ──
  arrow: { joint: 'weaponR', position: [0.0, -0.06, 0.02], rotation: [0, 0, 0], scale: 1 },
  // ── sol ön kol: kalkanlar (yüz dışarı, -X'e bakar) ──
  vikingShield: { joint: 'forearmL', position: [0.06, -0.18, -0.01], rotation: [0, -90 * DEG, 0], scale: 1 },
  kiteShield: { joint: 'forearmL', position: [0.07, -0.16, -0.02], rotation: [0, -90 * DEG, 0], scale: 1 },
  // ── kafa: Armory miğferleri (zırh sistemi yerine vitrin amaçlı kullanım) ──
  greatHelm: { joint: 'head', position: [0, 0.055, 0], rotation: [0, 0, 0], scale: 1 },
  hornedHelm: { joint: 'head', position: [0, 0.05, 0], rotation: [0, 0, 0], scale: 1 },
  // ── gövde: Armory göğüs zırhı ──
  cuirass: { joint: 'pelvis', position: [0, 0.28, 0], rotation: [0, 0, 0], scale: 1 },
  // ── sırt ──
  backSword: { joint: 'chest', position: [0.04, 0.02, -0.19], rotation: [0, 0, 166 * DEG], scale: 1 },
  backAxe: { joint: 'chest', position: [-0.05, 0.0, -0.19], rotation: [0, 0, 186 * DEG], scale: 1 },
  backBow: { joint: 'chest', position: [-0.08, 0.0, -0.18], rotation: [0, 0, 96 * DEG], scale: 1 },
  backQuiver: { joint: 'chest', position: [0.1, 0.04, -0.18], rotation: [0, 0, -20 * DEG], scale: 1 },
  backShield: { joint: 'chest', position: [0, -0.04, -0.21], rotation: [0, 180 * DEG, 0], scale: 1 },
};

'''
s = s[:old_mounts_start] + new_mounts + s[old_mounts_end:]

# back item seçimini tipe göre doğru mount'a yönlendir
s = s.replace("""    if (L.back === 'arrow') this.equip('quiver', 'back');
    else if (L.back) this.equip(L.back, 'back', L.back === 'recurveBow' ? 'backBow' : 'backSword');""",
    """    if (L.back === 'arrow') this.equip('quiver', 'back');
    else if (L.back) this.equip(L.back, 'back', backMountFor(L.back));""")

# bakeHierarchy: mergePieces artık renk koruyor, sadeleştir
s = s.replace("""  const merged = mergePieces(out.map((g) => ({ geometry: g })), new MaterialLibrary({}));
  for (const g of out) g.dispose();
  return merged;""",
    """  const merged = mergePieces(out.map((g) => ({ geometry: g })), EMPTY_MATS);
  for (const g of out) g.dispose();
  return merged;""")
s = s.replace("""export { weldVertices, ArmoryItemBuild };""",
    """const EMPTY_MATS = new MaterialLibrary({});

/** Sırta asılan ekipman için doğru mount anahtarı. */
export function backMountFor(id: ArmoryItemId): string {
  switch (id) {
    case 'recurveBow': return 'backBow';
    case 'vikingShield':
    case 'kiteShield': return 'backShield';
    case 'warAxe':
    case 'bardiche': return 'backAxe';
    default: return 'backSword';
  }
}

export type { ArmoryItemBuild };""")

# kullanılmayan import'ları temizle
s = s.replace("  profile2,\n  quantizeGeometry,\n  sweep,\n  triCount,\n  v3,\n  weldVertices,\n} from './Core.js';",
              "  profile2,\n  quantizeGeometry,\n  sweep,\n  triCount,\n  v3,\n} from './Core.js';")
s = s.replace("import { Armory, ArmoryItemId, ArmoryItemBuild } from './Armory.js';",
              "import { Armory, ArmoryItemId, ArmoryItemBuild } from './Armory.js';")

io.open(p, 'w', encoding='utf-8').write(s)
print('ok')

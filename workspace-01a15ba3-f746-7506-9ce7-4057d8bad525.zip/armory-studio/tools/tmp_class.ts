
/* ═══════════════════════════════════════════════════════════════════════
   KATALOG
   ═══════════════════════════════════════════════════════════════════════ */

const SWING_FAST: Omit<AttackSpec, 'grip' | 'arm' | 'strike'> = {
  type: 'swing', lunge: 0.14, duration: 0.85, impactAt: 0.34, impactSound: 'swordClash',
};

export const ARMORY_CATALOG: ArmoryItemSpec[] = [
  {
    id: 'gladius',
    name: 'İmparatorluk Kısa Kılıcı',
    cls: 'sword',
    faction: 'İmparatorluk',
    twoHanded: false,
    displayScale: 1.15,
    displayOffset: [0, -0.5, 0],
    displayRotation: [0, 0, 8],
    reach: 0.92,
    weightKg: 1.1,
    description:
      'Legion piyadesinin yemin kılıcı. Yaprak biçimli namlu zırh aralığına saplanmak için daraltılmış, kartal başlı altın topuz imparatorluk rütbesini taşır.',
    attack: { ...SWING_FAST, grip: [0, 0.19, 0], arm: [-108, -22, 16], strike: [104, 26, -12], duration: 0.78, impactAt: 0.3 },
    showcaseSound: 'swordClash',
  },
  {
    id: 'greatsword',
    name: 'Çift Elli Şövalye Kılıcı',
    cls: 'sword',
    faction: 'Vlandiya',
    twoHanded: true,
    displayScale: 1.05,
    displayOffset: [0, -0.78, 0],
    displayRotation: [0, 0, 5],
    reach: 1.5,
    weightKg: 2.6,
    description:
      'Kan oluklu (fuller) geniş namlu, aşağı kıvrık ağır siper ve haç kabartmalı kabza. İki elle savrulduğunda kalkan hattını yarar.',
    attack: {
      type: 'swing', grip: [0, 0.18, 0], arm: [-128, -30, 18], strike: [126, 34, -16],
      lunge: 0.24, duration: 1.15, impactAt: 0.5, impactSound: 'swordClash',
    },
    showcaseSound: 'swordClash',
  },
  {
    id: 'scimitar',
    name: 'Kuzait Eğri Kılıcı',
    cls: 'sword',
    faction: 'Kuzait',
    twoHanded: false,
    displayScale: 1.1,
    displayOffset: [0, -0.55, 0],
    displayRotation: [0, 0, 12],
    reach: 0.98,
    weightKg: 1.3,
    description:
      'Bozkırın kesme ustası. Kavisli namlu at sırtında çekme kesikleri üretir; uçtaki yalman genişlemesi darbenin ağırlığını bıçak ucuna taşır.',
    attack: { ...SWING_FAST, grip: [0, 0.2, 0], arm: [-96, -48, 22], strike: [86, 62, -18], duration: 0.72, impactAt: 0.28 },
    showcaseSound: 'swordClash',
  },
  {
    id: 'warAxe',
    name: 'Tek Elli Savaş Baltası',
    cls: 'axe',
    faction: 'Sturgia',
    twoHanded: false,
    displayScale: 1.15,
    displayOffset: [0, -0.42, 0],
    displayRotation: [0, 0, -6],
    reach: 0.86,
    weightKg: 1.6,
    description:
      'Sakallı (bearded) hilal ağız, çekiç poll\'u ve dikenli dip. Kalkana takıp aşağı çeken kuzeyli tekniği için dengelenmiş.',
    attack: {
      type: 'chop', grip: [0, 0.3, 0], arm: [-132, -26, 20], strike: [128, 22, -14],
      lunge: 0.18, duration: 1.0, impactAt: 0.44, impactSound: 'heavyAxeSwing',
    },
    showcaseSound: 'heavyAxeSwing',
  },
  {
    id: 'bardiche',
    name: 'Çift Elli Sturgia Baltası (Bardiche)',
    cls: 'axe',
    faction: 'Sturgia',
    twoHanded: true,
    displayScale: 1.0,
    displayOffset: [0, -0.9, 0],
    displayRotation: [0, 0, -4],
    reach: 1.9,
    weightKg: 3.4,
    description:
      'Sap boyunca uzanan dev hilal ağız ve çelik dil. Druzhinnik\'in hattı: tek savurmada kalkanı da, mızrak hizasını da söker.',
    attack: {
      type: 'chop', grip: [0, 0.82, 0], arm: [-142, -34, 24], strike: [140, 30, -20],
      lunge: 0.3, duration: 1.5, impactAt: 0.66, impactSound: 'heavyAxeSwing',
    },
    showcaseSound: 'heavyAxeSwing',
  },
  {
    id: 'lance',
    name: 'Süvari Kargısı',
    cls: 'polearm',
    faction: 'Vlandiya',
    twoHanded: true,
    displayScale: 0.72,
    displayOffset: [0, -0.9, 0],
    displayRotation: [0, 0, 10],
    reach: 2.36,
    weightKg: 2.2,
    description:
      'Uzun dişbudak gövde, yaprak biçimli çelik uç, el koruyucu (vamplate) ve fraksiyon flamalı. Dörtnala hücumda tüm kinetik enerjiyi uca taşır.',
    attack: {
      type: 'thrust', grip: [0, 1.0, 0], arm: [-24, -18, 0], strike: [16, 12, 0],
      lunge: 0.55, duration: 1.35, impactAt: 0.62, impactSound: 'arrowHit',
    },
    showcaseSound: 'battleHorn',
  },
  {
    id: 'halberd',
    name: 'Halberd / Glaive',
    cls: 'polearm',
    faction: 'İmparatorluk',
    twoHanded: true,
    displayScale: 0.78,
    displayOffset: [0, -0.9, 0],
    displayRotation: [0, 0, 8],
    reach: 2.22,
    weightKg: 2.9,
    description:
      'Mızrak ucu + yan balta ağzı + arka kanca. Süvariyi eyerden çekmek, zırh eklemine saplamak ve hattı tutmak için üç işlev tek gövdede.',
    attack: {
      type: 'thrust', grip: [0, 0.78, 0], arm: [-30, -22, 6], strike: [22, 18, -6],
      lunge: 0.45, duration: 1.4, impactAt: 0.64, impactSound: 'swordClash',
    },
    showcaseSound: 'swordClash',
  },
  {
    id: 'recurveBow',
    name: 'Kavisli Kompozit Yay',
    cls: 'bow',
    faction: 'Kuzait',
    twoHanded: true,
    displayScale: 1.0,
    displayOffset: [0, 0, 0],
    displayRotation: [0, 0, 90],
    reach: 0.7,
    weightKg: 0.9,
    description:
      'Boynuz karın, ahşap çekirdek ve tendon sırt. Uçları içe kıvrık (recurve) gövde kısa boyda yüksek çekiş gücü verir; at sırtında kurmak için tasarlanmış.',
    attack: {
      type: 'draw', grip: [0, 0, 0], arm: [-70, 0, 0], strike: [10, 0, 0],
      pullback: 0.22, lunge: 0, duration: 1.9, impactAt: 1.16, impactSound: 'bowRelease',
    },
    showcaseSound: 'bowRelease',
  },
  {
    id: 'arrow',
    name: 'Tüylü Savaş Oku',
    cls: 'arrow',
    faction: 'Kuzait',
    twoHanded: false,
    displayScale: 1.7,
    displayOffset: [0, 0, 0],
    displayRotation: [0, 0, -28],
    reach: 0.46,
    weightKg: 0.05,
    description:
      'Dört yüzlü bodkin uç zırh halkalarını aralar; üç tüy (kırmızı-beyaz-kırmızı) oku döndürerek uçuşu stabilize eder.',
    attack: {
      type: 'thrust', grip: [0, -0.2, 0], arm: [-40, 0, 0], strike: [70, 0, 0],
      lunge: 0.9, duration: 0.55, impactAt: 0.3, impactSound: 'arrowHit',
    },
    showcaseSound: 'arrowHit',
  },
  {
    id: 'vikingShield',
    name: 'Yuvarlak Viking Kalkanı',
    cls: 'shield',
    faction: 'Sturgia',
    twoHanded: false,
    displayScale: 1.15,
    displayOffset: [0, 0, 0],
    displayRotation: [0, -18, 6],
    reach: 0.72,
    weightKg: 5.4,
    description:
      'Kubbeli tahta gövde, demir kenar çemberi ve konik göbek (boss). Göbek yumruk darbelerini dağıtır, çıtalar balta ağızını tutar.',
    attack: {
      type: 'bash', grip: [0, 0, -0.06], arm: [-26, -18, 0], strike: [22, 24, 0],
      lunge: 0.28, duration: 0.95, impactAt: 0.46, impactSound: 'shieldBlock',
    },
    showcaseSound: 'shieldBlock',
  },
  {
    id: 'kiteShield',
    name: 'Şövalye Uçurtma Kalkanı',
    cls: 'shield',
    faction: 'Vlandiya',
    twoHanded: false,
    displayScale: 0.95,
    displayOffset: [0, 0.1, 0],
    displayRotation: [0, -16, 4],
    reach: 1.5,
    weightKg: 6.8,
    description:
      'İçe bombeli heater gövde, çelik kenar bandı ve guige kayışı. Eyerde bacakları örten uzun alt uç, eyerden alma hücumlarında hayat kurtarır.',
    attack: {
      type: 'bash', grip: [0, 0.1, -0.08], arm: [-24, -22, 0], strike: [18, 26, 0],
      lunge: 0.24, duration: 1.05, impactAt: 0.5, impactSound: 'shieldBlock',
    },
    showcaseSound: 'shieldBlock',
  },
  {
    id: 'greatHelm',
    name: 'Kapalı Şövalye Miğferi (Great Helm)',
    cls: 'armor',
    faction: 'Vlandiya',
    twoHanded: false,
    displayScale: 1.9,
    displayOffset: [0, -0.05, 0],
    displayRotation: [0, -22, 0],
    reach: 0.4,
    weightKg: 2.8,
    description:
      'Tam kapalı tas, dar göz yarığı, nefes delikleri ve alın üzerinde altın haç. Görüşü kısar ama mızrak hücumunda yüzü kurtarır.',
    attack: {
      type: 'raise', grip: [0, 0, 0], arm: [-24, 0, 0], strike: [22, 0, 0],
      lunge: 0, duration: 1.2, impactAt: 0.6, impactSound: 'shieldBlock',
    },
    showcaseSound: 'battleHorn',
  },
  {
    id: 'hornedHelm',
    name: 'Boynuzlu Nord Miğferi',
    cls: 'armor',
    faction: 'Sturgia',
    twoHanded: false,
    displayScale: 1.9,
    displayOffset: [0, -0.06, 0],
    displayRotation: [0, -20, 0],
    reach: 0.42,
    weightKg: 2.4,
    description:
      'Konik spangen tas, süpürülmüş kemik boynuzlar ve fraksiyon sorgucu. Konik tepe balta ağızını yana kaydırır; boynuzlar silüeti büyütüp korku salar.',
    attack: {
      type: 'raise', grip: [0, 0, 0], arm: [-26, 0, 0], strike: [24, 0, 0],
      lunge: 0, duration: 1.2, impactAt: 0.6, impactSound: 'shieldBlock',
    },
    showcaseSound: 'battleHorn',
  },
  {
    id: 'cuirass',
    name: 'Göğüs Zırhı + Omuzluklar',
    cls: 'armor',
    faction: 'İmparlorluk',
    twoHanded: false,
    displayScale: 1.25,
    displayOffset: [0, -0.1, 0],
    displayRotation: [0, -18, 0],
    reach: 0.6,
    weightKg: 9.5,
    description:
      'Eliptik gövde tası, göğüs omurgası (keel), üç katmanlı omuzluk, bel bantları ve boyunluk. Kavisli yüzeyler oku sektirir, katmanlar omuz darbelerini yayar.',
    attack: {
      type: 'raise', grip: [0, 0, 0], arm: [-18, 0, 0], strike: [16, 0, 0],
      lunge: 0, duration: 1.3, impactAt: 0.65, impactSound: 'shieldBlock',
    },
    showcaseSound: 'battleHorn',
  },
];

/** Bütçe sınıfları: silah/kalkan sıkı, miğfer orta, gövde zırhı geniş. */
export function budgetFor(id: ArmoryItemId, lod: LodLevel): number {
  const isWeapon = !['greatHelm', 'hornedHelm', 'cuirass'].includes(id);
  if (lod === 'hero') return isWeapon ? 600 : id === 'cuirass' ? 2600 : 900;
  if (lod === 'battle') return isWeapon ? BUDGET.weaponMax : id === 'cuirass' ? 420 : 280;
  return isWeapon ? 90 : id === 'cuirass' ? 260 : 170;
}

const BUILDERS: Record<ArmoryItemId, (ctx: BuildCtx) => Piece[]> = {
  gladius: buildGladius,
  greatsword: buildGreatsword,
  scimitar: buildScimitar,
  warAxe: buildWarAxe,
  bardiche: buildBardiche,
  lance: buildLance,
  halberd: buildHalberd,
  recurveBow: buildRecurveBow,
  arrow: buildArrow,
  vikingShield: buildVikingShield,
  kiteShield: buildKiteShield,
  greatHelm: buildGreatHelm,
  hornedHelm: buildHornedHelm,
  cuirass: buildCuirass,
};

export const ARMORY_IDS = Object.keys(BUILDERS) as ArmoryItemId[];

/* ═══════════════════════════════════════════════════════════════════════
   ANA SINIF
   ═══════════════════════════════════════════════════════════════════════ */

export interface ArmoryOptions {
  /** Deterministik üretim tohumu. */
  seed?: number;
  /** Bütçe aşımında konsola uyarı yaz (geliştirme sırasında açık bırak). */
  warnOnBudgetOverflow?: boolean;
}

/**
 * Prosedürel cephanelik. Kullanım:
 *
 *   const armory = new Armory();
 *   const sword  = armory.buildItem('greatsword', 'hero');
 *   scene.add(sword.group);                                  // hiyerarşi
 *   const mesh = new THREE.Mesh(sword.merged, sword.material); // tek draw-call
 *   const crowd = armory.createInstanced('vikingShield', 500);  // InstancedMesh
 */
export class Armory {
  readonly palette: MaterialLibrary;
  readonly faction: FactionPalette;
  readonly budget = new BudgetTracker();
  readonly catalog = ARMORY_CATALOG;
  private seed: number;

  constructor(faction: FactionPalette | string = 'vlandia', options: ArmoryOptions = {}) {
    this.faction = typeof faction === 'string' ? FactionPalette.byId(faction) : faction;
    this.seed = options.seed ?? 20261020;
    this.budget.warn = options.warnOnBudgetOverflow ?? true;
    this.palette = new MaterialLibrary(createArmoryPalette(this.faction));
    this.palette.setFaction(this.faction);
  }

  /** Fraksiyonu değiştir (tüm tint'li materyaller yeniden üretilir). */
  setFaction(faction: FactionPalette | string): void {
    const f = typeof faction === 'string' ? FactionPalette.byId(faction) : faction;
    (this as { faction: FactionPalette }).faction = f;
    for (const [key, def] of Object.entries(createArmoryPalette(f))) this.palette.define(key, def);
    this.palette.setFaction(f);
  }

  getSpec(id: ArmoryItemId): ArmoryItemSpec {
    const spec = ARMORY_CATALOG.find((s) => s.id === id);
    if (!spec) throw new Error(`[Bannerforge] Armory: katalogda "${id}" yok.`);
    return spec;
  }

  /** Bir ekipmanı üret: hem THREE.Group hem merged BufferGeometry döner. */
  buildItem(id: ArmoryItemId, lod: LodLevel = 'hero'): ArmoryItemBuild {
    const builder = BUILDERS[id];
    if (!builder) throw new Error(`[Bannerforge] Armory: "${id}" için üretici yok.`);
    const ctx = ctxFor(lod, this.palette, this.faction, this.seed + hashId(id));
    const pieces = builder(ctx);
    if (pieces.length === 0) throw new Error(`[Bannerforge] Armory: "${id}" üreticisi boş çıktı.`);

    // ── grup (hiyerarşi / materyal başına mesh) ──
    const group = new THREE.Group();
    group.name = `${id}_${lod}`;
    const materials: THREE.MeshStandardMaterial[] = [];
    const seen = new Set<string>();
    for (let i = 0; i < pieces.length; i++) {
      const piece = pieces[i];
      const def = this.palette.resolve(piece.material);
      const matKey = def ? def.key : '__inline__' + i;
      const mat = def ? this.palette.material(def.key) : inlineMaterial(piece.material as MaterialDef);
      if (!seen.has(matKey)) {
        seen.add(matKey);
        materials.push(mat);
      }
      const mesh = new THREE.Mesh(piece.geometry, mat);
      mesh.name = piece.name ?? `${matKey}_${i}`;
      if (piece.position) mesh.position.set(piece.position[0], piece.position[1], piece.position[2]);
      if (piece.rotation) mesh.rotation.set(piece.rotation[0], piece.rotation[1], piece.rotation[2]);
      if (piece.scale !== undefined) {
        if (typeof piece.scale === 'number') mesh.scale.setScalar(piece.scale);
        else mesh.scale.set(piece.scale[0], piece.scale[1], piece.scale[2]);
      }
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      group.add(mesh);
    }

    // ── merged (tek draw-call / InstancedMesh) ──
    const merged = mergePieces(pieces, this.palette);
    const material = this.palette.mergedMaterial(`__merged_${this.faction.id}_${lod}`);
    const triangles = Math.round(triCount(merged));
    const budget = budgetFor(id, lod);
    this.budget.check(`${id}/${lod}`, merged, budget);

    merged.computeBoundingBox();
    const box = merged.boundingBox ?? new THREE.Box3().setFromBufferAttribute(merged.attributes.position as THREE.BufferAttribute);
    const size = box.getSize(new THREE.Vector3());
    const sphere = new THREE.Sphere();
    box.getBoundingSphere(sphere);

    return {
      id,
      spec: this.getSpec(id),
      lod,
      group,
      merged,
      material,
      materials,
      triangles,
      budget,
      withinBudget: triangles <= budget,
      boundingBox: box,
      size,
    };
  }

  /** Tüm kataloğu üret (vitrin / test için). */
  buildAll(lod: LodLevel = 'hero'): ArmoryItemBuild[] {
    return ARMORY_IDS.map((id) => this.buildItem(id, lod));
  }

  /**
   * GPU Instancing: merged geometri + tek materyal ile InstancedMesh.
   * 500v500 savaşlarda her birim tipi için bir mesh → draw-call sayısı
   * birim sayısından bağımsız kalır.
   */
  createInstanced(id: ArmoryItemId, count: number, lod: LodLevel = 'battle'): THREE.InstancedMesh {
    const item = this.buildItem(id, lod);
    const mesh = new THREE.InstancedMesh(item.merged, item.material, count);
    mesh.castShadow = false;
    mesh.receiveShadow = true;
    mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    mesh.name = `instanced_${id}_${lod}`;
    mesh.frustumCulled = true;
    return mesh;
  }

  /**
   * Bir ekipmanı el/askı noktasına takılabilir hale getirir:
   * pivot (grip) orijine gelir, displayOffset + displayScale uygulanır.
   */
  createDisplayNode(item: ArmoryItemBuild, useGrip = true): THREE.Group {
    const holder = new THREE.Group();
    const inner = new THREE.Group();
    inner.add(item.group);
    const s = item.spec.displayScale;
    const off = item.spec.displayOffset;
    const grip = item.spec.attack.grip;
    if (useGrip && (item.spec.cls === 'sword' || item.spec.cls === 'axe' || item.spec.cls === 'polearm')) {
      inner.position.set(-(grip[0] + off[0]) * s, -(grip[1] + off[1]) * s, -(grip[2] + off[2]) * s);
    } else {
      inner.position.set(-off[0] * s, -off[1] * s, -off[2] * s);
    }
    inner.scale.setScalar(s);
    inner.rotation.set(
      item.spec.displayRotation[0] * DEG,
      item.spec.displayRotation[1] * DEG,
      item.spec.displayRotation[2] * DEG,
    );
    holder.add(inner);
    holder.name = `display_${item.id}`;
    return holder;
  }

  /** Bütçe raporunu okunabilir tabloya çevirir. */
  budgetTable(): string {
    const rows = this.budget.reports.map(
      (r) => `${r.ok ? '✓' : '✗'} ${r.name.padEnd(22)} ${String(r.triangles).padStart(5)} / ${String(r.budget).padStart(5)}`,
    );
    return rows.join('\n');
  }
}

/** Satır içi MaterialDef'ten geçici THREE materyali (flama gibi tek kullanımlık parçalar). */
function inlineMaterial(def: MaterialDef): THREE.MeshStandardMaterial {
  return new THREE.MeshStandardMaterial({
    color: def.color,
    metalness: def.metalness,
    roughness: def.roughness,
    flatShading: def.flatShading !== false,
    side: def.side ?? THREE.FrontSide,
    emissive: def.emissive ?? 0x000000,
    emissiveIntensity: def.emissiveIntensity ?? 1,
    transparent: def.transparent ?? false,
    opacity: def.opacity ?? 1,
  });
}

function hashId(id: string): number {
  let h = 2166136261;
  for (let i = 0; i < id.length; i++) {
    h ^= id.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

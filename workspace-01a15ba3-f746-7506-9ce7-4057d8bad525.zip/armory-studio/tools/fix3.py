import io
import re

p = 'src/Armory.ts'
s = io.open(p, encoding='utf-8').read()

start = s.index('const BOW = {')
end = s.index('/* ═══════════════════════════════════════════════════════════════════════\n   KALKANLAR')

new = r'''const BOW = {
  half: 0.7,          // kol uzunluğu (kabza merkezinden uç nock'a)
  kMain: 0.42,        // ana gövde eğriliği  θ(y) = k·y²
  recurveFrom: 0.62,  // bu oranından sonra uçlar içe (kiriş yönüne) kıvrılır
  recurveK: 0.5,      // recurve eğrilik şiddeti
  profileHW: 0.022,   // kol profil yarı genişliği (kabzada)
  profileHT: 0.01,    // kol profil yarı kalınlığı
};

/**
 * Birikimli büküm açısı θ(|y|) — negatif değer kolu kiriş yönüne (-X) büker,
 * recurve bölgesinde pozitif terim uçları geriye (yayın içine) kıvırır.
 * Gerçek Kuzait kompozit yay silüeti bu iki terimin toplamından çıkar.
 */
function bowTheta(absY: number): number {
  const L = BOW.half;
  const main = -BOW.kMain * absY * absY;
  const y1 = BOW.recurveFrom * L;
  if (absY <= y1) return main;
  const k = Math.min(1, (absY - y1) / (L - y1));
  const recurve = BOW.recurveK * y1 * (absY - y1) * (1 - k * 0.35);
  return main + recurve;
}

/** Bükülmüş kol üzerindeki bir noktanın konumu ve parça rotasyonu. */
function bowPoint(absY: number, sign: 1 | -1): { pos: THREE.Vector3; rotZdeg: number } {
  const y = absY * sign;
  const theta = bowTheta(absY) * sign;
  return { pos: v3(-y * Math.sin(theta), y * Math.cos(theta), 0), rotZdeg: (-theta / DEG) * sign };
}

/**
 * 8) GELENEKSEL KAVİSLİ YAY (Recurve / Kuzait kompozit yay)
 *    Süpürülmüş kol profili + bendAlongX deformasyonu (gövde kavis + uç
 *    recurve), kemik nock'lar, deri kabza, kiriş ve orta sarımı.
 *    Kollar ±X boyunca uzanır; kiriş x = brace düzleminde, kabza orijinde.
 */
function buildRecurveBow(ctx: BuildCtx): Piece[] {
  const P: Piece[] = [];
  const hero = ctx.lod === 'hero';
  const steps = ctx.res(hero ? 12 : 7);
  const radial = ctx.rad(hero ? 6 : 5);
  const hw = BOW.profileHW;
  const ht = BOW.profileHT;

  // ── kol profili: dış (hedefe bakan) karın, iç (kiriş) sırt ──
  const limbProfile: Vec2Tuple[] = [
    [-hw, ht],
    [hw, ht],
    [hw * 0.72, -ht],
    [-hw * 0.72, -ht],
    [-hw, ht],
  ];

  const buildLimb = (sign: 1 | -1): void => {
    const spine: Vec3Tuple[] = [];
    for (let i = 0; i <= steps; i++) spine.push([(i / steps) * BOW.half, 0, 0]);
    const g = sweep(profile2(limbProfile), spine3(spine), {
      scale: (t) => lerp(1, 0.44, t) * (1 + 0.1 * Math.sin(Math.PI * t)),
      seedNormal: v3(0, 1, 0),
    });
    bendAlongX(g, (x) => bowTheta(Math.abs(x)) * Math.sign(x || sign) * sign);
    P.push({ geometry: g, material: sign === 1 ? 'wood' : 'woodDark' });

    // ── kemik uç nock + kiriş kertiği ──
    const tip = bowPoint(BOW.half, sign);
    const nock = new THREE.CylinderGeometry(0.013, 0.019, 0.08, radial);
    nock.rotateZ(-90 * DEG * sign);
    P.push({ geometry: nock, material: 'bone', position: [tip.pos.x, tip.pos.y, 0], rotation: [0, 0, sign * tip.rotZdeg * DEG] });
    const grooveAt = bowPoint(BOW.half * 0.93, sign);
    const groove = new THREE.TorusGeometry(0.014, 0.0045, 3, radial);
    groove.rotateY(90 * DEG);
    P.push({ geometry: groove, material: 'horn', position: [grooveAt.pos.x, grooveAt.pos.y, 0], rotation: [0, 0, sign * grooveAt.rotZdeg * DEG] });

    // ── tendon/deri sarımlar (bükülmüş konumlarıyla) ──
    if (hero) {
      for (const t of [0.3, 0.52, 0.74]) {
        const at = bowPoint(BOW.half * t, sign);
        const ring = new THREE.TorusGeometry(0.022, 0.005, 3, 7);
        ring.rotateY(90 * DEG);
        P.push({ geometry: ring, material: 'trim', position: [at.pos.x, at.pos.y, 0], rotation: [0, 0, sign * at.rotZdeg * DEG] });
      }
      // boynuz karın kaplaması (kompozit yay)
      const hornStrip = new THREE.BoxGeometry(BOW.half * 0.78, 0.012, hw * 1.5);
      hornStrip.translate(BOW.half * 0.42, ht + 0.004, 0);
      bendAlongX(hornStrip, (x) => bowTheta(Math.abs(x)) * Math.sign(x || sign) * sign);
      P.push({ geometry: hornStrip, material: 'horn' });
    }
  };
  buildLimb(1);
  buildLimb(-1);

  // ── kabza (riser): kalınlaştırılmış merkez, deri sarım, altın bilezikler ──
  const riser = new THREE.CylinderGeometry(0.034, 0.03, 0.18, radial);
  riser.rotateZ(90 * DEG);
  P.push({ geometry: riser, material: 'leatherDark', position: [0, 0, 0] });
  const riserPlate = new THREE.BoxGeometry(0.024, 0.05, 0.12);
  P.push({ geometry: riserPlate, material: 'woodDark', position: [0.026, 0, 0] });
  if (hero) {
    for (const s of [-1, 1]) {
      const ringGeo = new THREE.TorusGeometry(0.033, 0.006, 3, 8);
      ringGeo.rotateY(90 * DEG);
      P.push({ geometry: ringGeo, material: 'gold', position: [s * 0.088, 0, 0] });
    }
    const wrap = new THREE.CylinderGeometry(0.038, 0.038, 0.13, 8);
    wrap.rotateZ(90 * DEG);
    P.push({ geometry: wrap, material: 'leather', position: [-0.004, 0, 0] });
    // ok yatağı çıkıntısı
    const rest = new THREE.BoxGeometry(0.02, 0.014, 0.05);
    P.push({ geometry: rest, material: 'bone', position: [0.03, 0.012, 0] });
  }

  // ── kiriş: bükülmüş nock'lardan kabzanın önüne ──
  const tipUp = bowPoint(BOW.half, 1).pos;
  const tipDown = bowPoint(BOW.half, -1).pos;
  const brace = Math.max(0.08, Math.abs(tipUp.x) * 0.78);
  const string = tubeFromPoints(
    [v3(tipUp.x, tipUp.y, 0), v3(brace * 0.55, tipUp.y * 0.5, 0), v3(brace, 0, 0), v3(brace * 0.55, tipDown.y * 0.5, 0), v3(tipDown.x, tipDown.y, 0)],
    hero ? 0.0055 : 0.0075,
    hero ? 4 : 3,
    1,
  );
  P.push({ geometry: string, material: hero ? 'bone' : 'clothLight' });

  // ── kiriş orta sarımı (serving) ──
  if (hero) {
    const serving = new THREE.CylinderGeometry(0.009, 0.009, 0.11, 5);
    P.push({ geometry: serving, material: 'clothLight', position: [brace, 0, 0] });
    const nockPoint = new THREE.TorusGeometry(0.012, 0.004, 3, 6);
    nockPoint.rotateX(90 * DEG);
    P.push({ geometry: nockPoint, material: 'leatherDark', position: [brace + 0.004, 0, 0] });
  }
  return P;
}

/**
 * 9) TÜYLÜ LOW-POLY OK
 *    Demir bodkin uç + soket, ahşap gövde, 120° aralıklı kırmızı/beyaz tüy,
 *    boynuz kertik (nock). +Y = uçuş yönü.
 */
function buildArrow(ctx: BuildCtx): Piece[] {
  const P: Piece[] = [];
  const hero = ctx.lod === 'hero';
  const radial = ctx.rad(hero ? 6 : 5);

  // ── gövde ──
  P.push(haft(ctx, -0.36, 0.3, 0.0075, 0.0068, 'woodLight', { radial, jitter: 0 }));

  // ── soket ──
  const socket = new THREE.CylinderGeometry(0.0095, 0.008, 0.05, radial);
  socket.translate(0, 0.318, 0);
  P.push({ geometry: socket, material: 'iron' });

  // ── bodkin uç: dört yüzlü zırh deliciği ──
  const point = sweptBlade(ctx, {
    profile: [
      [-0.0085, 0],
      [0.0085, 0],
      [0, 0.011],
      [-0.0085, 0],
    ],
    spine: [[0, 0.33, 0], [0, 0.46, 0]],
    steps: ctx.res(hero ? 7 : 4),
    scale: (t) => (t > 0.88 ? 1 - smooth((t - 0.88) / 0.12) : 0.6 + 0.4 * Math.sin(Math.PI * Math.min(1, t * 1.2 + 0.12))),
    seedNormal: [1, 0, 0],
  });
  P.push({ geometry: point, material: 'steelBright' });

  // ── kertik (nock) ──
  const nock = new THREE.CylinderGeometry(0.0095, 0.0085, 0.028, radial);
  nock.translate(0, -0.373, 0);
  P.push({ geometry: nock, material: 'horn' });
  if (hero) {
    const slot = new THREE.BoxGeometry(0.004, 0.026, 0.022);
    P.push({ geometry: slot, material: 'dark', position: [0, -0.38, 0] });
  }

  // ── üç tüy: 120° aralıklı, kırmızı / beyaz / kırmızı ──
  const featherShape = shapeFrom([
    [0.011, 0.0],
    [0.028, 0.034],
    [0.031, 0.076],
    [0.02, 0.108],
    [0.006, 0.118],
    [0.001, 0.062],
    [0.004, 0.02],
  ]);
  for (let i = 0; i < 3; i++) {
    const geo = new THREE.ExtrudeGeometry(featherShape, extrudeOpts(hero ? 0.005 : 0.006, hero ? 0.0018 : 0.0012, 1));
    geo.translate(0, 0, -(hero ? 0.005 : 0.006) / 2);
    const mat = i === 1 ? 'clothLight' : 'cloth';
    const ang = (i * 120) * DEG;
    const off = 0.0075;
    P.push({
      geometry: geo,
      material: mat,
      position: [Math.cos(ang) * off, -0.335, Math.sin(ang) * off],
      rotation: [0, -ang, i === 1 ? -5 * DEG : 9 * DEG],
    });
    if (hero) {
      // tüy mili (rachis)
      const rachis = new THREE.BoxGeometry(0.003, 0.116, 0.003);
      P.push({
        geometry: rachis,
        material: 'bone',
        position: [Math.cos(ang) * (off + 0.004), -0.283, Math.sin(ang) * (off + 0.004)],
        rotation: [0, -ang, 0],
      });
    }
  }

  // ── gövde sarım ipleri ──
  if (hero) {
    for (const y of [-0.243, -0.228]) {
      const ring = new THREE.TorusGeometry(0.0088, 0.0018, 3, 6);
      ring.rotateX(90 * DEG);
      P.push({ geometry: ring, material: 'clothLight', position: [0, y, 0] });
    }
  }
  return P;
}

'''

s = s[:start] + new + s[end:]

# bendAlongX yardımcı fonksiyonunu Core'dan import edilen bendGeometry'nin yanına ekle
anchor = "const lerp = (a: number, b: number, t: number): number => a + (b - a) * t;"
helper = anchor + '''

/**
 * X ekseni boyunca bükme deformasyonu (bendGeometry'nin 90° döndürülmüş hali):
 * nokta (x,y,z) → (x·cosθ + y·sinθ, −x·sinθ + y·cosθ, z), θ = curvature(x).
 * Yay gövdesi ve kavisli namlular için kullanılır.
 */
function bendAlongX(g: THREE.BufferGeometry, curvature: (x: number) => number): THREE.BufferGeometry {
  const p = g.attributes.position as THREE.BufferAttribute;
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i);
    const y = p.getY(i);
    const a = curvature(x);
    const c = Math.cos(a);
    const s = Math.sin(a);
    p.setXYZ(i, x * c + y * s, -x * s + y * c, p.getZ(i));
  }
  p.needsUpdate = true;
  g.computeVertexNormals();
  return g;
}'''
assert anchor in s
s = s.replace(anchor, helper, 1)

io.open(p, 'w', encoding='utf-8').write(s)
print('ok, lines:', len(s.splitlines()))

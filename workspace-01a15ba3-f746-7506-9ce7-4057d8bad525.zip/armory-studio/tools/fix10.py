#!/usr/bin/env python3
"""Bölüm 2: 8 yeni Bannerlord tarzı ekipman (Armory.ts)."""
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
p = ROOT / 'src' / 'Armory.ts'
src = p.read_text(encoding='utf-8')

def rep(old: str, new: str, count: int = 1):
    global src
    if src.count(old) < count:
        print(f'EKSİK: {old[:70]!r}')
        sys.exit(1)
    src = src.replace(old, new, count)

# 1) WeaponClass + id union
rep(
    "export type WeaponClass = 'sword' | 'axe' | 'polearm' | 'bow' | 'arrow' | 'shield' | 'armor';",
    "export type WeaponClass = 'sword' | 'axe' | 'mace' | 'polearm' | 'bow' | 'arrow' | 'shield' | 'armor';",
)
rep(
    "  | 'greatHelm' | 'hornedHelm' | 'cuirass';",
    "  | 'greatHelm' | 'hornedHelm' | 'cuirass'\n"
    "  | 'flangedMace' | 'warHammer' | 'morningstar'\n"
    "  | 'billhook'\n"
    "  | 'paviseShield' | 'cavalryRound'\n"
    "  | 'nasalHelm' | 'kettleHat';",
)

# 2) budgetFor: yeni miğferler zırh bütçesinden saysın
rep(
    "  const isWeapon = !['greatHelm', 'hornedHelm', 'cuirass'].includes(id);",
    "  const isWeapon = !['greatHelm', 'hornedHelm', 'cuirass', 'nasalHelm', 'kettleHat'].includes(id);",
)

# 3) Yeni üreticiler (BUILDERS'tan hemen önce)
BUILDERS_ANCHOR = "const BUILDERS: Record<ArmoryItemId, (ctx: BuildCtx) => Piece[]> = {"
NEW_BUILDERS = '''/* ═══════════════════════════════════════════════════════════════════════
   TOPUZLAR & ÇEKİÇLER (Bölüm 2 ek paketi)
   ═══════════════════════════════════════════════════════════════════════ */

/** Yıldız kesit (topuz başı): dış/iç yarıçap arasında sivri dilimler. */
function flangeStar(points: number, rInner: number, rOuter: number): Vec2Tuple[] {
  const out: Vec2Tuple[] = [];
  for (let i = 0; i < points * 2; i++) {
    const a = (i / (points * 2)) * TAU;
    const r = i % 2 === 0 ? rOuter : rInner;
    out.push([Math.cos(a) * r, Math.sin(a) * r]);
  }
  return out;
}

/**
 * 15) DİKENLİ TOPUZ (Flanged Mace · Aseray)
 *    Yıldız kesitli çelik baş, dilimli sap, bronz bilezik, kubbe dip.
 */
function buildFlangedMace(ctx: BuildCtx): Piece[] {
  const P: Piece[] = [];
  const hero = ctx.lod === 'hero';
  const starPts = hero ? 10 : ctx.lod === 'battle' ? 8 : 6;

  // ── sap + deri kabza ──
  P.push(haft(ctx, 0, 0.52, 0.021, 0.017, 'wood', { radial: ctx.rad(), jitter: ctx.jitter, facet: hero ? 0.01 : 0 }));
  P.push(haft(ctx, 0.05, 0.24, 0.024, 0.023, 'leatherDark', { radial: ctx.rad(6) }));
  if (hero) P.push(...bindings(ctx, 0.07, 0.22, 0.026, 5, 'leatherDark'));

  // ── bilezik + baş altı yaka ──
  const collar = new THREE.CylinderGeometry(0.032, 0.026, 0.035, ctx.rad(6));
  collar.translate(0, 0.4, 0);
  P.push({ geometry: collar, material: 'bronze' });

  // ── yıldız kesitli baş (tek extrude = ucuz ve fasetli) ──
  const head = extrudedBlade(
    flangeStar(starPts, 0.045, hero ? 0.085 : 0.078),
    hero ? 0.15 : 0.13,
    hero ? 0.008 : 0.004,
    'steelBright',
    { rotation: [90 * DEG, 0, 0], position: [0, hero ? 0.55 : 0.54, 0] },
  );
  P.push(head);

  // ── merkez göbek + tepe dikeni ──
  const core = new THREE.CylinderGeometry(0.04, 0.044, 0.15, ctx.rad(6));
  core.translate(0, 0.475, 0);
  P.push({ geometry: core, material: 'steel' });
  const spike = new THREE.ConeGeometry(0.02, 0.06, 4);
  P.push({ geometry: spike, material: 'steelBright', position: [0, 0.58, 0] });

  // ── kubbe dip topuzu ──
  P.push(ball(0.026, 'bronze', hero ? 1 : 0, [0, 0.015, 0]));
  if (hero) P.push(...rivets(ctx, 6, 0.045, 0.008, 0.415, 'bronze'));
  return P;
}

/**
 * 16) ŞÖVALYE SAVAŞ ÇEKİCİ (War Hammer · Vlandiya)
 *    Dört yüzlü vuruş piramidi, arkada zırh delen gaga, çelik langetler.
 */
function buildWarHammer(ctx: BuildCtx): Piece[] {
  const P: Piece[] = [];
  const hero = ctx.lod === 'hero';

  P.push(haft(ctx, 0, 0.6, 0.023, 0.018, 'wood', { radial: ctx.rad(), jitter: ctx.jitter, facet: hero ? 0.01 : 0 }));
  P.push(haft(ctx, 0.06, 0.26, 0.026, 0.025, 'leatherDark', { radial: ctx.rad(6) }));

  // ── baş gövdesi + vuruş yüzü piramidi ──
  const head = new THREE.BoxGeometry(0.13, 0.085, 0.08);
  P.push({ geometry: head, material: 'steelDark', position: [0.02, 0.52, 0] });
  const face = new THREE.ConeGeometry(0.05, 0.06, 4);
  face.rotateZ(-90 * DEG);
  P.push({ geometry: face, material: 'steelBright', position: [0.115, 0.52, 0] });

  // ── arka gaga (zırh delici) ──
  const beak = new THREE.ConeGeometry(0.028, hero ? 0.14 : 0.11, 4);
  beak.rotateZ(90 * DEG);
  beak.rotateY(12 * DEG);
  P.push({ geometry: beak, material: 'steel', position: [-0.09, 0.525, 0] });

  // ── göz (socket) + tepe çıkıntısı ──
  const socket = new THREE.CylinderGeometry(0.034, 0.03, 0.12, ctx.rad(6));
  socket.translate(0, 0.52, 0);
  P.push({ geometry: socket, material: 'steelDark' });
  const crown = new THREE.ConeGeometry(0.022, 0.05, 4);
  P.push({ geometry: crown, material: 'steel', position: [0, 0.6, 0] });

  if (hero) {
    for (const s of [-1, 1]) {
      const langet = new THREE.BoxGeometry(0.008, 0.18, 0.022);
      P.push({ geometry: langet, material: 'iron', position: [s * 0.025, 0.4, 0] });
    }
    P.push(ball(0.024, 'steel', 0, [0, 0.012, 0]));
  }
  return P;
}

/**
 * 17) ZİNCİRLİ MORNINGSTAR (Flail · Sturgia)
 *    Dönme halkası, üç halkalı zincir, dikenli demir top.
 */
function buildMorningstar(ctx: BuildCtx): Piece[] {
  const P: Piece[] = [];
  const hero = ctx.lod === 'hero';
  const battle = ctx.lod !== 'crowd';

  // ── sap ──
  P.push(haft(ctx, 0, 0.42, 0.02, 0.017, 'wood', { radial: ctx.rad(), jitter: ctx.jitter }));
  P.push(haft(ctx, 0.05, 0.2, 0.023, 0.022, 'leatherDark', { radial: ctx.rad(6) }));

  // ── fırdöndü halkası + zincir baklaları ──
  const swivel = new THREE.TorusGeometry(0.02, 0.006, 3, ctx.rad(6));
  P.push({ geometry: swivel, material: 'iron', position: [0, 0.44, 0] });
  const links = hero ? 3 : battle ? 2 : 1;
  for (let i = 0; i < links; i++) {
    const link = new THREE.BoxGeometry(0.012, 0.05, 0.02);
    P.push({
      geometry: link,
      material: 'iron',
      position: [0.012 * (i % 2 === 0 ? 1 : -1), 0.48 + i * 0.042, 0],
      rotation: [i % 2 === 0 ? 0 : 90 * DEG, 0, 14 * DEG],
    });
  }

  // ── dikenli top ──
  const headY = 0.48 + links * 0.042 + 0.06;
  P.push(ball(0.055, 'iron', 0, [0.02, headY, 0], [1, 1.12, 1]));
  // tepe + dip dikeni
  const topSpike = new THREE.ConeGeometry(0.016, 0.06, 4);
  P.push({ geometry: topSpike, material: 'steel', position: [0.02, headY + 0.06, 0] });
  const botSpike = new THREE.ConeGeometry(0.016, 0.06, 4);
  botSpike.rotateX(180 * DEG);
  P.push({ geometry: botSpike, material: 'steel', position: [0.02, headY - 0.06, 0] });
  // yatay halka dikenleri
  const ring = hero ? 6 : battle ? 5 : 4;
  for (let i = 0; i < ring; i++) {
    const a = (i / ring) * TAU;
    const spike = new THREE.ConeGeometry(0.016, 0.06, 4);
    spike.rotateZ(-90 * DEG);
    spike.rotateY(-a);
    P.push({
      geometry: spike,
      material: 'steel',
      position: [0.02 + Math.cos(a) * 0.05, headY, Math.sin(a) * 0.05],
    });
  }
  P.push(ball(0.02, 'steelDark', 0, [0, 0.01, 0]));
  return P;
}

/**
 * 18) VLANDYA BILLHOOK'U (Bill / Glaive)
 *    Uzun sap, içe kavisli kanca ağzı, arkada delici sırt dikeni.
 */
function buildBillhook(ctx: BuildCtx): Piece[] {
  const P: Piece[] = [];
  const hero = ctx.lod === 'hero';

  P.push(...poleShaft(ctx, 0, 1.72, 0.021, 'wood'));
  if (hero) P.push(...bindings(ctx, 0.3, 0.52, 0.024, 6, 'leatherDark'));

  // ── kanca ağzı: içe dönen fasetli kontur ──
  const hook: Vec2Tuple[] = [
    [0.0, 0.0],
    [0.06, 0.07],
    [0.11, 0.18],
    [0.115, 0.3],
    [0.06, 0.4],
    [-0.03, 0.44],
    [-0.075, 0.38],
    [-0.01, 0.32],
    [0.035, 0.24],
    [0.03, 0.12],
    [-0.035, 0.04],
  ];
  P.push(
    extrudedBlade(hook, hero ? 0.026 : 0.02, hero ? 0.008 : 0.004, 'steelBright', {
      rotation: [0, 90 * DEG, 0],
      position: [-0.013, 1.66, 0],
    }),
  );

  // ── sırt dikeni + soket ──
  const spike = new THREE.ConeGeometry(0.02, hero ? 0.16 : 0.12, 4);
  spike.rotateZ(90 * DEG);
  P.push({ geometry: spike, material: 'steel', position: [-0.1, 1.74, 0] });
  const socket = new THREE.CylinderGeometry(0.03, 0.026, 0.16, ctx.rad(6));
  socket.translate(0, 1.66, 0);
  P.push({ geometry: socket, material: 'steelDark' });
  if (hero) {
    const butt = new THREE.CylinderGeometry(0.024, 0.02, 0.06, ctx.rad(6));
    butt.translate(0, 0.03, 0);
    P.push({ geometry: butt, material: 'iron' });
  }
  return P;
}

/* ═══════════════════════════════════════════════════════════════════════
   KALKANLAR (Bölüm 2 ek paketi)
   ═══════════════════════════════════════════════════════════════════════ */

/** Pavise konturu: geniş omuzlu, alt köşeleri pahlı dikdörtgen. */
function paviseOutline(segments: number): THREE.Vector2[] {
  const raw: Vec2Tuple[] = [
    [-0.26, 0.52],
    [0.26, 0.52],
    [0.31, 0.3],
    [0.31, -0.3],
    [0.2, -0.56],
    [-0.2, -0.56],
    [-0.31, -0.3],
    [-0.31, 0.3],
  ];
  const n = Math.max(4, Math.min(raw.length, segments));
  const step = raw.length / n;
  const pts: THREE.Vector2[] = [];
  for (let i = 0; i < n; i++) {
    const f = i * step;
    const i0 = Math.floor(f) % raw.length;
    const i1 = (i0 + 1) % raw.length;
    const k = f - Math.floor(f);
    pts.push(v2(lerp(raw[i0][0], raw[i1][0], k), lerp(raw[i0][1], raw[i1][1], k)));
  }
  return pts;
}

/**
 * 19) İMPARATORLUK PAVİSE KALKANI
 *    Boylu boyunca omurga, kavisli kapalı kabuk, haç boyalı ön yüz.
 */
function buildPaviseShield(ctx: BuildCtx): Piece[] {
  const P: Piece[] = [];
  const hero = ctx.lod === 'hero';
  const outline = paviseOutline(hero ? 8 : ctx.lod === 'battle' ? 8 : 6);

  // ── kapalı kavisli kabuk (ön + arka tek parça) ──
  const shell = domeShell(
    outline,
    hero || ctx.lod === 'battle'
      ? [
          [0, 0.085],
          [0.45, 0.078],
          [0.78, 0.052],
          [1, -0.008],
        ]
      : [
          [0, 0.08],
          [0.6, 0.06],
          [1, -0.008],
        ],
    { cap: true, jitter: ctx.jitter, facet: hero ? 0.008 : 0 },
  );
  P.push({ geometry: shell, material: 'wood' });

  // ── dikey omurga (çelik sırt) ──
  const spine = new THREE.BoxGeometry(0.05, 1.02, 0.05);
  P.push({ geometry: spine, material: 'steelDark', position: [0, 0, 0.075] });

  // ── fraksiyon haçı (boyalı şeritler) ──
  if (ctx.lod !== 'crowd') {
    const vbar = new THREE.BoxGeometry(0.1, 0.72, 0.012);
    P.push({ geometry: vbar, material: 'cloth', position: [0, 0.02, 0.062] });
    const hbar = new THREE.BoxGeometry(0.42, 0.1, 0.012);
    P.push({ geometry: hbar, material: 'cloth', position: [0, 0.16, 0.062] });
  }

  if (hero) {
    const rim = shellSweepFixed(outline, [[-0.014, 0.02], [0.014, 0.02], [0.014, -0.014], [-0.014, -0.014]]);
    P.push({ geometry: rim, material: 'iron' });
    P.push(...rivets(ctx, 8, 0.27, 0.01, 0.4, 'iron', Math.PI));
    const strap = new THREE.BoxGeometry(0.06, 0.5, 0.014);
    P.push({ geometry: strap, material: 'leather', position: [0, 0, -0.05] });
  }
  return P;
}

/**
 * 20) KUZAİT SÜVARİ ROUND KALKANI
 *    Küçük, çelik, derin bombeli; ok yağmuruna karşı kubbe + sivri göbek.
 */
function buildCavalryRound(ctx: BuildCtx): Piece[] {
  const P: Piece[] = [];
  const hero = ctx.lod === 'hero';
  const R = 0.26;
  const outline = shieldOutline('round', hero ? 10 : ctx.lod === 'battle' ? 8 : 6, R / 0.36);

  const shell = domeShell(
    outline,
    [
      [0, 0.09],
      [0.5, 0.082],
      [0.85, 0.045],
      [1, -0.006],
    ],
    { cap: true, jitter: ctx.jitter, facet: hero ? 0.006 : 0 },
  );
  P.push({ geometry: shell, material: 'steel' });

  // ── göbek + sivri tepe ──
  const boss = new THREE.ConeGeometry(0.08, hero ? 0.1 : 0.085, ctx.rad(6));
  boss.rotateX(90 * DEG);
  P.push({ geometry: boss, material: 'steelBright', position: [0, 0, 0.1] });
  if (hero) {
    const tip = new THREE.ConeGeometry(0.014, 0.05, 4);
    tip.rotateX(90 * DEG);
    P.push({ geometry: tip, material: 'steelBright', position: [0, 0, 0.17] });
    P.push(...rivets(ctx, 8, R - 0.03, 0.009, 0.03, 'bronze'));
  }

  // ── mine bandı (fraksiyon emayesi) + kayış ──
  if (ctx.lod !== 'crowd') {
    const band = new THREE.TorusGeometry(R * 0.66, 0.02, 3, ctx.rad(8));
    P.push({ geometry: band, material: 'cloth', position: [0, 0, 0.055] });
  }
  const strap = new THREE.BoxGeometry(0.045, 0.34, 0.012);
  P.push({ geometry: strap, material: 'leatherDark', position: [0, 0, -0.035] });
  return P;
}

/* ═══════════════════════════════════════════════════════════════════════
   MİĞFERLER (Bölüm 2 ek paketi)
   ═══════════════════════════════════════════════════════════════════════ */

/**
 * 21) NASAL MİĞFER (İmparatorluk lejyon veterani)
 *    Konik tas, kaş bandı, burun koruyan nasal çubuk, ense siperi.
 */
function buildNasalHelm(ctx: BuildCtx): Piece[] {
  const P: Piece[] = [];
  const hero = ctx.lod === 'hero';
  const rad = ctx.rad(8);

  // ── konik tas ──
  const skull = new THREE.CylinderGeometry(0.035, 0.155, 0.26, rad, 2);
  skull.translate(0, 0.13, 0);
  if (ctx.jitter) jitterGeometry(skull, ctx.jitter, 91);
  P.push({ geometry: skull, material: 'steel' });

  // ── kaş/alın bandı ──
  const brow = new THREE.CylinderGeometry(0.158, 0.162, 0.05, rad, 1, true);
  brow.translate(0, 0.03, 0);
  P.push({ geometry: brow, material: 'steelDark' });

  // ── nasal (burun) çubuğu ──
  const nasal = new THREE.BoxGeometry(0.022, 0.15, 0.02);
  P.push({ geometry: nasal, material: 'steelBright', position: [0, 0.02, 0.155] });

  // ── ense siperi (3 dilim) ──
  if (ctx.lod !== 'crowd') {
    for (const [x, r] of [[-0.09, 24], [0, 0], [0.09, -24]] as [number, number][]) {
      const flap = new THREE.BoxGeometry(0.09, 0.12, 0.014);
      P.push({ geometry: flap, material: 'steelDark', position: [x, -0.02, -0.13], rotation: [12 * DEG, r * DEG, 0] });
    }
  }

  if (hero) {
    P.push(...rivets(ctx, 8, 0.155, 0.009, 0.055, 'bronze'));
    const crest = new THREE.BoxGeometry(0.014, 0.05, 0.2);
    P.push({ geometry: crest, material: 'bronze', position: [0, 0.26, -0.02] });
  }
  return P;
}

/**
 * 22) KETTLE HAT (Sturgia piyadesi geniş kenarlık)
 *    Geniş konik kenar, alçak tas, tepe kabartması; oklara karşı şemsiye.
 */
function buildKettleHat(ctx: BuildCtx): Piece[] {
  const P: Piece[] = [];
  const hero = ctx.lod === 'hero';
  const rad = ctx.rad(8);

  // ── tas ──
  const skull = new THREE.CylinderGeometry(0.06, 0.15, 0.17, rad, 1);
  skull.translate(0, 0.085, 0);
  if (ctx.jitter) jitterGeometry(skull, ctx.jitter, 97);
  P.push({ geometry: skull, material: 'steel' });

  // ── geniş kenar (açık koni = 16 üçgen) ──
  const brim = new THREE.CylinderGeometry(0.15, 0.27, 0.07, rad, 1, true);
  brim.translate(0, 0.015, 0);
  P.push({ geometry: brim, material: 'steelDark' });

  // ── tepe kabartması + bant ──
  const knob = new THREE.ConeGeometry(0.028, 0.05, 4);
  P.push({ geometry: knob, material: 'steelBright', position: [0, 0.19, 0] });
  if (ctx.lod !== 'crowd') {
    const band = new THREE.CylinderGeometry(0.152, 0.152, 0.03, rad, 1, true);
    band.translate(0, 0.045, 0);
    P.push({ geometry: band, material: 'steelDark' });
  }
  if (hero) {
    P.push(...rivets(ctx, 8, 0.15, 0.008, 0.05, 'iron'));
    // yan havalandırma delikleri hissi: iki alçak kutu
    for (const s of [-1, 1]) {
      const vent = new THREE.BoxGeometry(0.05, 0.016, 0.012);
      P.push({ geometry: vent, material: 'iron', position: [s * 0.11, 0.09, 0.09], rotation: [0, s * -32 * DEG, 0] });
    }
  }
  return P;
}

'''
rep(BUILDERS_ANCHOR, NEW_BUILDERS + BUILDERS_ANCHOR)

# 4) BUILDERS kayıtları
rep(
    "  cuirass: buildCuirass,\n};",
    "  cuirass: buildCuirass,\n"
    "  flangedMace: buildFlangedMace,\n"
    "  warHammer: buildWarHammer,\n"
    "  morningstar: buildMorningstar,\n"
    "  billhook: buildBillhook,\n"
    "  paviseShield: buildPaviseShield,\n"
    "  cavalryRound: buildCavalryRound,\n"
    "  nasalHelm: buildNasalHelm,\n"
    "  kettleHat: buildKettleHat,\n"
    "};",
)

p.write_text(src, encoding='utf-8')
print('Armory.ts: 8 yeni üretici + tip + bütçe güncellendi.')


/* ═══════════════════════════════════════════════════════════════════════
   ZIRH VE MİĞFERLER
   ═══════════════════════════════════════════════════════════════════════ */

/** Miğfer tası profili (LatheGeometry: x = yarıçap, y = yükseklik). */
function helmProfile(kind: 'great' | 'spangen', segmentsHint: number): THREE.Vector2[] {
  if (kind === 'great') {
    return profile2([
      [0.152, -0.21],
      [0.145, -0.175],
      [0.143, -0.1],
      [0.146, -0.032],
      [0.152, 0.012],
      [0.156, 0.06],
      [0.146, 0.12],
      [0.112, 0.166],
      [0.052, 0.192],
      [0.0, 0.198],
    ]);
  }
  return profile2([
    [0.146, -0.14],
    [0.15, -0.08],
    [0.152, -0.02],
    [0.148, 0.045],
    [0.128, 0.104],
    [0.084, 0.154],
    [0.034, 0.182],
    [0.0, 0.188],
  ]);
}

/**
 * 12) KAPALI ŞÖVALYE MİĞFERİ (Great Helm)
 *    LatheGeometry tas + gerçek göz yarığı (üçgen silme + delik kapama),
 *    çift cidar (dış/iç kabuk) ile kalınlık, burun koruyucu, altın haç,
 *    nefes delikleri, perçinler ve alt bant.
 */
function buildGreatHelm(ctx: BuildCtx): Piece[] {
  const P: Piece[] = [];
  const hero = ctx.lod === 'hero';
  const seg = hero ? 10 : 6;
  const prof = helmProfile('great', seg);

  // ── dış kabuk ──
  const outer = new THREE.LatheGeometry(prof, seg);
  weldVertices(outer, 1e-4);
  const carved = carveEyeSlit(outer, hero ? 52 : 62, -0.062, 0.028);
  P.push({ geometry: carved, material: 'steel' });

  // ── iç kabuk (kalınlık + yarıktan bakınca karanlık iç hacim) ──
  if (hero) {
    const innerProf = prof.map((p) => v2(Math.max(0, p.x * 0.9), p.y * 0.985 - 0.004));
    const inner = new THREE.LatheGeometry(innerProf, seg);
    weldVertices(inner, 1e-4);
    flipWinding(inner);
    P.push({ geometry: inner, material: 'dark' });
  }

  // ── alt bant (rolled rim) ──
  const rim = new THREE.TorusGeometry(0.152, hero ? 0.012 : 0.014, 3, seg);
  rim.rotateX(90 * DEG);
  P.push({ geometry: rim, material: 'steelDark', position: [0, -0.208, 0] });

  // ── kaş bandı (yarığın üst sınırı) ──
  const browProf = profile2([[0.155, -0.012], [0.166, -0.006], [0.166, 0.012], [0.155, 0.018]]);
  const brow = new THREE.LatheGeometry(browProf, seg);
  P.push({ geometry: brow, material: 'steelDark', position: [0, 0.032, 0] });

  // ── burun koruyucu (nasal) ──
  const nasal = new THREE.BoxGeometry(hero ? 0.034 : 0.038, 0.13, hero ? 0.026 : 0.03);
  P.push({ geometry: nasal, material: 'steelDark', position: [0, -0.02, 0.152] });
  if (hero) {
    const nasalTip = new THREE.BoxGeometry(0.03, 0.03, 0.024);
    P.push({ geometry: nasalTip, material: 'steelDark', position: [0, -0.086, 0.15] });
  }

  // ── altın haç (alın) ──
  const crossV = new THREE.BoxGeometry(0.026, 0.125, 0.012);
  const crossH = new THREE.BoxGeometry(0.086, 0.026, 0.012);
  P.push({ geometry: crossV, material: 'gold', position: [0, 0.108, 0.141] });
  P.push({ geometry: crossH, material: 'gold', position: [0, 0.108, 0.141] });
  if (hero) {
    const gemGeo = new THREE.OctahedronGeometry(0.014, 0);
    P.push({ geometry: gemGeo, material: 'gem', position: [0, 0.108, 0.152] });
  }

  // ── nefes delikleri (her iki yanakta, artı düzeninde) ──
  const holeCount = hero ? 5 : 3;
  for (const side of [-1, 1]) {
    for (let i = 0; i < holeCount; i++) {
      const a = side * (26 + (i % 2) * 13) * DEG;
      const y = -0.1 + Math.floor(i / 2) * 0.036;
      const r = 0.148 - Math.abs(y) * 0.02;
      const hole = new THREE.CylinderGeometry(0.0075, 0.0075, 0.03, hero ? 5 : 4);
      hole.rotateX(90 * DEG);
      P.push({
        geometry: hole,
        material: 'dark',
        position: [Math.sin(a) * r, y, Math.cos(a) * r],
        rotation: [0, a, 0],
      });
    }
  }

  // ── perçinler (kaş bandı boyunca) ──
  if (hero) {
    for (let i = 0; i < seg; i++) {
      const a = (i / seg) * TAU + Math.PI / seg;
      if (Math.abs(((a + Math.PI) % TAU) - Math.PI) < 1.1) continue; // ön tarafta yarığa denk gelmesin
      const g = new THREE.OctahedronGeometry(0.009, 0);
      g.scale(1, 0.7, 1);
      P.push({ geometry: g, material: 'iron', position: [Math.sin(a) * 0.16, 0.036, Math.cos(a) * 0.16] });
    }
  }

  // ── tepe süsü (kısa diken) ──
  const finial = new THREE.ConeGeometry(0.018, 0.05, hero ? 5 : 4);
  P.push({ geometry: finial, material: 'gold', position: [0, 0.22, 0] });
  return P;
}

/** LatheGeometry'den göz yarığı üçgenlerini söker ve delikleri kapatır. */
function carveEyeSlit(g: THREE.BufferGeometry, halfAngleDeg: number, yBottom: number, yTop: number): THREE.BufferGeometry {
  const src = g.index ? g.toNonIndexed() : g.clone();
  const p = src.attributes.position as THREE.BufferAttribute;
  const keep: number[] = [];
  const c = new THREE.Vector3();
  for (let t = 0; t < p.count; t += 3) {
    c.set(0, 0, 0);
    for (let k = 0; k < 3; k++) {
      c.x += p.getX(t + k);
      c.y += p.getY(t + k);
      c.z += p.getZ(t + k);
    }
    c.divideScalar(3);
    const ang = Math.atan2(c.x, c.z); // 0 = ön (+Z)
    const inFront = Math.abs(ang) < halfAngleDeg * DEG;
    const inSlit = c.y > yBottom && c.y < yTop;
    if (inFront && inSlit) continue;
    for (let k = 0; k < 3; k++) keep.push(p.getX(t + k), p.getY(t + k), p.getZ(t + k));
  }
  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.Float32BufferAttribute(keep, 3));
  out.computeVertexNormals();
  return capHoles(out);
}

/**
 * 13) KUZAİT / NORD BOYNUZLU MİĞFER
 *    Konik spangen tas, süpürülmüş boynuzlar (gerçek kavis + kemik fasetleri),
 *    burun koruyucu, fraksiyon sorgucu, deri ense koruyucu.
 */
function buildHornedHelm(ctx: BuildCtx): Piece[] {
  const P: Piece[] = [];
  const hero = ctx.lod === 'hero';
  const seg = hero ? 8 : 6;
  const prof = helmProfile('spangen', seg);

  // ── konik tas ──
  const skull = new THREE.LatheGeometry(prof, seg);
  weldVertices(skull, 1e-4);
  jitterGeometry(skull, ctx.jitter * 0.6, 77);
  P.push({ geometry: skull, material: 'steel' });

  // ── kaş bandı + burun koruyucu ──
  const browProf = profile2([[0.152, -0.014], [0.166, -0.004], [0.166, 0.016], [0.152, 0.02]]);
  const brow = new THREE.LatheGeometry(browProf, seg);
  P.push({ geometry: brow, material: 'steelDark', position: [0, -0.032, 0] });
  const nasal = new THREE.BoxGeometry(hero ? 0.032 : 0.036, 0.14, hero ? 0.022 : 0.026);
  P.push({ geometry: nasal, material: 'steelDark', position: [0, -0.09, 0.15] });
  const nasalTip = new THREE.ConeGeometry(0.018, 0.04, 4);
  nasalTip.rotateX(180 * DEG);
  P.push({ geometry: nasalTip, material: 'steelDark', position: [0, -0.176, 0.15] });

  // ── spangen şeritleri (tasın üzerindeki çelik bantlar) ──
  if (hero) {
    for (const a of [0, 90, 180, 270]) {
      const band = new THREE.BoxGeometry(0.018, 0.006, 0.34);
      band.rotateY(a * DEG);
      const g = band.clone();
      g.rotateX(0);
      P.push({ geometry: g, material: 'steelBright', position: [0, 0.06, 0], rotation: [78 * DEG, a * DEG, 0] });
    }
  }

  // ── boynuzlar: süpürülmüş kavis + kemik halkaları ──
  const hornSteps = ctx.res(hero ? 9 : 6);
  for (const side of [-1, 1]) {
    const spinePts: Vec3Tuple[] = [];
    for (let i = 0; i <= hornSteps; i++) {
      const t = i / hornSteps;
      const a = t * 118 * DEG;
      spinePts.push([
        side * (0.145 + Math.sin(a) * 0.185),
        0.045 + Math.cos(a) * -0.055 + t * 0.115,
        -0.012 + t * 0.05,
      ]);
    }
    const horn = sweptBlade(ctx, {
      profile: [
        [-0.03, 0],
        [0, -0.034],
        [0.03, 0],
        [0.012, 0.026],
        [-0.012, 0.026],
        [-0.03, 0],
      ],
      spine: spinePts,
      steps: hornSteps + 1,
      scale: (t) => Math.pow(1 - t, 0.72) * 0.96 + 0.04,
      seedNormal: [0, 1, 0],
    });
    P.push({ geometry: horn, material: 'bone' });

    if (hero) {
      // boynuz kaidesi (çelik yüksük) + halka fasetleri
      const ferrule = new THREE.CylinderGeometry(0.038, 0.03, 0.05, 6);
      ferrule.rotateZ(side * 90 * DEG);
      P.push({ geometry: ferrule, material: 'steelDark', position: [side * 0.15, 0.045, -0.012] });
      for (const t of [0.34, 0.6]) {
        const at = spinePts[Math.round(t * hornSteps)];
        const ring = new THREE.TorusGeometry(0.024 * (1 - t * 0.6), 0.005, 3, 5);
        ring.rotateY(90 * DEG);
        P.push({ geometry: ring, material: 'horn', position: at });
      }
    }
  }

  // ── fraksiyon sorgucu (tepe tüyleri) ──
  const plumeCount = hero ? 7 : 4;
  for (let i = 0; i < plumeCount; i++) {
    const t = plumeCount > 1 ? i / (plumeCount - 1) : 0.5;
    const feather = sweptBlade(ctx, {
      profile: [
        [-0.026, 0],
        [0.026, 0],
        [0.018, 0.006],
        [-0.018, 0.006],
        [-0.026, 0],
      ],
      spine: [
        [0, 0.18, -0.02 + (t - 0.5) * 0.05],
        [0, 0.27, -0.06 + (t - 0.5) * 0.08],
        [0, 0.33, -0.14 + (t - 0.5) * 0.1],
      ],
      steps: ctx.res(hero ? 6 : 4),
      scale: (u) => Math.sin(Math.PI * Math.min(1, u * 1.02)) ** 0.5,
      seedNormal: [1, 0, 0],
      twist: () => (t - 0.5) * 0.9,
    });
    P.push({ geometry: feather, material: i % 3 === 1 ? 'clothLight' : 'plume' });
  }

  // ── deri ense/yanak koruyucu ──
  const guardProf = profile2([[0.15, 0.0], [0.168, -0.02], [0.16, -0.075], [0.132, -0.09]]);
  const guard = new THREE.LatheGeometry(guardProf, seg, 105 * DEG, 150 * DEG);
  P.push({ geometry: guard, material: 'leatherDark', position: [0, -0.13, 0] });
  if (hero) {
    const chinStrap = tubeFromPoints([v3(-0.13, -0.14, 0.06), v3(-0.05, -0.2, 0.12), v3(0.05, -0.2, 0.12), v3(0.13, -0.14, 0.06)], 0.008, 4, 2);
    P.push({ geometry: chinStrap, material: 'leather' });
  }

  // ── tepe diken ──
  const spike = new THREE.ConeGeometry(0.02, 0.07, hero ? 5 : 4);
  P.push({ geometry: spike, material: 'steelBright', position: [0, 0.215, 0] });
  return P;
}

/**
 * 14) LOW-POLY GÖĞÜS ZIRHI (Cuirass + Pauldron + Fauld + Gorget)
 *    Lathe gövde (eliptik ölçekli, çekiç fasetli), göğüs omurgası (keel),
 *    üç katmanlı süpürülmüş omuzluk, bel bantları ve fraksiyon astarı.
 */
function buildCuirass(ctx: BuildCtx): Piece[] {
  const P: Piece[] = [];
  const hero = ctx.lod === 'hero';
  const seg = hero ? 10 : 8;

  // ── gövde tası (boyun → bel) ──
  const torsoProf = profile2([
    [0.1, 0.3],
    [0.185, 0.27],
    [0.215, 0.19],
    [0.228, 0.09],
    [0.21, 0.0],
    [0.182, -0.11],
    [0.172, -0.17],
  ]);
  const torso = new THREE.LatheGeometry(torsoProf, seg);
  torso.scale(1, 1, 0.8); // eliptik kesit: göğüs derinliği < genişliği
  weldVertices(torso, 1e-4);
  if (hero) {
    jitterGeometry(torso, 0.004, 313);
    quantizeGeometry(torso, 0.012);
  }
  P.push({ geometry: torso, material: 'steel' });

  // ── iç astar (karanlık) ──
  if (hero) {
    const inner = torso.clone();
    inner.scale(0.93, 0.98, 0.93);
    flipWinding(inner);
    P.push({ geometry: inner, material: 'dark' });
  }

  // ── göğüs omurgası (keel) ve sırt omurgası ──
  const keel = new THREE.BoxGeometry(0.036, 0.4, 0.05);
  keel.translate(0, 0.09, 0.185);
  P.push({ geometry: keel, material: 'steelBright' });
  if (hero) {
    const keelBack = new THREE.BoxGeometry(0.032, 0.36, 0.042);
    keelBack.translate(0, 0.09, -0.15);
    P.push({ geometry: keelBack, material: 'steel' });
  }

  // ── boyunluk (gorget) ──
  const gorget = new THREE.TorusGeometry(0.108, hero ? 0.024 : 0.026, 3, seg);
  gorget.rotateX(90 * DEG);
  P.push({ geometry: gorget, material: 'steelDark', position: [0, 0.292, 0] });
  if (hero) {
    const collar = new THREE.LatheGeometry(profile2([[0.1, 0.02], [0.122, 0.0], [0.116, -0.03], [0.096, -0.04]]), seg);
    P.push({ geometry: collar, material: 'mail', position: [0, 0.31, 0] });
  }

  // ── fraksiyon göğüs arması ──
  const charge = buildCharge(ctx.faction.charge, ctx.faction.colors.trim, hero ? 0.075 : 0.07, ctx.faction.colors.secondary);
  for (const cp of charge) {
    P.push({
      geometry: cp.geometry,
      material: {
        key: 'cuirassCharge',
        color: (cp.material as { color?: number })?.color ?? ctx.faction.colors.trim,
        metalness: 0.75,
        roughness: 0.4,
        flatShading: true,
      },
      position: [(cp.position?.[0] ?? 0), 0.15 + (cp.position?.[1] ?? 0), 0.213],
      rotation: cp.rotation,
    });
  }

  // ── bel bantları (fauld) ──
  const fauldCount = hero ? 3 : 2;
  for (let i = 0; i < fauldCount; i++) {
    const t = i / Math.max(1, fauldCount - 1);
    const y = -0.19 - i * 0.055;
    const r = 0.176 + i * 0.014;
    const band = new THREE.LatheGeometry(profile2([[r, 0.024], [r + 0.022, 0.0], [r + 0.016, -0.026], [r - 0.004, -0.03]]), seg);
    band.scale(1, 1, 0.82);
    P.push({ geometry: band, material: i % 2 === 0 ? 'steelDark' : 'steel', position: [0, y, 0] });
    if (hero && t >= 0) {
      // bant uçlarında altın perçin
      for (const s of [-1, 1]) {
        const rv = new THREE.OctahedronGeometry(0.011, 0);
        rv.scale(1, 0.7, 1);
        P.push({ geometry: rv, material: 'gold', position: [s * (r * 0.72), y + 0.004, r * 0.42] });
      }
    }
  }

  // ── kemer + tokası ──
  const belt = new THREE.TorusGeometry(0.188, hero ? 0.022 : 0.024, 3, seg);
  belt.rotateX(90 * DEG);
  belt.scale(1, 1, 0.82);
  P.push({ geometry: belt, material: 'leatherDark', position: [0, -0.16, 0] });
  const buckle = new THREE.BoxGeometry(0.07, 0.06, 0.02);
  P.push({ geometry: buckle, material: 'gold', position: [0, -0.16, 0.156] });

  // ── omuzluklar (pauldron): 3 katman süpürülmüş kabuk ──
  const pauldronOutline = profile2([
    [-0.02, 0.19],
    [0.09, 0.25],
    [0.19, 0.13],
    [0.2, -0.03],
    [0.1, -0.13],
    [-0.02, -0.09],
  ]);
  const pauldronProfile: Vec2Tuple[] = [
    [0, 0.03],
    [0.055, 0.016],
    [0.095, -0.018],
    [0.1, -0.052],
  ];
  for (const side of [-1, 1]) {
    const layers = hero ? 3 : 2;
    for (let i = 0; i < layers; i++) {
      const k = 1 - i * 0.14;
      const outline = pauldronOutline.map((p) => v2(p.x * k, p.y * k));
      const shell = shellSweep(outline, profile2(pauldronProfile.map((p) => [p[0] * k, p[1]] as Vec2Tuple)));
      P.push({
        geometry: shell,
        material: i === 0 ? 'steelBright' : 'steel',
        position: [side * (0.196 + i * 0.014), 0.222 - i * 0.062, 0],
        rotation: [-90 * DEG, 0, side > 0 ? -6 * DEG : 6 * DEG],
      });
      if (hero) {
        // katman kenarında altın biye
        const trimOutline = outline.map((p) => v2(p.x, p.y));
        const trimShell = shellSweep(trimOutline, profile2([[0.098, -0.05], [0.104, -0.056], [0.104, -0.044]]));
        P.push({
          geometry: trimShell,
          material: 'trim',
          position: [side * (0.196 + i * 0.014), 0.222 - i * 0.062, 0],
          rotation: [-90 * DEG, 0, side > 0 ? -6 * DEG : 6 * DEG],
        });
      }
    }
    // omuz tepesi rondel + diken
    const rondel = new THREE.CylinderGeometry(hero ? 0.042 : 0.038, hero ? 0.046 : 0.042, 0.018, ctx.rad(6));
    rondel.rotateZ(side * 90 * DEG);
    P.push({ geometry: rondel, material: 'gold', position: [side * 0.215, 0.255, 0] });
    if (hero && side > 0) {
      const spike = new THREE.ConeGeometry(0.018, 0.07, 4);
      spike.rotateZ(-90 * DEG);
      P.push({ geometry: spike, material: 'steelBright', position: [0.25, 0.27, 0] });
    }
    if (hero && side < 0) {
      // sol omuzda küçük kanat/çıkıntı (asimetrik Bannerlord silüeti)
      const fin = shapeFrom([
        [0, 0],
        [0.1, 0.03],
        [0.13, -0.06],
        [0.04, -0.05],
      ]);
      const finGeo = new THREE.ExtrudeGeometry(fin, extrudeOpts(0.014, 0.004, 1));
      P.push({ geometry: finGeo, material: 'steelDark', position: [-0.24, 0.27, 0], rotation: [0, 90 * DEG, 20 * DEG] });
    }
  }

  // ── koltuk altı / kol ağzı kapakları (içerisi görünmesin) ──
  for (const side of [-1, 1]) {
    const armpit = new THREE.CircleGeometry(0.075, ctx.rad(6));
    armpit.rotateY(side * 90 * DEG);
    P.push({ geometry: armpit, material: 'dark', position: [side * 0.17, 0.14, 0] });
  }
  return P;
}

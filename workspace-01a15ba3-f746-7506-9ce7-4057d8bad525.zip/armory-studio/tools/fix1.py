import io

p = 'src/Armory.ts'
s = io.open(p, encoding='utf-8').read()

s = s.replace("\nimport { shellSweep as shellSweepLocal, flipWinding as flipWindingLocal } from './Core.js';\n", "")
s = s.replace("  mergePieces,\n  profile2,", "  flipWinding,\n  mergePieces,\n  profile2,\n  shellSweep,")
s = s.replace(
    "  const g = shellSweepLocal(outline, profile2(profile));\n  return flip ? flipWindingLocal(g) : g;",
    "  const g = shellSweep(outline, profile2(profile));\n  return flip ? flipWinding(g) : g;",
)

old_tendon = """    // ── kol üzerinde tendon sarımı / süs şeridi ──
    if (hero) {
      for (const t of [0.34, 0.56, 0.76]) {
        const y = dir * BOW.half * t;
        const ring = new THREE.TorusGeometry(0.02, 0.005, 3, 7);
        ring.rotateX(90 * DEG);
        const z = -BOW.k * y * y * (y / Math.abs(y || 1)) * Math.abs(y) * 0 + -Math.sign(y) * BOW.k * y * y * 0;
        P.push({ geometry: ring, material: 'trim', position: [0, y, -BOW.k * y * y * Math.abs(y) * 0] });
      }"""
new_tendon = """    // ── kol üzerinde tendon sarımı (büküm sonrası z konumu: -k·y·|y|) ──
    if (hero) {
      for (const t of [0.34, 0.56, 0.76]) {
        const y = dir * BOW.half * t;
        const ring = new THREE.TorusGeometry(0.021, 0.005, 3, 7);
        ring.rotateX(90 * DEG);
        P.push({ geometry: ring, material: 'trim', position: [0, y, -BOW.k * y * Math.abs(y)] });
      }"""
assert old_tendon in s
s = s.replace(old_tendon, new_tendon)

old_ang = "    const ang = Math.atan2(-BOW.k * BOW.half * BOW.half * 0 + dir * 2 * BOW.k * BOW.half, 1);"
new_ang = "    // bükülmüş ucun teğet açısı: theta'(y) = 2·k·y\n    const ang = 2 * BOW.k * BOW.half;"
assert old_ang in s
s = s.replace(old_ang, new_ang)

s = s.replace("  const featherCount = hero ? 3 : 3;", "  const featherCount = 3;")

io.open(p, 'w', encoding='utf-8').write(s)
print('ok')

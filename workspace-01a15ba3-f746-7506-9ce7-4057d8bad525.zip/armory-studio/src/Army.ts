/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BANNERFORGE ENGINE · Army.ts
 *  500v500 meydan savaşı: InstancedMesh kalabalık sistemi + simülasyon.
 *
 *  TEKNİK (1000 birim neden akıcı çalışır?)
 *  ────────────────────────────────────────
 *  1) POZ BAKE: Her rol × klip × faz kombinasyonu için karakter/at rig'i o
 *     pozda TEK BufferGeometry'ye pişirilir (bakeRigPose). Animasyon
 *     çeşitliliği geometri varyantlarından gelir; runtime'da kemik matrisi,
 *     skinning veya vertex deformasyonu HESAPLANMAZ.
 *  2) ŞABLON YENİDEN KULLANIMI: Rol başına 1 karakter/at üretilir, tüm fazlar
 *     aynı şablonun rig'i pozlanarak bake edilir (üretim maliyeti ~rol sayısı).
 *  3) INSTANCING: Her varyant bir InstancedMesh → 1000 birim ≈ 20–30 draw-call.
 *  4) SABİT SLOT + EŞİK: Her birimin slotu sabittir; matris yalnızca konum
 *     1.5 cm'den fazla değiştiğinde / yön 1° döndüğünde / faz slotu
 *     değiştiğinde yeniden yazılır.
 *  5) TEK MATERYAL: merged geometri + vertexColors + flatShading.
 *
 *  ÖLÇEK: 1 birim = 1 m, zemin y = 0. Hatlar X boyunca dizilir, ordular
 *         ±Z'den birbirine yürür (ordu 0 → -Z, ordu 1 → +Z hedefler).
 * ═══════════════════════════════════════════════════════════════════════════
 */

import * as THREE from 'three';
import { BUDGET, DEG, LodLevel, MaterialLibrary, Piece, clamp, makeRng, mergePieces, reduceToBudget, triCount } from './Core.js';
import { FactionPalette, buildBanner } from './Faction.js';
import { Character, CharacterOptions, ROLE_PRESETS, UnitRole, bakeHierarchy } from './Character.js';
import { Horse, HorseOptions } from './Horse.js';
import { Rig } from './Rig.js';

/* ─────────────────────────── tipler ─────────────────────────── */

export type UnitState = 'advance' | 'engage' | 'attack' | 'block' | 'shoot' | 'dying' | 'dead' | 'rout';

export interface UnitData {
  id: number;
  armyId: 0 | 1;
  role: UnitRole;
  mounted: boolean;
  pos: THREE.Vector3;
  facing: number;
  state: UnitState;
  /** Animasyon faz ofseti (0..1) — kalabalıkta senkronu kırar. */
  phase: number;
  speed: number;
  hp: number;
  alive: boolean;
  stateTime: number;
  nextAction: number;
  targetId: number;
  dirty: boolean;
  /** Rol içi sıra numarası → sabit instance slotu. */
  slot: number;
  deathDir: number;
  homeX: number;
  hasStruck: boolean;
  /** Son yazılan matris durumu (eşik kontrolü için). */
  lastX: number;
  lastZ: number;
  lastFacing: number;
  lastPhaseIndex: number;
}

export interface ArmyConfig {
  faction: FactionPalette | string;
  counts: Partial<Record<UnitRole, number>>;
  lod?: LodLevel;
  /** Her klip için kaç animasyon fazı bake edilsin (bellek ↔ akıcılık). */
  phases?: number;
  seed?: number;
}

export interface SimConfig {
  /** Hat genişliği (m). */
  width: number;
  /** İki ordunun başlangıç Z ayrıklığı (m). */
  separation: number;
  /** Birimler arası mesafe (m). */
  spacing: number;
  /** Çarpışma/hat mesafesi (m). */
  engageDistance: number;
}

export interface SimEvent {
  type: 'clash' | 'arrowHit' | 'bowRelease' | 'death' | 'horn';
  position: THREE.Vector3;
  armyId: 0 | 1;
}

export interface ArmyStats {
  units: number;
  alive: number;
  dead: number;
  drawCalls: number;
  trianglesPerUnit: number;
  /** Rol başına çizilen üçgen (Bölüm 1 uyum raporu için). */
  trianglesPerRole: Partial<Record<UnitRole, number>>;
  totalTrianglesRendered: number;
  instances: number;
  variants: number;
}

/* ─────────────────────────── poz bake ─────────────────────────── */

const _m4 = new THREE.Matrix4();

/**
 * Bir rig'in mevcut pozunu, görsel hiyerarşiyi KÖK uzayında tek
 * BufferGeometry'ye pişirir. Kök (pozisyon/yön) hariç tutulur — o bilgi
 * InstancedMesh matrisinde taşınır.
 */
export function bakeRigPose(
  rig: Rig,
  visualRoot: THREE.Object3D,
  mats: MaterialLibrary,
  excludeJoints: string[] = ['root'],
  maxTris?: number,
): THREE.BufferGeometry {
  rig.root.updateMatrixWorld(true);
  visualRoot.updateMatrixWorld(true);
  // Referans: 'root' KEMİĞİ (rig.root değil — rig.root yalnızca taşıyıcı
  // Object3D'dir ve tüm iskelet onun ALTINDADIR; hariç tutulursa hiçbir
  // mesh toplanamaz). Kök kemik ofseti [0,0,0] olduğu için bake edilen
  // geometri zemin uzayında (ayaklar y = 0) çıkar.
  const refBone = rig.joints.get('root') ?? rig.root;
  const rootInv = _m4.copy(refBone.matrixWorld).invert().clone();

  const excluded = new Set<THREE.Object3D>();
  for (const name of excludeJoints) {
    if (name === 'root') continue; // kök kemik referans olarak kullanılır
    const j = rig.joints.get(name);
    if (j) excluded.add(j);
  }

  const pieces: Piece[] = [];
  const m = new THREE.Matrix4();

  visualRoot.traverse((o) => {
    const mesh = o as THREE.Mesh;
    if (!mesh.isMesh || !mesh.geometry) return;
    if (excluded.size) {
      let cur: THREE.Object3D | null = mesh;
      let skip = false;
      while (cur) {
        if (excluded.has(cur)) {
          skip = true;
          break;
        }
        cur = cur.parent;
      }
      if (skip) return;
    }
    m.multiplyMatrices(rootInv, mesh.matrixWorld);
    const g = mesh.geometry.clone();
    g.applyMatrix4(m);
    const mat = mesh.material as THREE.MeshStandardMaterial;
    pieces.push({
      geometry: g,
      material: {
        key: 'bake',
        color: mat.color ? mat.color.getHex() : 0xffffff,
        metalness: mat.metalness ?? 0.15,
        roughness: mat.roughness ?? 0.85,
        flatShading: true,
        side: mat.side ?? THREE.FrontSide,
      },
    });
  });

  const merged = mergePieces(pieces, mats);
  if (maxTris === undefined || triCount(merged) <= maxTris) return merged;
  const reduced = reduceToBudget(merged, maxTris);
  merged.dispose();
  return reduced;
}

/** Birim tipi + LOD için Bölüm 1 performans bütçesi (üçgen). */
export function unitBudget(role: UnitRole, lod: LodLevel): number {
  const soldier = BUDGET.soldierMax; // 800 → tam donanımlı piyade (Bölüm 1)
  const horse = BUDGET.horseMax;     // 900 → zırhlı savaş atı (Bölüm 1)
  const crowd = lod === 'crowd' ? 0.72 : 1;
  if (lod === 'hero') return Math.round((role === 'cavalry' ? soldier + horse : soldier) * 1.0);
  return Math.round((role === 'cavalry' ? soldier + horse : soldier) * crowd);
}

/* ─────────────────────────── varyant tablosu ─────────────────────────── */

/** İlerlemeli kurulum adımı. */
export type BuildStep =
  | { kind: 'template'; role: UnitRole; mounted: boolean; count: number }
  | { kind: 'variant'; role: UnitRole; mounted: boolean; count: number; clip: string; phaseIndex: number; cycle: number }
  | { kind: 'releaseTemplate'; role: UnitRole; count: number };

interface UnitTypeVariant {
  role: UnitRole;
  clip: string;
  phaseIndex: number;
  geometry: THREE.BufferGeometry;
  mesh: THREE.InstancedMesh;
  triangles: number;
  capacity: number;
}

/** Rol → saldırı klibi. */
function attackClipFor(role: UnitRole): string {
  switch (role) {
    case 'archer': return 'shootBow';
    case 'cavalry': return 'attackThrust';
    case 'sergeant': return 'attackAxe';
    case 'banner': return 'block';
    default: return 'attackSword';
  }
}

/** Tarayıcıda bir kare bekler (Node'da hemen döner). */
function nextFrame(): Promise<void> {
  return new Promise((resolve) => {
    if (typeof requestAnimationFrame === 'function') requestAnimationFrame(() => resolve());
    else setTimeout(resolve, 0);
  });
}

function clipCycle(clip: string): number {
  switch (clip) {
    case 'walk': return 1.1;
    case 'horseWalk': return 1.0;
    case 'attackSword': return 1.5;
    case 'attackAxe': return 2.1;
    case 'attackThrust': return 1.85;
    case 'shootBow': return 2.6;
    case 'block': return 2.4;
    case 'death': return 1.6;
    default: return 1.5;
  }
}

/* ─────────────────────────── Army ─────────────────────────── */

export class Army {
  readonly id: 0 | 1;
  readonly faction: FactionPalette;
  readonly units: UnitData[] = [];
  readonly group = new THREE.Group();
  readonly lod: LodLevel;
  readonly stats: ArmyStats = {
    units: 0, alive: 0, dead: 0, drawCalls: 0, trianglesPerUnit: 0, trianglesPerRole: {},
    totalTrianglesRendered: 0, instances: 0, variants: 0,
  };

  private variants: UnitTypeVariant[] = [];
  private variantMap = new Map<string, UnitTypeVariant>();
  private roleSlotCounter = new Map<UnitRole, number>();
  private roleCapacity = new Map<UnitRole, number>();
  private mats: MaterialLibrary;
  private phases: number;
  private seed: number;
  private bannerMeshes: THREE.Mesh[] = [];
  private triPerUnit = 0;
  private tmpObj = new THREE.Object3D();

  constructor(id: 0 | 1, config: ArmyConfig) {
    this.id = id;
    this.faction = typeof config.faction === 'string' ? FactionPalette.byId(config.faction) : config.faction;
    this.lod = config.lod ?? 'crowd';
    this.phases = Math.max(1, config.phases ?? (this.lod === 'crowd' ? 2 : this.lod === 'battle' ? 3 : 4));
    this.seed = config.seed ?? 1234 + id * 777;
    this.mats = new MaterialLibrary({ crowd: { color: 0xffffff, metalness: 0.15, roughness: 0.85 } });
    this.group.name = `army_${id}_${this.faction.id}`;
    this.config = config;
    this.planBuild();
  }

  private config: ArmyConfig;
  private activeTemplate: { role: UnitRole; character: Character | null; horse: Horse | null } | null = null;
  /** Kurulacak iş adımları (rol × klip × faz). İlerlemeli kurulum bunu tüketir. */
  private buildQueue: BuildStep[] = [];
  private builtVariants = 0;
  private totalVariants = 0;

  get buildProgress(): { done: number; total: number; ratio: number } {
    return {
      done: this.builtVariants,
      total: this.totalVariants,
      ratio: this.totalVariants ? this.builtVariants / this.totalVariants : 1,
    };
  }

  get isBuilt(): boolean {
    return this.buildQueue.length === 0 && this.totalVariants > 0;
  }

  /* ── üretim planı: her adım bir varyant (rol × klip × faz) ── */
  private planBuild(): void {
    const config = this.config;
    const rng = makeRng(this.seed);
    const roles: UnitRole[] = ['infantry', 'archer', 'sergeant', 'banner', 'cavalry'];
    let idCounter = 0;

    for (const role of roles) {
      const count = config.counts[role] ?? 0;
      if (count <= 0) continue;
      const mounted = role === 'cavalry';
      const clips = this.clipsFor(role, mounted);
      this.totalVariants += clips.length * this.phases;

      // Şablon ilk adımda üretilir, son adımda bırakılır (bellek dostu).
      this.buildQueue.push({ kind: 'template', role, mounted, count });
      for (const clip of clips) {
        const cycle = clipCycle(clip);
        for (let phaseIndex = 0; phaseIndex < this.phases; phaseIndex++) {
          this.buildQueue.push({ kind: 'variant', role, mounted, count, clip, phaseIndex, cycle });
        }
      }
      this.buildQueue.push({ kind: 'releaseTemplate', role, count });

      // birim kayıtları (ucuz) hemen oluşturulur
      for (let i = 0; i < count; i++) {
        const slot = i % count;
        this.units.push({
          id: idCounter++,
          armyId: this.id,
          role,
          mounted,
          pos: new THREE.Vector3(),
          facing: this.id === 0 ? Math.PI : 0,
          state: 'advance',
          phase: rng(),
          speed: mounted ? 3.6 : 1.45 + rng() * 0.5,
          hp: role === 'sergeant' ? 170 : role === 'cavalry' ? 150 : role === 'infantry' ? 100 : 80,
          alive: true,
          stateTime: 0,
          nextAction: rng() * 1.6,
          targetId: -1,
          dirty: true,
          slot,
          deathDir: rng() > 0.5 ? 1 : -1,
          homeX: 0,
          hasStruck: false,
          lastX: NaN,
          lastZ: NaN,
          lastFacing: NaN,
          lastPhaseIndex: -1,
        });
      }
    }

    this.stats.units = this.units.length;
    this.stats.alive = this.units.length;
    this.stats.trianglesPerUnit = this.triPerUnit;
    this.stats.variants = this.variants.length;
  }

  /**
   * Tek kurulum adımı işler. Döndürür: bitti mi?
   * Tarayıcıda her adımdan sonra bir kare bekleyerek (requestAnimationFrame /
   * setTimeout 0) arayüz donmadan yükleme çubuğu ilerletilir.
   */
  buildStep(): boolean {
    const step = this.buildQueue.shift();
    if (!step) return true;

    if (step.kind === 'template') {
      this.activeTemplate = this.makeTemplate(step.role, step.mounted);
      return false;
    }

    if (step.kind === 'releaseTemplate') {
      this.activeTemplate?.character?.dispose();
      this.activeTemplate?.horse?.dispose();
      this.activeTemplate = null;
      this.roleCapacity.set(step.role, step.count);
      return false;
    }

    // ── variant: rig'i bu fazda pozla ve tek geometriye pişir ──
    const tpl = this.activeTemplate;
    if (!tpl) return false;
    const mounted = step.mounted;
    const rig = mounted ? tpl.horse!.rig : tpl.character!.rig;
    const anim = mounted ? tpl.horse!.animator : tpl.character!.animator;
    const visualRoot = mounted ? tpl.horse!.group : tpl.character!.group;
    const rider = mounted ? tpl.character! : null;

    const phase = step.phaseIndex / this.phases;
    anim.ctx.phase = phase;
    anim.ctx.speed = mounted ? 1.9 : 1;
    const pose = anim.evaluate(step.clip, phase * step.cycle, { phase, speed: anim.ctx.speed });
    rig.applyPose(pose, true);
    // Süvaride binici kendi rig'inde "mountedIdle" pozunda pişirilir.
    if (rider) rider.rig.applyPose(rider.animator.evaluate('mountedIdle', phase * 2.4, { phase }), true);
    visualRoot.updateMatrixWorld(true);

    const limit = unitBudget(step.role, this.lod);
    const geometry = bakeRigPose(rig, visualRoot, this.mats, ['root'], limit);
    const triangles = Math.round(triCount(geometry));
    this.triPerUnit = Math.max(this.triPerUnit, triangles);
    this.stats.trianglesPerRole[step.role] = Math.max(this.stats.trianglesPerRole[step.role] ?? 0, triangles);
    if (triangles > limit) {
      console.warn(`[Bannerforge] Army ${this.id}/${step.role}/${this.lod}: ${triangles} > ${limit} üçgen`);
    }

    const mesh = new THREE.InstancedMesh(geometry, this.mats.mergedMaterial(`army_${this.id}_${this.lod}`), step.count);
    mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    mesh.count = step.count;
    mesh.frustumCulled = false;
    mesh.castShadow = false;
    mesh.receiveShadow = false;
    mesh.name = `a${this.id}_${step.role}_${step.clip}_p${step.phaseIndex}`;
    const zero = new THREE.Matrix4().makeScale(0, 0, 0);
    for (let i = 0; i < step.count; i++) mesh.setMatrixAt(i, zero);
    mesh.instanceMatrix.needsUpdate = true;
    this.group.add(mesh);

    const variant: UnitTypeVariant = {
      role: step.role, clip: step.clip, phaseIndex: step.phaseIndex,
      geometry, mesh, triangles, capacity: step.count,
    };
    this.variants.push(variant);
    this.variantMap.set(`${step.role}|${step.clip}|${step.phaseIndex}`, variant);

    this.builtVariants++;
    this.stats.units = this.units.length;
    this.stats.alive = this.units.filter((u) => u.alive).length;
    this.stats.trianglesPerUnit = this.triPerUnit;
    this.stats.variants = this.variants.length;
    return false;
  }

  /** Kalan tüm adımları senkron çalıştırır (test/Node için). */
  buildSync(): void {
    while (!this.buildStep()) {
      /* adım adım tüket */
    }
  }

  /**
   * Kalan adımları tarayıcıda kare kare işler; her adımda `onProgress` çağrılır.
   * Arayüz donmadan yükleme çubuğu ilerletilebilir.
   */
  async buildAsync(onProgress?: (ratio: number, label: string) => void, yieldEvery = 1): Promise<void> {
    let i = 0;
    while (this.buildQueue.length > 0) {
      const step = this.buildQueue[0];
      this.buildStep();
      onProgress?.(
        this.totalVariants ? this.builtVariants / this.totalVariants : 1,
        step.kind === 'variant' ? `${step.role} · ${step.clip} · faz ${step.phaseIndex + 1}/${this.phases}` : step.kind,
      );
      if (++i % yieldEvery === 0) await nextFrame();
    }
    onProgress?.(1, 'hazır');
  }

  private clipsFor(role: UnitRole, mounted: boolean): string[] {
    if (mounted) return ['horseWalk', 'death'];
    if (role === 'archer') return ['walk', 'shootBow', 'death'];
    if (role === 'banner') return ['walk', 'block', 'death'];
    return ['walk', attackClipFor(role), 'death'];
  }

  private makeTemplate(role: UnitRole, mounted: boolean): { role: UnitRole; character: Character | null; horse: Horse | null } {
    const character = new Character({
      faction: this.faction,
      lod: this.lod,
      seed: this.seed + role.length * 31 + (mounted ? 5 : 0),
      loadout: this.loadoutFor(role),
      build: 0.5,
    });
    if (!mounted) return { role, character, horse: null };
    const coats = ['bay', 'chestnut', 'grey', 'black'] as const;
    const horse = new Horse({
      faction: this.faction,
      lod: this.lod,
      coat: coats[Math.abs(this.seed + role.length) % coats.length],
      barding: true,
      caparison: true,
      saddle: true,
      seed: this.seed + 17,
    });
    horse.attachRider(character);
    return { role, character, horse };
  }

  /** Kalabalık LOD'unda bütçeye (400–800 üçgen) uyan hafif donanım. */
  private loadoutFor(role: UnitRole): CharacterOptions['loadout'] {
    const rich = this.lod !== 'crowd';
    switch (role) {
      case 'archer':
        return { weapon: 'recurveBow', offhand: null, back: 'arrow', tier: 'light', helm: 'kettle', surcoat: rich, role };
      case 'cavalry':
        return { weapon: 'lance', offhand: 'kiteShield', back: rich ? 'scimitar' : null, tier: 'heavy', helm: 'greatHelm', surcoat: rich, role };
      case 'sergeant':
        return { weapon: rich ? 'bardiche' : 'warAxe', offhand: rich ? null : 'vikingShield', tier: 'heavy', helm: 'spangen', surcoat: rich, role };
      case 'banner':
        return { weapon: 'gladius', offhand: 'vikingShield', tier: 'medium', helm: 'spangen', surcoat: true, role };
      default:
        return { weapon: 'gladius', offhand: 'vikingShield', tier: rich ? 'medium' : 'light', helm: rich ? 'spangen' : 'kettle', surcoat: rich, role };
    }
  }

  /* ── formasyon ── */
  layout(sim: SimConfig): void {
    const rng = makeRng(this.seed + 99);
    const byRole = new Map<UnitRole, UnitData[]>();
    for (const u of this.units) {
      const list = byRole.get(u.role);
      if (list) list.push(u);
      else byRole.set(u.role, [u]);
    }
    const dir = this.id === 0 ? 1 : -1;
    const rows: { role: UnitRole; zRow: number; lateralBias: number }[] = [
      { role: 'infantry', zRow: 0, lateralBias: 0 },
      { role: 'sergeant', zRow: 1, lateralBias: 0 },
      { role: 'banner', zRow: 2, lateralBias: 0 },
      { role: 'archer', zRow: 5, lateralBias: 0 },
      { role: 'cavalry', zRow: 2, lateralBias: 0.44 },
    ];

    for (const row of rows) {
      const list = byRole.get(row.role);
      if (!list || list.length === 0) continue;
      const perRow = Math.max(1, Math.ceil(Math.sqrt(list.length * 2.4)));
      for (let i = 0; i < list.length; i++) {
        const r = Math.floor(i / perRow);
        const c = i % perRow;
        const inRow = Math.min(perRow, list.length - r * perRow);
        const gap = sim.spacing * (row.role === 'cavalry' ? 2.0 : 1);
        const wing = row.lateralBias ? Math.sign(this.id === 0 ? 1 : -1) * sim.width * row.lateralBias : 0;
        const x = (c - (inRow - 1) / 2) * gap + wing + (rng() - 0.5) * 0.25;
        const z = dir * (sim.separation / 2 + row.zRow * 1.3 + r * gap) + (rng() - 0.5) * 0.25;
        list[i].pos.set(x, 0, z);
        list[i].homeX = x;
        list[i].facing = this.id === 0 ? Math.PI : 0;
        list[i].alive = true;
        list[i].state = 'advance';
        list[i].dirty = true;
      }
    }
    this.refreshAll();
  }

  /* ── matris yazımı ── */
  private writeInstance(u: UnitData): void {
    const clip = this.clipForState(u);
    const phaseIndex = clip === 'death'
      ? Math.min(this.phases - 1, Math.floor(clamp(u.stateTime / 1.6, 0, 0.999) * this.phases))
      : Math.floor(((u.phase + u.stateTime * 0.9) % 1) * this.phases) % this.phases;
    const variant = this.variantMap.get(`${u.role}|${clip}|${phaseIndex}`);
    if (!variant) return;

    const o = this.tmpObj;
    o.position.copy(u.pos);
    if (u.state === 'dying' || u.state === 'dead') {
      const k = clamp(u.stateTime / 1.5, 0, 1);
      o.rotation.set(u.deathDir * k * 76 * DEG, u.facing, k * 12 * DEG);
      o.position.y = -Math.sin(k * 1.25) * 0.34;
      o.scale.setScalar(1);
    } else {
      o.rotation.set(0, u.facing, 0);
      o.position.y = bobFor(u, clip);
      o.scale.setScalar(1);
    }
    o.updateMatrix();
    variant.mesh.setMatrixAt(u.slot, o.matrix);
    variant.mesh.instanceMatrix.needsUpdate = true;

    u.lastX = u.pos.x;
    u.lastZ = u.pos.z;
    u.lastFacing = u.facing;
    u.lastPhaseIndex = phaseIndex;
  }

  private clipForState(u: UnitData): string {
    if (u.state === 'dead' || u.state === 'dying') return 'death';
    if (u.state === 'attack') return u.role === 'archer' ? 'attackSword' : u.mounted ? 'horseWalk' : attackClipFor(u.role);
    if (u.state === 'shoot') return 'shootBow';
    if (u.state === 'block') return u.role === 'banner' ? 'block' : 'walk';
    return u.mounted ? 'horseWalk' : 'walk';
  }

  /** Tüm matrisleri yeniden yaz (ilk kare / reset / teleport). */
  refreshAll(): void {
    for (const u of this.units) this.writeInstance(u);
    this.updateStats();
  }

  /**
   * Kare başına çağrılır: yalnızca eşiği aşan birimlerin matrisi yazılır.
   * Faz slotu değişen birimler (yürüyenler) zaten güncellenir.
   */
  flush(positionThreshold = 0.015, angleThreshold = 0.03): void {
    let written = 0;
    for (const u of this.units) {
      const clip = this.clipForState(u);
      const phaseIndex = clip === 'death'
        ? Math.min(this.phases - 1, Math.floor(clamp(u.stateTime / 1.6, 0, 0.999) * this.phases))
        : Math.floor(((u.phase + u.stateTime * 0.9) % 1) * this.phases) % this.phases;

      const moved = !(Math.abs(u.pos.x - u.lastX) < positionThreshold && Math.abs(u.pos.z - u.lastZ) < positionThreshold);
      const turned = Math.abs(u.facing - u.lastFacing) > angleThreshold;
      const phaseChanged = phaseIndex !== u.lastPhaseIndex;
      if (u.dirty || moved || turned || phaseChanged) {
        this.writeInstance(u);
        u.dirty = false;
        written++;
      }
    }
    if (written > 0) this.updateStats();
  }

  private updateStats(): void {
    let instances = 0;
    let tris = 0;
    let drawCalls = 0;
    let alive = 0;
    for (const v of this.variants) {
      if (v.mesh.count > 0) {
        instances += v.capacity;
        tris += v.capacity * v.triangles;
        drawCalls++;
      }
    }
    for (const u of this.units) if (u.alive) alive++;
    this.stats.drawCalls = drawCalls;
    this.stats.instances = instances;
    this.stats.totalTrianglesRendered = tris;
    this.stats.alive = alive;
    this.stats.dead = this.units.length - alive;
  }

  /* ── sancaklar ── */
  addBanners(count: number, poleHeight = 3.2): THREE.Mesh[] {
    const out: THREE.Mesh[] = [];
    for (let i = 0; i < count; i++) {
      const banner = buildBanner({
        width: 1.2,
        height: 1.55,
        faction: this.faction,
        poleHeight,
        edge: i % 2 === 0 ? 'swallow' : 'pointed',
        segments: [5, 4],
      });
      const geo = bakeHierarchy(banner.group);
      const mesh = new THREE.Mesh(geo, this.mats.mergedMaterial(`banner_${this.id}`));
      mesh.castShadow = true;
      mesh.visible = false;
      this.group.add(mesh);
      out.push(mesh);
      this.bannerMeshes.push(mesh);
    }
    return out;
  }

  updateBanners(): void {
    if (this.bannerMeshes.length === 0) return;
    const carriers = this.units.filter((u) => u.role === 'banner' && u.alive);
    for (let i = 0; i < this.bannerMeshes.length; i++) {
      const mesh = this.bannerMeshes[i];
      const carrier = carriers[i % Math.max(1, carriers.length)];
      if (!carrier || carriers.length === 0) {
        mesh.visible = false;
        continue;
      }
      mesh.visible = true;
      mesh.position.set(carrier.pos.x, 0, carrier.pos.z);
      mesh.rotation.y = carrier.facing + 90 * DEG;
    }
  }

  dispose(): void {
    for (const v of this.variants) {
      v.geometry.dispose();
      v.mesh.dispose();
    }
    for (const m of this.bannerMeshes) m.geometry.dispose();
    this.mats.dispose();
    this.variants = [];
    this.variantMap.clear();
    this.units.length = 0;
  }
}

function bobFor(u: UnitData, clip: string): number {
  const k = (u.phase + u.stateTime * (clip === 'horseWalk' ? 1.5 : 1.1)) * Math.PI * 2;
  if (clip === 'walk') return Math.abs(Math.sin(k)) * (u.speed > 2 ? 0.05 : 0.02);
  if (clip === 'horseWalk') return Math.abs(Math.sin(k)) * 0.075;
  if (clip === 'attackSword' || clip === 'attackAxe') return Math.abs(Math.sin(k * 1.4)) * 0.015;
  return 0;
}

/* ═══════════════════════════════════════════════════════════════════════
   MEYDAN SAVAŞI SİMÜLASYONU
   ═══════════════════════════════════════════════════════════════════════ */

interface Arrow {
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  life: number;
  flightTime: number;
  active: boolean;
  targetId: number;
  targetArmy: 0 | 1;
}

export interface BattleOptions {
  armies: [ArmyConfig, ArmyConfig];
  sim?: Partial<SimConfig>;
  arrowPool?: number;
  seed?: number;
  /**
   * true → ordular kurulum adımlarını BEKLETİR; `buildAsync()` ile kare kare
   * işlenir (tarayıcıda yükleme çubuğu için). false → kurucu içinde senkron.
   */
  progressive?: boolean;
}

export class BattleSim {
  readonly armies: [Army, Army];
  readonly group = new THREE.Group();
  readonly sim: SimConfig;
  readonly events: SimEvent[] = [];
  time = 0;
  phase: 'muster' | 'advance' | 'clash' | 'aftermath' = 'muster';

  private arrowMesh: THREE.InstancedMesh | null = null;
  private arrowGeo: THREE.BufferGeometry | null = null;
  private arrows: Arrow[] = [];
  private rng: () => number;
  private tmpVec = new THREE.Vector3();
  private tmpObj = new THREE.Object3D();
  private eventBudget = 0;

  constructor(options: BattleOptions) {
    const seed = options.seed ?? 20261020;
    this.rng = makeRng(seed);
    this.sim = {
      width: 48,
      separation: 78,
      spacing: 1.15,
      engageDistance: 1.5,
      ...(options.sim ?? {}),
    };
    this.armies = [new Army(0, options.armies[0]), new Army(1, options.armies[1])];
    if (options.progressive !== true) {
      this.armies[0].buildSync();
      this.armies[1].buildSync();
    }
    this.armies[0].layout(this.sim);
    this.armies[1].layout(this.sim);
    this.group.add(this.armies[0].group, this.armies[1].group);
    this.armies[0].addBanners(2);
    this.armies[1].addBanners(2);
    if (options.arrowPool !== 0) this.initArrows(options.arrowPool ?? 96);
    this.pushEvent('horn', new THREE.Vector3(0, 2, this.sim.separation * 0.5), 0);
    this.phase = 'advance';
  }

  /** İlerlemeli kurulum: her iki ordunun varyantları kare kare pişirilir. */
  async buildAsync(onProgress?: (ratio: number, label: string) => void): Promise<void> {
    const total = this.armies[0].buildProgress.total + this.armies[1].buildProgress.total;
    let done = 0;
    for (const army of this.armies) {
      await army.buildAsync((r, label) => {
        onProgress?.(total ? (done + r * army.buildProgress.total) / total : 1, `${army.id === 0 ? 'A' : 'B'} ordusu · ${label}`);
      });
      done += army.buildProgress.total;
    }
    this.armies[0].layout(this.sim);
    this.armies[1].layout(this.sim);
    onProgress?.(1, 'savaşa hazır');
  }

  private initArrows(pool: number): void {
    const shaft = new THREE.CylinderGeometry(0.012, 0.012, 0.72, 3, 1);
    shaft.rotateX(90 * DEG);
    const head = new THREE.ConeGeometry(0.024, 0.11, 3);
    head.rotateX(-90 * DEG);
    head.translate(0, 0, 0.41);
    const fletch = new THREE.BoxGeometry(0.1, 0.006, 0.13);
    fletch.translate(0, 0, -0.3);
    this.arrowGeo = mergePieces(
      [
        { geometry: shaft, material: { key: 'a', color: 0x8a6a3d, metalness: 0.05, roughness: 0.9 } },
        { geometry: head, material: { key: 'b', color: 0x9aa2ab, metalness: 0.7, roughness: 0.4 } },
        { geometry: fletch, material: { key: 'c', color: 0xd8d2c2, metalness: 0.04, roughness: 0.95 } },
      ],
      new MaterialLibrary({}),
    );
    const mat = new THREE.MeshStandardMaterial({ vertexColors: true, flatShading: true, roughness: 0.85, metalness: 0.15 });
    this.arrowMesh = new THREE.InstancedMesh(this.arrowGeo, mat, pool);
    this.arrowMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.arrowMesh.count = 0;
    this.arrowMesh.frustumCulled = false;
    this.group.add(this.arrowMesh);
    for (let i = 0; i < pool; i++) {
      this.arrows.push({
        pos: new THREE.Vector3(), vel: new THREE.Vector3(), life: 0, flightTime: 1,
        active: false, targetId: -1, targetArmy: 0,
      });
    }
  }

  private pushEvent(type: SimEvent['type'], position: THREE.Vector3, armyId: 0 | 1): void {
    if (this.events.length > 48) return;
    this.events.push({ type, position: position.clone(), armyId });
  }

  /** Ses/efekt katmanına aktarılacak olaylar (kamera merkezine göre filtrelenebilir). */
  drainEvents(max = 12): SimEvent[] {
    const out = this.events.splice(0, Math.min(max, this.events.length));
    return out;
  }

  reset(): void {
    this.armies[0].layout(this.sim);
    this.armies[1].layout(this.sim);
    for (const army of this.armies) {
      for (const u of army.units) {
        u.alive = true;
        u.hp = u.role === 'sergeant' ? 170 : u.role === 'cavalry' ? 150 : u.role === 'infantry' ? 100 : 80;
        u.state = 'advance';
        u.stateTime = 0;
        u.nextAction = this.rng() * 1.6;
        u.targetId = -1;
        u.hasStruck = false;
        u.dirty = true;
      }
      army.refreshAll();
    }
    for (const a of this.arrows) a.active = false;
    if (this.arrowMesh) this.arrowMesh.count = 0;
    this.time = 0;
    this.phase = 'advance';
    this.pushEvent('horn', new THREE.Vector3(0, 2, this.sim.separation * 0.5), 0);
  }

  update(dt: number): void {
    dt = Math.min(dt, 0.05);
    this.time += dt;
    this.eventBudget = 8;
    const [A, B] = this.armies;

    for (const army of this.armies) {
      const enemy = army === A ? B : A;
      const dir = army.id === 0 ? -1 : 1;
      for (const u of army.units) {
        u.stateTime += dt;
        if (!u.alive) {
          if (u.state === 'dying' && u.stateTime > 1.5) {
            u.state = 'dead';
            u.dirty = true;
          }
          continue;
        }

        const target = this.findTarget(u, enemy);
        let dist = Infinity;
        if (target) dist = this.tmpVec.subVectors(target.pos, u.pos).length();

        switch (u.state) {
          case 'advance': {
            u.pos.z += dir * u.speed * dt;
            u.pos.x += (u.homeX - u.pos.x) * Math.min(1, dt * 1.4);
            u.facing = army.id === 0 ? Math.PI : 0;
            u.dirty = true;
            const trigger = u.role === 'archer' ? 27 : this.sim.engageDistance + 1.4;
            if (dist < trigger) {
              u.state = u.role === 'archer' ? 'shoot' : 'engage';
              u.stateTime = 0;
              u.dirty = true;
            }
            break;
          }
          case 'engage': {
            if (target) {
              this.tmpVec.subVectors(target.pos, u.pos);
              const d = this.tmpVec.length();
              if (d > 0.001) {
                this.tmpVec.divideScalar(d);
                u.facing = Math.atan2(this.tmpVec.x, this.tmpVec.z);
                if (d > 1.3) u.pos.addScaledVector(this.tmpVec, Math.min(u.speed * 0.7 * dt, d - 1.2));
              }
            }
            u.dirty = true;
            if (u.stateTime > u.nextAction) {
              u.state = u.role === 'banner' ? 'block' : 'attack';
              u.stateTime = 0;
              u.hasStruck = false;
              u.nextAction = 0.7 + this.rng() * 1.9;
              u.dirty = true;
            }
            if (dist > 8) {
              u.state = 'advance';
              u.dirty = true;
            }
            break;
          }
          case 'attack': {
            u.dirty = true;
            const cycle = u.role === 'sergeant' ? 2.1 : 1.5;
            const impact = u.role === 'sergeant' ? 1.1 : 0.63;
            const k = u.stateTime % cycle;
            if (!u.hasStruck && k > impact) {
              u.hasStruck = true;
              if (target && dist < 2.6) {
                this.damage(target, u.role === 'sergeant' ? 32 : 21, army.id);
                this.emit('clash', u.pos, 1.15, army.id);
              }
            }
            if (k < impact * 0.4) u.hasStruck = false;
            if (u.stateTime > u.nextAction) {
              u.state = this.rng() > 0.74 ? 'block' : 'engage';
              u.stateTime = 0;
              u.nextAction = 0.6 + this.rng() * 1.7;
              u.dirty = true;
            }
            break;
          }
          case 'block': {
            u.dirty = true;
            if (u.stateTime > 0.9 + this.rng() * 0.5) {
              u.state = 'engage';
              u.stateTime = 0;
              u.dirty = true;
            }
            break;
          }
          case 'shoot': {
            u.dirty = true;
            if (target) {
              const dx = target.pos.x - u.pos.x;
              const dz = target.pos.z - u.pos.z;
              if (Math.abs(dx) + Math.abs(dz) > 0.001) u.facing = Math.atan2(dx, dz);
            }
            const cycle = 2.6;
            const release = 1.62;
            const k = u.stateTime % cycle;
            if (!u.hasStruck && k > release) {
              u.hasStruck = true;
              if (target) {
                this.fireArrow(u, target);
                this.emit('bowRelease', u.pos, 1.45, army.id);
              }
            }
            if (k < release * 0.4) u.hasStruck = false;
            if (dist < 8 && dist > 2.4) {
              u.pos.z -= dir * u.speed * 0.8 * dt;
              u.pos.x += (u.homeX - u.pos.x) * Math.min(1, dt);
            }
            // düşman üstüne bindiyse okçu kılıcına davranır
            if (dist < 2.4) {
              u.state = 'attack';
              u.stateTime = 0;
              u.hasStruck = false;
              u.nextAction = 0.7 + this.rng() * 1.4;
              u.dirty = true;
            } else if (!target) {
              u.state = 'advance';
              u.stateTime = 0;
              u.dirty = true;
            }
            break;
          }
          case 'rout': {
            u.pos.z -= dir * u.speed * 1.5 * dt;
            u.facing = army.id === 0 ? 0 : Math.PI;
            u.dirty = true;
            break;
          }
        }
      }
    }

    this.updateArrows(dt);
    A.flush();
    B.flush();
    A.updateBanners();
    B.updateBanners();

    if (this.phase !== 'aftermath' && (A.stats.alive === 0 || B.stats.alive === 0)) {
      this.phase = 'aftermath';
    } else if (this.phase === 'advance') {
      const engaged = A.units.some((u) => u.alive && (u.state === 'engage' || u.state === 'attack' || u.state === 'shoot'));
      if (engaged) {
        this.phase = 'clash';
        this.pushEvent('horn', new THREE.Vector3(0, 2, -this.sim.separation * 0.5), 1);
      }
    }
  }

  private emit(type: SimEvent['type'], at: THREE.Vector3, y: number, armyId: 0 | 1): void {
    if (this.eventBudget-- <= 0) return;
    this.tmpVec.set(at.x, y, at.z);
    this.pushEvent(type, this.tmpVec, armyId);
  }

  private findTarget(u: UnitData, enemy: Army): UnitData | null {
    const maxD = u.role === 'archer' ? 34 : 22;
    if (u.targetId >= 0 && u.targetId < enemy.units.length) {
      const cur = enemy.units[u.targetId];
      if (cur && cur.alive && cur.pos.distanceToSquared(u.pos) < maxD * maxD) return cur;
    }
    let best: UnitData | null = null;
    let bestD = maxD * maxD;
    const n = enemy.units.length;
    if (n === 0) return null;
    const checks = Math.min(n, 40);
    const start = (u.id * 13) % n;
    for (let i = 0; i < checks; i++) {
      const e = enemy.units[(start + i) % n];
      if (!e.alive) continue;
      const d = e.pos.distanceToSquared(u.pos);
      if (d < bestD) {
        bestD = d;
        best = e;
      }
    }
    if (best) u.targetId = best.id;
    return best;
  }

  private damage(target: UnitData, amount: number, fromArmy: 0 | 1): void {
    if (!target.alive) return;
    target.hp -= amount;
    if (target.hp <= 0) {
      target.alive = false;
      target.state = 'dying';
      target.stateTime = 0;
      target.dirty = true;
      this.emit('death', target.pos, 0.9, fromArmy);
    } else if (target.state === 'advance') {
      target.state = 'engage';
      target.stateTime = 0;
      target.dirty = true;
    }
  }

  private fireArrow(from: UnitData, target: UnitData): void {
    if (!this.arrowMesh) return;
    let slot: Arrow | null = null;
    for (const a of this.arrows) {
      if (!a.active) {
        slot = a;
        break;
      }
    }
    if (!slot) return;
    slot.active = true;
    slot.life = 0;
    slot.pos.set(from.pos.x + (this.rng() - 0.5) * 0.7, 1.5, from.pos.z);
    const dx = target.pos.x - slot.pos.x + (this.rng() - 0.5) * 0.9;
    const dz = target.pos.z - slot.pos.z + (this.rng() - 0.5) * 0.9;
    const dist = Math.hypot(dx, dz);
    slot.flightTime = clamp(dist / 32, 0.4, 1.7);
    slot.vel.set(dx / slot.flightTime, (1.05 - slot.pos.y) / slot.flightTime + 4.9 * slot.flightTime * 0.5, dz / slot.flightTime);
    slot.targetId = target.id;
    slot.targetArmy = target.armyId;
  }

  private updateArrows(dt: number): void {
    if (!this.arrowMesh) return;
    let count = 0;
    const gravity = 4.9;
    for (const a of this.arrows) {
      if (!a.active) continue;
      a.life += dt;
      a.vel.y -= gravity * dt;
      a.pos.addScaledVector(a.vel, dt);
      if (a.life >= a.flightTime || a.pos.y < 0.03) {
        if (a.life >= a.flightTime * 0.9) {
          const enemy = this.armies[a.targetArmy];
          const target = enemy.units[a.targetId];
          if (target && target.alive) {
            this.damage(target, 24, a.targetArmy === 0 ? 1 : 0);
            this.emit('arrowHit', a.pos, a.pos.y, a.targetArmy === 0 ? 1 : 0);
          }
        }
        a.active = false;
        continue;
      }
      const o = this.tmpObj;
      o.position.copy(a.pos);
      this.tmpVec.copy(a.pos).add(a.vel);
      o.up.set(0, 1, 0);
      o.lookAt(this.tmpVec);
      o.updateMatrix();
      this.arrowMesh.setMatrixAt(count++, o.matrix);
    }
    this.arrowMesh.count = count;
    if (count > 0) this.arrowMesh.instanceMatrix.needsUpdate = true;
  }

  stats(): { time: number; phase: BattleSim['phase']; armies: [ArmyStats, ArmyStats]; arrowsInFlight: number } {
    let inFlight = 0;
    for (const a of this.arrows) if (a.active) inFlight++;
    return { time: this.time, phase: this.phase, armies: [this.armies[0].stats, this.armies[1].stats], arrowsInFlight: inFlight };
  }

  dispose(): void {
    this.armies[0].dispose();
    this.armies[1].dispose();
    this.arrowGeo?.dispose();
    this.arrowMesh?.dispose();
  }
}

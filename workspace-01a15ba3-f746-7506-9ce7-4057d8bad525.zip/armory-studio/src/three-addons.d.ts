declare module 'three/addons/utils/BufferGeometryUtils.js' {
  import type { BufferGeometry } from 'three';
  export function mergeGeometries(geometries: BufferGeometry[], useGroups?: boolean): BufferGeometry | null;
  export function mergeVertices(geometry: BufferGeometry, tolerance?: number): BufferGeometry;
  export function toCreasedNormals(geometry: BufferGeometry, creaseAngle?: number): BufferGeometry;
  export function computeMorphedAttributes(object: unknown): Record<string, unknown>;
}

declare module 'three/addons/controls/OrbitControls.js' {
  import * as THREE from 'three';
  export class OrbitControls {
    constructor(camera: THREE.Camera, domElement?: HTMLElement);
    object: THREE.Camera;
    domElement: HTMLElement;
    enabled: boolean;
    target: THREE.Vector3;
    minDistance: number;
    maxDistance: number;
    minPolarAngle: number;
    maxPolarAngle: number;
    enableDamping: boolean;
    dampingFactor: number;
    enablePan: boolean;
    enableZoom: boolean;
    enableRotate: boolean;
    autoRotate: boolean;
    autoRotateSpeed: number;
    zoomSpeed: number;
    panSpeed: number;
    rotateSpeed: number;
    screenSpacePanning: boolean;
    update(): boolean;
    dispose(): void;
    reset(): void;
    getDistance(): number;
    addEventListener(type: string, listener: (event: unknown) => void): void;
    removeEventListener(type: string, listener: (event: unknown) => void): void;
  }
}

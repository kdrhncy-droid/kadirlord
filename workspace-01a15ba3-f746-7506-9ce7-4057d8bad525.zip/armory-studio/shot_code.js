async (page) => { await page.screenshot({ path: '/home/user/shot_12_warhus.png', timeout: 60000, animations: 'disabled' }); }
